Imports System.Drawing
Public Class frmPictures
   Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents pic2 As System.Windows.Forms.PictureBox
   Friend WithEvents pic3 As System.Windows.Forms.PictureBox
   Friend WithEvents pic1 As System.Windows.Forms.PictureBox
   Friend WithEvents pic4 As System.Windows.Forms.PictureBox
   Friend WithEvents pic6 As System.Windows.Forms.PictureBox
   Friend WithEvents pic7 As System.Windows.Forms.PictureBox
   Friend WithEvents pic8 As System.Windows.Forms.PictureBox
   Friend WithEvents pic5 As System.Windows.Forms.PictureBox
   Friend WithEvents pic9 As System.Windows.Forms.PictureBox
   Friend WithEvents pic10 As System.Windows.Forms.PictureBox
   Friend WithEvents pic11 As System.Windows.Forms.PictureBox
   Friend WithEvents pic12 As System.Windows.Forms.PictureBox
   Friend WithEvents pic13 As System.Windows.Forms.PictureBox
   Friend WithEvents pic14 As System.Windows.Forms.PictureBox
   Friend WithEvents pic15 As System.Windows.Forms.PictureBox
   Friend WithEvents pic16 As System.Windows.Forms.PictureBox
   Friend WithEvents pic17 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox9 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox10 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox11 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox12 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox13 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox14 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox15 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox16 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox17 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox18 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox19 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox20 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox21 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox22 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox23 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox24 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox25 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox26 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox27 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox28 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox29 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox30 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox31 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox32 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox33 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox34 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox35 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox36 As System.Windows.Forms.PictureBox
   Friend WithEvents PictureBox37 As System.Windows.Forms.PictureBox
   Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.components = New System.ComponentModel.Container()
      Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmPictures))
      Me.pic2 = New System.Windows.Forms.PictureBox()
      Me.pic3 = New System.Windows.Forms.PictureBox()
      Me.pic1 = New System.Windows.Forms.PictureBox()
      Me.pic4 = New System.Windows.Forms.PictureBox()
      Me.pic6 = New System.Windows.Forms.PictureBox()
      Me.pic7 = New System.Windows.Forms.PictureBox()
      Me.pic8 = New System.Windows.Forms.PictureBox()
      Me.pic5 = New System.Windows.Forms.PictureBox()
      Me.pic9 = New System.Windows.Forms.PictureBox()
      Me.pic10 = New System.Windows.Forms.PictureBox()
      Me.pic11 = New System.Windows.Forms.PictureBox()
      Me.pic12 = New System.Windows.Forms.PictureBox()
      Me.pic13 = New System.Windows.Forms.PictureBox()
      Me.pic14 = New System.Windows.Forms.PictureBox()
      Me.pic15 = New System.Windows.Forms.PictureBox()
      Me.pic16 = New System.Windows.Forms.PictureBox()
      Me.pic17 = New System.Windows.Forms.PictureBox()
      Me.PictureBox9 = New System.Windows.Forms.PictureBox()
      Me.PictureBox10 = New System.Windows.Forms.PictureBox()
      Me.PictureBox11 = New System.Windows.Forms.PictureBox()
      Me.PictureBox12 = New System.Windows.Forms.PictureBox()
      Me.PictureBox13 = New System.Windows.Forms.PictureBox()
      Me.PictureBox14 = New System.Windows.Forms.PictureBox()
      Me.PictureBox15 = New System.Windows.Forms.PictureBox()
      Me.PictureBox16 = New System.Windows.Forms.PictureBox()
      Me.PictureBox17 = New System.Windows.Forms.PictureBox()
      Me.PictureBox18 = New System.Windows.Forms.PictureBox()
      Me.PictureBox19 = New System.Windows.Forms.PictureBox()
      Me.PictureBox20 = New System.Windows.Forms.PictureBox()
      Me.PictureBox21 = New System.Windows.Forms.PictureBox()
      Me.PictureBox22 = New System.Windows.Forms.PictureBox()
      Me.PictureBox23 = New System.Windows.Forms.PictureBox()
      Me.PictureBox24 = New System.Windows.Forms.PictureBox()
      Me.PictureBox25 = New System.Windows.Forms.PictureBox()
      Me.PictureBox26 = New System.Windows.Forms.PictureBox()
      Me.PictureBox27 = New System.Windows.Forms.PictureBox()
      Me.PictureBox28 = New System.Windows.Forms.PictureBox()
      Me.PictureBox29 = New System.Windows.Forms.PictureBox()
      Me.PictureBox30 = New System.Windows.Forms.PictureBox()
      Me.PictureBox31 = New System.Windows.Forms.PictureBox()
      Me.PictureBox32 = New System.Windows.Forms.PictureBox()
      Me.PictureBox33 = New System.Windows.Forms.PictureBox()
      Me.PictureBox34 = New System.Windows.Forms.PictureBox()
      Me.PictureBox35 = New System.Windows.Forms.PictureBox()
      Me.PictureBox36 = New System.Windows.Forms.PictureBox()
      Me.PictureBox37 = New System.Windows.Forms.PictureBox()
      Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
      Me.SuspendLayout()
      '
      'pic2
      '
      Me.pic2.Image = CType(resources.GetObject("pic2.Image"), System.Drawing.Bitmap)
      Me.pic2.Location = New System.Drawing.Point(32, 8)
      Me.pic2.Name = "pic2"
      Me.pic2.Size = New System.Drawing.Size(24, 24)
      Me.pic2.TabIndex = 6
      Me.pic2.TabStop = False
      Me.pic2.Visible = False
      '
      'pic3
      '
      Me.pic3.Image = CType(resources.GetObject("pic3.Image"), System.Drawing.Bitmap)
      Me.pic3.Location = New System.Drawing.Point(56, 8)
      Me.pic3.Name = "pic3"
      Me.pic3.Size = New System.Drawing.Size(32, 24)
      Me.pic3.TabIndex = 5
      Me.pic3.TabStop = False
      Me.pic3.Visible = False
      '
      'pic1
      '
      Me.pic1.Image = CType(resources.GetObject("pic1.Image"), System.Drawing.Bitmap)
      Me.pic1.Location = New System.Drawing.Point(8, 8)
      Me.pic1.Name = "pic1"
      Me.pic1.Size = New System.Drawing.Size(24, 24)
      Me.pic1.TabIndex = 4
      Me.pic1.TabStop = False
      Me.pic1.Visible = False
      '
      'pic4
      '
      Me.pic4.Image = CType(resources.GetObject("pic4.Image"), System.Drawing.Bitmap)
      Me.pic4.Location = New System.Drawing.Point(88, 8)
      Me.pic4.Name = "pic4"
      Me.pic4.Size = New System.Drawing.Size(32, 16)
      Me.pic4.TabIndex = 7
      Me.pic4.TabStop = False
      Me.pic4.Visible = False
      '
      'pic6
      '
      Me.pic6.Image = CType(resources.GetObject("pic6.Image"), System.Drawing.Bitmap)
      Me.pic6.Location = New System.Drawing.Point(144, 8)
      Me.pic6.Name = "pic6"
      Me.pic6.Size = New System.Drawing.Size(32, 24)
      Me.pic6.TabIndex = 8
      Me.pic6.TabStop = False
      Me.pic6.Visible = False
      '
      'pic7
      '
      Me.pic7.Image = CType(resources.GetObject("pic7.Image"), System.Drawing.Bitmap)
      Me.pic7.Location = New System.Drawing.Point(184, 8)
      Me.pic7.Name = "pic7"
      Me.pic7.Size = New System.Drawing.Size(24, 24)
      Me.pic7.TabIndex = 9
      Me.pic7.TabStop = False
      Me.pic7.Visible = False
      '
      'pic8
      '
      Me.pic8.Image = CType(resources.GetObject("pic8.Image"), System.Drawing.Bitmap)
      Me.pic8.Location = New System.Drawing.Point(224, 8)
      Me.pic8.Name = "pic8"
      Me.pic8.Size = New System.Drawing.Size(16, 16)
      Me.pic8.TabIndex = 10
      Me.pic8.TabStop = False
      Me.pic8.Visible = False
      '
      'pic5
      '
      Me.pic5.Image = CType(resources.GetObject("pic5.Image"), System.Drawing.Bitmap)
      Me.pic5.Location = New System.Drawing.Point(112, 8)
      Me.pic5.Name = "pic5"
      Me.pic5.Size = New System.Drawing.Size(32, 24)
      Me.pic5.TabIndex = 11
      Me.pic5.TabStop = False
      Me.pic5.Visible = False
      '
      'pic9
      '
      Me.pic9.Image = CType(resources.GetObject("pic9.Image"), System.Drawing.Bitmap)
      Me.pic9.Location = New System.Drawing.Point(264, 8)
      Me.pic9.Name = "pic9"
      Me.pic9.Size = New System.Drawing.Size(32, 24)
      Me.pic9.TabIndex = 12
      Me.pic9.TabStop = False
      Me.pic9.Visible = False
      '
      'pic10
      '
      Me.pic10.Image = CType(resources.GetObject("pic10.Image"), System.Drawing.Bitmap)
      Me.pic10.Location = New System.Drawing.Point(304, 8)
      Me.pic10.Name = "pic10"
      Me.pic10.Size = New System.Drawing.Size(24, 24)
      Me.pic10.TabIndex = 13
      Me.pic10.TabStop = False
      Me.pic10.Visible = False
      '
      'pic11
      '
      Me.pic11.Image = CType(resources.GetObject("pic11.Image"), System.Drawing.Bitmap)
      Me.pic11.Location = New System.Drawing.Point(8, 40)
      Me.pic11.Name = "pic11"
      Me.pic11.Size = New System.Drawing.Size(24, 24)
      Me.pic11.TabIndex = 14
      Me.pic11.TabStop = False
      Me.pic11.Visible = False
      '
      'pic12
      '
      Me.pic12.Image = CType(resources.GetObject("pic12.Image"), System.Drawing.Bitmap)
      Me.pic12.Location = New System.Drawing.Point(40, 32)
      Me.pic12.Name = "pic12"
      Me.pic12.Size = New System.Drawing.Size(24, 24)
      Me.pic12.TabIndex = 15
      Me.pic12.TabStop = False
      Me.pic12.Visible = False
      '
      'pic13
      '
      Me.pic13.Image = CType(resources.GetObject("pic13.Image"), System.Drawing.Bitmap)
      Me.pic13.Location = New System.Drawing.Point(80, 32)
      Me.pic13.Name = "pic13"
      Me.pic13.Size = New System.Drawing.Size(24, 24)
      Me.pic13.TabIndex = 16
      Me.pic13.TabStop = False
      Me.pic13.Visible = False
      '
      'pic14
      '
      Me.pic14.Image = CType(resources.GetObject("pic14.Image"), System.Drawing.Bitmap)
      Me.pic14.Location = New System.Drawing.Point(120, 32)
      Me.pic14.Name = "pic14"
      Me.pic14.Size = New System.Drawing.Size(24, 24)
      Me.pic14.TabIndex = 17
      Me.pic14.TabStop = False
      Me.pic14.Visible = False
      '
      'pic15
      '
      Me.pic15.Image = CType(resources.GetObject("pic15.Image"), System.Drawing.Bitmap)
      Me.pic15.Location = New System.Drawing.Point(160, 32)
      Me.pic15.Name = "pic15"
      Me.pic15.Size = New System.Drawing.Size(24, 24)
      Me.pic15.TabIndex = 18
      Me.pic15.TabStop = False
      Me.pic15.Visible = False
      '
      'pic16
      '
      Me.pic16.Image = CType(resources.GetObject("pic16.Image"), System.Drawing.Bitmap)
      Me.pic16.Location = New System.Drawing.Point(200, 32)
      Me.pic16.Name = "pic16"
      Me.pic16.Size = New System.Drawing.Size(24, 24)
      Me.pic16.TabIndex = 19
      Me.pic16.TabStop = False
      Me.pic16.Visible = False
      '
      'pic17
      '
      Me.pic17.Image = CType(resources.GetObject("pic17.Image"), System.Drawing.Bitmap)
      Me.pic17.Location = New System.Drawing.Point(232, 32)
      Me.pic17.Name = "pic17"
      Me.pic17.Size = New System.Drawing.Size(24, 24)
      Me.pic17.TabIndex = 20
      Me.pic17.TabStop = False
      Me.pic17.Visible = False
      '
      'PictureBox9
      '
      Me.PictureBox9.Image = CType(resources.GetObject("PictureBox9.Image"), System.Drawing.Bitmap)
      Me.PictureBox9.Location = New System.Drawing.Point(272, 32)
      Me.PictureBox9.Name = "PictureBox9"
      Me.PictureBox9.Size = New System.Drawing.Size(24, 24)
      Me.PictureBox9.TabIndex = 21
      Me.PictureBox9.TabStop = False
      Me.PictureBox9.Visible = False
      '
      'PictureBox10
      '
      Me.PictureBox10.Image = CType(resources.GetObject("PictureBox10.Image"), System.Drawing.Bitmap)
      Me.PictureBox10.Location = New System.Drawing.Point(8, 64)
      Me.PictureBox10.Name = "PictureBox10"
      Me.PictureBox10.Size = New System.Drawing.Size(32, 24)
      Me.PictureBox10.TabIndex = 22
      Me.PictureBox10.TabStop = False
      Me.PictureBox10.Visible = False
      '
      'PictureBox11
      '
      Me.PictureBox11.Image = CType(resources.GetObject("PictureBox11.Image"), System.Drawing.Bitmap)
      Me.PictureBox11.Location = New System.Drawing.Point(48, 56)
      Me.PictureBox11.Name = "PictureBox11"
      Me.PictureBox11.Size = New System.Drawing.Size(24, 24)
      Me.PictureBox11.TabIndex = 23
      Me.PictureBox11.TabStop = False
      Me.PictureBox11.Visible = False
      '
      'PictureBox12
      '
      Me.PictureBox12.Image = CType(resources.GetObject("PictureBox12.Image"), System.Drawing.Bitmap)
      Me.PictureBox12.Location = New System.Drawing.Point(80, 56)
      Me.PictureBox12.Name = "PictureBox12"
      Me.PictureBox12.Size = New System.Drawing.Size(24, 24)
      Me.PictureBox12.TabIndex = 24
      Me.PictureBox12.TabStop = False
      Me.PictureBox12.Visible = False
      '
      'PictureBox13
      '
      Me.PictureBox13.Image = CType(resources.GetObject("PictureBox13.Image"), System.Drawing.Bitmap)
      Me.PictureBox13.Location = New System.Drawing.Point(112, 56)
      Me.PictureBox13.Name = "PictureBox13"
      Me.PictureBox13.Size = New System.Drawing.Size(32, 24)
      Me.PictureBox13.TabIndex = 25
      Me.PictureBox13.TabStop = False
      Me.PictureBox13.Visible = False
      '
      'PictureBox14
      '
      Me.PictureBox14.Image = CType(resources.GetObject("PictureBox14.Image"), System.Drawing.Bitmap)
      Me.PictureBox14.Location = New System.Drawing.Point(160, 56)
      Me.PictureBox14.Name = "PictureBox14"
      Me.PictureBox14.Size = New System.Drawing.Size(24, 16)
      Me.PictureBox14.TabIndex = 26
      Me.PictureBox14.TabStop = False
      Me.PictureBox14.Visible = False
      '
      'PictureBox15
      '
      Me.PictureBox15.Image = CType(resources.GetObject("PictureBox15.Image"), System.Drawing.Bitmap)
      Me.PictureBox15.Location = New System.Drawing.Point(200, 56)
      Me.PictureBox15.Name = "PictureBox15"
      Me.PictureBox15.Size = New System.Drawing.Size(24, 16)
      Me.PictureBox15.TabIndex = 27
      Me.PictureBox15.TabStop = False
      Me.PictureBox15.Visible = False
      '
      'PictureBox16
      '
      Me.PictureBox16.Image = CType(resources.GetObject("PictureBox16.Image"), System.Drawing.Bitmap)
      Me.PictureBox16.Location = New System.Drawing.Point(240, 56)
      Me.PictureBox16.Name = "PictureBox16"
      Me.PictureBox16.Size = New System.Drawing.Size(24, 24)
      Me.PictureBox16.TabIndex = 28
      Me.PictureBox16.TabStop = False
      Me.PictureBox16.Visible = False
      '
      'PictureBox17
      '
      Me.PictureBox17.Image = CType(resources.GetObject("PictureBox17.Image"), System.Drawing.Bitmap)
      Me.PictureBox17.Location = New System.Drawing.Point(280, 56)
      Me.PictureBox17.Name = "PictureBox17"
      Me.PictureBox17.Size = New System.Drawing.Size(24, 24)
      Me.PictureBox17.TabIndex = 29
      Me.PictureBox17.TabStop = False
      Me.PictureBox17.Visible = False
      '
      'PictureBox18
      '
      Me.PictureBox18.Image = CType(resources.GetObject("PictureBox18.Image"), System.Drawing.Bitmap)
      Me.PictureBox18.Location = New System.Drawing.Point(8, 88)
      Me.PictureBox18.Name = "PictureBox18"
      Me.PictureBox18.Size = New System.Drawing.Size(24, 24)
      Me.PictureBox18.TabIndex = 30
      Me.PictureBox18.TabStop = False
      Me.PictureBox18.Visible = False
      '
      'PictureBox19
      '
      Me.PictureBox19.Image = CType(resources.GetObject("PictureBox19.Image"), System.Drawing.Bitmap)
      Me.PictureBox19.Location = New System.Drawing.Point(48, 88)
      Me.PictureBox19.Name = "PictureBox19"
      Me.PictureBox19.Size = New System.Drawing.Size(24, 24)
      Me.PictureBox19.TabIndex = 31
      Me.PictureBox19.TabStop = False
      Me.PictureBox19.Visible = False
      '
      'PictureBox20
      '
      Me.PictureBox20.Image = CType(resources.GetObject("PictureBox20.Image"), System.Drawing.Bitmap)
      Me.PictureBox20.Location = New System.Drawing.Point(80, 88)
      Me.PictureBox20.Name = "PictureBox20"
      Me.PictureBox20.Size = New System.Drawing.Size(32, 24)
      Me.PictureBox20.TabIndex = 32
      Me.PictureBox20.TabStop = False
      Me.PictureBox20.Visible = False
      '
      'PictureBox21
      '
      Me.PictureBox21.Image = CType(resources.GetObject("PictureBox21.Image"), System.Drawing.Bitmap)
      Me.PictureBox21.Location = New System.Drawing.Point(112, 88)
      Me.PictureBox21.Name = "PictureBox21"
      Me.PictureBox21.Size = New System.Drawing.Size(24, 16)
      Me.PictureBox21.TabIndex = 33
      Me.PictureBox21.TabStop = False
      Me.PictureBox21.Visible = False
      '
      'PictureBox22
      '
      Me.PictureBox22.Image = CType(resources.GetObject("PictureBox22.Image"), System.Drawing.Bitmap)
      Me.PictureBox22.Location = New System.Drawing.Point(144, 88)
      Me.PictureBox22.Name = "PictureBox22"
      Me.PictureBox22.Size = New System.Drawing.Size(32, 24)
      Me.PictureBox22.TabIndex = 34
      Me.PictureBox22.TabStop = False
      Me.PictureBox22.Visible = False
      '
      'PictureBox23
      '
      Me.PictureBox23.Image = CType(resources.GetObject("PictureBox23.Image"), System.Drawing.Bitmap)
      Me.PictureBox23.Location = New System.Drawing.Point(192, 88)
      Me.PictureBox23.Name = "PictureBox23"
      Me.PictureBox23.Size = New System.Drawing.Size(24, 24)
      Me.PictureBox23.TabIndex = 35
      Me.PictureBox23.TabStop = False
      Me.PictureBox23.Visible = False
      '
      'PictureBox24
      '
      Me.PictureBox24.Image = CType(resources.GetObject("PictureBox24.Image"), System.Drawing.Bitmap)
      Me.PictureBox24.Location = New System.Drawing.Point(232, 80)
      Me.PictureBox24.Name = "PictureBox24"
      Me.PictureBox24.Size = New System.Drawing.Size(32, 24)
      Me.PictureBox24.TabIndex = 36
      Me.PictureBox24.TabStop = False
      Me.PictureBox24.Visible = False
      '
      'PictureBox25
      '
      Me.PictureBox25.Image = CType(resources.GetObject("PictureBox25.Image"), System.Drawing.Bitmap)
      Me.PictureBox25.Location = New System.Drawing.Point(280, 80)
      Me.PictureBox25.Name = "PictureBox25"
      Me.PictureBox25.Size = New System.Drawing.Size(32, 24)
      Me.PictureBox25.TabIndex = 37
      Me.PictureBox25.TabStop = False
      Me.PictureBox25.Visible = False
      '
      'PictureBox26
      '
      Me.PictureBox26.Image = CType(resources.GetObject("PictureBox26.Image"), System.Drawing.Bitmap)
      Me.PictureBox26.Location = New System.Drawing.Point(8, 112)
      Me.PictureBox26.Name = "PictureBox26"
      Me.PictureBox26.Size = New System.Drawing.Size(24, 24)
      Me.PictureBox26.TabIndex = 38
      Me.PictureBox26.TabStop = False
      Me.PictureBox26.Visible = False
      '
      'PictureBox27
      '
      Me.PictureBox27.Image = CType(resources.GetObject("PictureBox27.Image"), System.Drawing.Bitmap)
      Me.PictureBox27.Location = New System.Drawing.Point(48, 112)
      Me.PictureBox27.Name = "PictureBox27"
      Me.PictureBox27.Size = New System.Drawing.Size(24, 24)
      Me.PictureBox27.TabIndex = 39
      Me.PictureBox27.TabStop = False
      Me.PictureBox27.Visible = False
      '
      'PictureBox28
      '
      Me.PictureBox28.Image = CType(resources.GetObject("PictureBox28.Image"), System.Drawing.Bitmap)
      Me.PictureBox28.Location = New System.Drawing.Point(88, 112)
      Me.PictureBox28.Name = "PictureBox28"
      Me.PictureBox28.Size = New System.Drawing.Size(24, 24)
      Me.PictureBox28.TabIndex = 40
      Me.PictureBox28.TabStop = False
      Me.PictureBox28.Visible = False
      '
      'PictureBox29
      '
      Me.PictureBox29.Image = CType(resources.GetObject("PictureBox29.Image"), System.Drawing.Bitmap)
      Me.PictureBox29.Location = New System.Drawing.Point(128, 112)
      Me.PictureBox29.Name = "PictureBox29"
      Me.PictureBox29.Size = New System.Drawing.Size(24, 24)
      Me.PictureBox29.TabIndex = 41
      Me.PictureBox29.TabStop = False
      Me.PictureBox29.Visible = False
      '
      'PictureBox30
      '
      Me.PictureBox30.Image = CType(resources.GetObject("PictureBox30.Image"), System.Drawing.Bitmap)
      Me.PictureBox30.Location = New System.Drawing.Point(168, 112)
      Me.PictureBox30.Name = "PictureBox30"
      Me.PictureBox30.Size = New System.Drawing.Size(24, 24)
      Me.PictureBox30.TabIndex = 42
      Me.PictureBox30.TabStop = False
      Me.PictureBox30.Visible = False
      '
      'PictureBox31
      '
      Me.PictureBox31.Image = CType(resources.GetObject("PictureBox31.Image"), System.Drawing.Bitmap)
      Me.PictureBox31.Location = New System.Drawing.Point(208, 112)
      Me.PictureBox31.Name = "PictureBox31"
      Me.PictureBox31.Size = New System.Drawing.Size(32, 32)
      Me.PictureBox31.TabIndex = 43
      Me.PictureBox31.TabStop = False
      Me.PictureBox31.Visible = False
      '
      'PictureBox32
      '
      Me.PictureBox32.Image = CType(resources.GetObject("PictureBox32.Image"), System.Drawing.Bitmap)
      Me.PictureBox32.Location = New System.Drawing.Point(256, 112)
      Me.PictureBox32.Name = "PictureBox32"
      Me.PictureBox32.Size = New System.Drawing.Size(24, 24)
      Me.PictureBox32.TabIndex = 44
      Me.PictureBox32.TabStop = False
      Me.PictureBox32.Visible = False
      '
      'PictureBox33
      '
      Me.PictureBox33.Image = CType(resources.GetObject("PictureBox33.Image"), System.Drawing.Bitmap)
      Me.PictureBox33.Location = New System.Drawing.Point(8, 144)
      Me.PictureBox33.Name = "PictureBox33"
      Me.PictureBox33.Size = New System.Drawing.Size(32, 24)
      Me.PictureBox33.TabIndex = 45
      Me.PictureBox33.TabStop = False
      Me.PictureBox33.Visible = False
      '
      'PictureBox34
      '
      Me.PictureBox34.Image = CType(resources.GetObject("PictureBox34.Image"), System.Drawing.Bitmap)
      Me.PictureBox34.Location = New System.Drawing.Point(56, 144)
      Me.PictureBox34.Name = "PictureBox34"
      Me.PictureBox34.Size = New System.Drawing.Size(32, 32)
      Me.PictureBox34.TabIndex = 46
      Me.PictureBox34.TabStop = False
      Me.PictureBox34.Visible = False
      '
      'PictureBox35
      '
      Me.PictureBox35.Image = CType(resources.GetObject("PictureBox35.Image"), System.Drawing.Bitmap)
      Me.PictureBox35.Location = New System.Drawing.Point(104, 144)
      Me.PictureBox35.Name = "PictureBox35"
      Me.PictureBox35.Size = New System.Drawing.Size(24, 24)
      Me.PictureBox35.TabIndex = 47
      Me.PictureBox35.TabStop = False
      Me.PictureBox35.Visible = False
      '
      'PictureBox36
      '
      Me.PictureBox36.Image = CType(resources.GetObject("PictureBox36.Image"), System.Drawing.Bitmap)
      Me.PictureBox36.Location = New System.Drawing.Point(144, 144)
      Me.PictureBox36.Name = "PictureBox36"
      Me.PictureBox36.Size = New System.Drawing.Size(32, 24)
      Me.PictureBox36.TabIndex = 48
      Me.PictureBox36.TabStop = False
      Me.PictureBox36.Visible = False
      '
      'PictureBox37
      '
      Me.PictureBox37.Image = CType(resources.GetObject("PictureBox37.Image"), System.Drawing.Bitmap)
      Me.PictureBox37.Location = New System.Drawing.Point(192, 144)
      Me.PictureBox37.Name = "PictureBox37"
      Me.PictureBox37.Size = New System.Drawing.Size(24, 32)
      Me.PictureBox37.TabIndex = 49
      Me.PictureBox37.TabStop = False
      Me.PictureBox37.Visible = False
      '
      'ImageList1
      '
      Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
      Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
      Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
      Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
      '
      'frmPictures
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(336, 200)
      Me.ControlBox = False
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.PictureBox37, Me.PictureBox36, Me.PictureBox35, Me.PictureBox34, Me.PictureBox33, Me.PictureBox32, Me.PictureBox31, Me.PictureBox30, Me.PictureBox29, Me.PictureBox28, Me.PictureBox27, Me.PictureBox26, Me.PictureBox25, Me.PictureBox24, Me.PictureBox23, Me.PictureBox22, Me.PictureBox21, Me.PictureBox20, Me.PictureBox19, Me.PictureBox18, Me.PictureBox17, Me.PictureBox16, Me.PictureBox15, Me.PictureBox14, Me.PictureBox13, Me.PictureBox12, Me.PictureBox11, Me.PictureBox10, Me.PictureBox9, Me.pic17, Me.pic16, Me.pic15, Me.pic14, Me.pic13, Me.pic12, Me.pic11, Me.pic10, Me.pic9, Me.pic5, Me.pic8, Me.pic7, Me.pic6, Me.pic4, Me.pic2, Me.pic3, Me.pic1})
      Me.Name = "frmPictures"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub frmPictures_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      Me.Size = New System.Drawing.Size(1, 1)
      Me.Visible = False
   End Sub
End Class
