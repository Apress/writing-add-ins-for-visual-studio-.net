'****************************
'* Copyright HHI Software, Inc.
'* All Rights Reserved
'* Date Created: 02/03/2002
'* Author: Les Smith
'****************************
Imports Microsoft.Office.Core
Imports EnvDTE
Imports Extensibility
Imports System.Runtime.InteropServices
Imports System.Windows.Forms

#Region " Read me for Add-in installation and setup information. "
' When run, the Add-in wizard prepared the registry for the Add-in.
' At a later time, if the Add-in becomes unavailable for reasons such as:
'   1) You moved this project to a computer other than which is was originally created on.
'   2) You chose 'Yes' when presented with a message asking if you wish to remove the Add-in.
'   3) Registry corruption.
' you will need to re-register the Add-in by building the CommandBarSetup project 
' by right clicking the project in the Solution Explorer, then choosing install.
#End Region

<GuidAttribute("D08E0D55-064B-450F-BD32-11A06F17E0DE"), _
ProgIdAttribute("CommandBar.Connect")> _
Public Class Connect

   Implements IDTExtensibility2
   Dim frm As New frmPictures()
   Private oAddin As AddIn
   Dim oVB As EnvDTE.DTE
   Private TBar As Microsoft.Office.Core.CommandBar
   Private mcbBrowseProcs As Microsoft.Office.Core.CommandBarControl
   Private mcbBrowseVars As Microsoft.Office.Core.CommandBarControl
   Private mcbQuikFind As Microsoft.Office.Core.CommandBarControl
   Private mcbExplorer As Microsoft.Office.Core.CommandBarControl
   Private mcbMultiSearch As Microsoft.Office.Core.CommandBarControl
   Private mcbIfAnalyser As Microsoft.Office.Core.CommandBarControl
   Private mcbScanProcs As Microsoft.Office.Core.CommandBarControl
   Private mcbScanVars As Microsoft.Office.Core.CommandBarControl
   Private mcbSetupAbout As Microsoft.Office.Core.CommandBarControl
   Private Kind As Byte

   ' Menu controls
   Dim mnuVBExpoPopup As Microsoft.Office.Core.CommandBarControl
   Dim mnuCompile As Microsoft.Office.Core.CommandBarControl
   Dim mnuBrowse As Microsoft.Office.Core.CommandBarControl
   Dim mnuScan As Microsoft.Office.Core.CommandBarControl
   Dim mnuBrowsePrj As Microsoft.Office.Core.CommandBarControl
   Dim mnuObjBrowse As Microsoft.Office.Core.CommandBarControl
   Dim mnuAbout As Microsoft.Office.Core.CommandBarControl
   Dim mnuReports As Microsoft.Office.Core.CommandBarControl
   Dim mnuSearch As Microsoft.Office.Core.CommandBarControl
   Dim mnuIfAnalyzer As Microsoft.Office.Core.CommandBarControl
   Dim mnuProjectExplorer As Microsoft.Office.Core.CommandBarControl
   Dim mnuQuikFind As Microsoft.Office.Core.CommandBarControl
   Dim mnuVarScan As Microsoft.Office.Core.CommandBarControl
   Dim mnuVarBrowse As Microsoft.Office.Core.CommandBarControl

   'command bar event handler
   Public WithEvents mnuScanHandler As EnvDTE.CommandBarEvents
   Public WithEvents mnuBrowsePrjHandler As EnvDTE.CommandBarEvents
   Public WithEvents mnuVarScanHandler As EnvDTE.CommandBarEvents
   Public WithEvents mnuVarBrowseHandler As EnvDTE.CommandBarEvents
   Public WithEvents mnuObjBrowseHandler As EnvDTE.CommandBarEvents
   Public WithEvents mnuAboutHandler As EnvDTE.CommandBarEvents
   Public WithEvents mnuReportsHandler As EnvDTE.CommandBarEvents
   Public WithEvents mnuSearchHandler As EnvDTE.CommandBarEvents
   Public WithEvents mnuIfAnalyzerHandler As EnvDTE.CommandBarEvents
   Public WithEvents mnuProjectExplorerHandler As EnvDTE.CommandBarEvents

   Dim commandBarControl As commandBarControl
   Public WithEvents commandBarEvents As EnvDTE.CommandBarEvents
   Public WithEvents commandBarEvents2 As EnvDTE.CommandBarEvents
   Public WithEvents commandBarEvents3 As EnvDTE.CommandBarEvents
   Public WithEvents commandBarEvents4 As EnvDTE.CommandBarEvents
   Public WithEvents commandBarEvents5 As EnvDTE.CommandBarEvents
   Public WithEvents commandBarEvents6 As EnvDTE.CommandBarEvents
   Public WithEvents commandBarEvents7 As EnvDTE.CommandBarEvents
   Public WithEvents commandBarEvents8 As EnvDTE.CommandBarEvents
   Public WithEvents commandBarEvents9 As EnvDTE.CommandBarEvents
   Public WithEvents commandBarEvents10 As EnvDTE.CommandBarEvents
   Public WithEvents commandBarEvents11 As EnvDTE.CommandBarEvents
   Public WithEvents commandBarEvents12 As EnvDTE.CommandBarEvents
   Public WithEvents commandBarEvents13 As EnvDTE.CommandBarEvents
   Public WithEvents commandBarEvents14 As EnvDTE.CommandBarEvents
   Public WithEvents commandBarEvents15 As EnvDTE.CommandBarEvents
   Public WithEvents commandBarEvents16 As EnvDTE.CommandBarEvents
   Public WithEvents commandBarEvents17 As EnvDTE.CommandBarEvents
   Public WithEvents commandBarEvents18 As EnvDTE.CommandBarEvents
   Public WithEvents commandBarEvents19 As EnvDTE.CommandBarEvents
   Public WithEvents commandBarEvents20 As EnvDTE.CommandBarEvents
   Public WithEvents commandBarEvents21 As EnvDTE.CommandBarEvents

   Public Sub OnBeginShutdown(ByRef custom As System.Array) Implements IDTExtensibility2.OnBeginShutdown
   End Sub

   Public Sub OnAddInsUpdate(ByRef custom As System.Array) Implements IDTExtensibility2.OnAddInsUpdate
   End Sub

   Public Sub OnStartupComplete(ByRef custom As System.Array) Implements IDTExtensibility2.OnStartupComplete
   End Sub

   Public Sub OnDisconnection(ByVal RemoveMode As ext_DisconnectMode, _
                              ByRef custom As System.Array) _
                              Implements IDTExtensibility2.OnDisconnection


      On Error Resume Next
      mcbBrowseProcs.Delete()
      mcbBrowseVars.Delete()
      mcbMultiSearch.Delete()
      mcbIfAnalyser.Delete()
      mcbExplorer.Delete()
      mcbScanProcs.Delete()
      mcbSetupAbout.Delete()
      mcbScanVars.Delete()
      mcbQuikFind.Delete()
      TBar.Delete()

      mnuIfAnalyzer.Delete()
      mnuQuikFind.Delete()
      mnuScan.Delete()
      mnuVarScan.Delete()
      mnuVarBrowse.Delete()
      mnuProjectExplorer.Delete()
      mnuSearch.Delete()
      mnuAbout.Delete()
      mnuBrowsePrj.Delete()
      mnuCompile.Delete()
      mnuBrowse.Delete()
      mnuVBExpoPopup.Delete()
   End Sub

   Public Sub OnConnection(ByVal application As Object, ByVal connectMode As ext_ConnectMode, ByVal addInInst As Object, ByRef custom As System.Array) Implements IDTExtensibility2.OnConnection
      Dim commandBars As _CommandBars
      Dim toolsCommandBar As Microsoft.Office.Core.CommandBar
      Dim commandBarControls As CommandBarControls
      Dim strCommandBarItem As String = "Tools"

      oVB = CType(application, EnvDTE.DTE)
      oAddin = CType(addInInst, AddIn)

      Try
         ' load the bitmap container
         frm.Show()
         frm.Hide()

         CreateOfficeToolBar()

         CreateOfficeToolBarButtons()

         SetupOfficeMenus()

         'destroy the bitmap container
         frm.Dispose()
      Catch ex As System.Exception
         System.Windows.Forms.MessageBox.Show(ex.ToString())
      End Try
   End Sub

   Private Sub commandBarEvents_Click(ByVal CommandBarControl As Object, _
      ByRef handled As Boolean, _
      ByRef CancelDefault As Boolean) _
      Handles commandBarEvents.Click
      MessageBox.Show("Browse Procedures clicked")
   End Sub
   Private Sub commandBarEvents2_Click(ByVal CommandBarControl As Object, _
      ByRef handled As Boolean, _
      ByRef CancelDefault As Boolean) _
      Handles commandBarEvents2.Click
      MessageBox.Show("Var Browse Clicked")
   End Sub
   Private Sub commandBarEvents3_Click(ByVal CommandBarControl As Object, _
      ByRef handled As Boolean, _
      ByRef CancelDefault As Boolean) _
      Handles commandBarEvents3.Click
      MessageBox.Show("Scan Procedures Clicked")
   End Sub
   Private Sub commandBarEvents4_Click(ByVal CommandBarControl As Object, _
      ByRef handled As Boolean, _
      ByRef CancelDefault As Boolean) _
      Handles commandBarEvents4.Click
      MessageBox.Show("Multi Search Clicked")
   End Sub
   Private Sub commandBarEvents5_Click(ByVal CommandBarControl As Object, _
      ByRef handled As Boolean, _
      ByRef CancelDefault As Boolean) _
      Handles commandBarEvents5.Click
      MessageBox.Show("Quik Find Clicked")
   End Sub
   Private Sub commandBarEvents6_Click(ByVal CommandBarControl As Object, _
      ByRef handled As Boolean, _
      ByRef CancelDefault As Boolean) _
      Handles commandBarEvents6.Click
      MessageBox.Show("Control Structure Analyzer Clicked")
   End Sub
   Private Sub commandBarEvents7_Click(ByVal CommandBarControl As Object, _
      ByRef handled As Boolean, _
      ByRef CancelDefault As Boolean) _
      Handles commandBarEvents7.Click
      MessageBox.Show("Project Explorer Clicked")
   End Sub
   Private Sub commandBarEvents8_Click(ByVal CommandBarControl As Object, _
      ByRef handled As Boolean, _
      ByRef CancelDefault As Boolean) _
      Handles commandBarEvents8.Click
      MessageBox.Show("Scan variables Clicked")
   End Sub
   Private Sub commandBarEvents9_Click(ByVal CommandBarControl As Object, _
      ByRef handled As Boolean, _
      ByRef CancelDefault As Boolean) _
      Handles commandBarEvents9.Click
      MessageBox.Show("About  Clicked")
   End Sub
   Private Sub commandBarEvents13_Click(ByVal CommandBarControl As Object, _
      ByRef handled As Boolean, _
      ByRef CancelDefault As Boolean) _
      Handles commandBarEvents13.Click
      MessageBox.Show("Browse Procs Clicked")
   End Sub
   Private Sub commandBarEvents14_Click(ByVal CommandBarControl As Object, _
      ByRef handled As Boolean, _
      ByRef CancelDefault As Boolean) _
      Handles commandBarEvents14.Click
      MessageBox.Show("Browse variables Clicked")
   End Sub
   Private Sub commandBarEvents15_Click(ByVal CommandBarControl As Object, _
      ByRef handled As Boolean, _
      ByRef CancelDefault As Boolean) _
      Handles commandBarEvents15.Click
      MessageBox.Show("Multi Search Clicked")
   End Sub
   Private Sub commandBarEvents16_Click(ByVal CommandBarControl As Object, _
      ByRef handled As Boolean, _
      ByRef CancelDefault As Boolean) _
      Handles commandBarEvents16.Click
      MessageBox.Show("Control Structure Analyzer Clicked")
   End Sub
   Private Sub commandBarEvents17_Click(ByVal CommandBarControl As Object, _
      ByRef handled As Boolean, _
      ByRef CancelDefault As Boolean) _
      Handles commandBarEvents17.Click
      MessageBox.Show("Project Explorer Clicked")
   End Sub
   Private Sub commandBarEvents18_Click(ByVal CommandBarControl As Object, _
      ByRef handled As Boolean, _
      ByRef CancelDefault As Boolean) _
      Handles commandBarEvents18.Click
      MessageBox.Show("Scan Procedures Clicked")
   End Sub
   Private Sub commandBarEvents19_Click(ByVal CommandBarControl As Object, _
      ByRef handled As Boolean, _
      ByRef CancelDefault As Boolean) _
      Handles commandBarEvents19.Click
      MessageBox.Show("Setup About Clicked")
   End Sub
   Private Sub commandBarEvents20_Click(ByVal CommandBarControl As Object, _
      ByRef handled As Boolean, _
      ByRef CancelDefault As Boolean) _
      Handles commandBarEvents20.Click
      MessageBox.Show("Scan variables Clicked")
   End Sub
   Private Sub commandBarEvents21_Click(ByVal CommandBarControl As Object, _
      ByRef handled As Boolean, _
      ByRef CancelDefault As Boolean) _
      Handles commandBarEvents21.Click
      MessageBox.Show("Scan variables Clicked")
   End Sub

   Private Sub CreateOfficeToolBar()
      ' This method creates the office toolbar
      TBar = AddOfficeToolBar(oVB, _
                            "VBXRTBar", _
                             False)
   End Sub

   Private Sub CreateOfficeToolBarButtons()
      ' This method calls the low level method that
      ' adds the tool buttons to the tool bar
      ' The paired commands do two things.
      ' 1) created the toolbar or button
      ' 2) link the command event to the event handler.
      Try
         ' note that the bitmap can come from a variety
         ' of places.  Here it is pulled from an imagelist
         ' the next menu pulls from an image control on the form
         mcbBrowseProcs = AddOfficeToolBarButton(oVB, _
            TBar, _
            "Browse Procedures", _
            frm.ImageList1.Images(0))
         commandBarEvents13 = CType(oVB.Events.CommandBarEvents(mcbBrowseProcs), _
               EnvDTE.CommandBarEvents)

         mcbBrowseVars = AddOfficeToolBarButton(oVB, _
            TBar, _
            "Browse Variables", _
            frm.pic8.Image)
         commandBarEvents14 = CType(oVB.Events.CommandBarEvents(mcbBrowseVars), _
            EnvDTE.CommandBarEvents)

         mcbMultiSearch = AddOfficeToolBarButton(oVB, _
            TBar, _
            "Multi Search", _
            frm.pic1.Image)
         commandBarEvents15 = CType(oVB.Events.CommandBarEvents(mcbMultiSearch), _
            EnvDTE.CommandBarEvents)

         mcbIfAnalyser = AddOfficeToolBarButton(oVB, _
            TBar, _
            "Control Structure Analyzer", _
            frm.PictureBox36.Image)
         commandBarEvents16 = CType(oVB.Events.CommandBarEvents(mcbIfAnalyser), _
            EnvDTE.CommandBarEvents)

         mcbExplorer = AddOfficeToolBarButton(oVB, _
            TBar, _
            "Project Explorer", _
            frm.PictureBox32.Image)
         commandBarEvents17 = CType(oVB.Events.CommandBarEvents(mcbExplorer), _
            EnvDTE.CommandBarEvents)

         mcbScanProcs = AddOfficeToolBarButton(oVB, _
            TBar, _
            "Scan Procedures", _
            frm.pic3.Image)
         commandBarEvents18 = CType(oVB.Events.CommandBarEvents(mcbScanProcs), _
            EnvDTE.CommandBarEvents)

         mcbSetupAbout = AddOfficeToolBarIconAndCaption(oVB, _
            TBar, _
            "Office Toolbar", _
            frm.PictureBox33.Image)
         commandBarEvents19 = CType(oVB.Events.CommandBarEvents(mcbSetupAbout), _
            EnvDTE.CommandBarEvents)

         mcbSetupAbout.TooltipText = "Setup Interface"
      Catch e As System.Exception
         MsgBox(e.Message)
      End Try
   End Sub

   Private Sub SetupOfficeMenus()
      ' This method sets up the office menu, including
      ' the popup and menuitiem menus
      Dim cmdBar As Microsoft.Office.Core.CommandBarControl

      Try
         cmdBar = oVB.CommandBars("MenuBar").Controls("Tools")

         ' set up top level popup menu
         mnuVBExpoPopup = AddOfficePopupMenu(VBE:=oVB, _
            Menu:=cmdBar, _
            Caption:="&Office Command Test", _
            sep:=True)

         ' set up sub menus
         mnuBrowse = AddOfficePopupMenu(VBE:=oVB, _
            Menu:=mnuVBExpoPopup, _
            Caption:="&Browse Procedures")
         mnuCompile = AddOfficePopupMenu(VBE:=oVB, _
            Menu:=mnuVBExpoPopup, _
            Caption:="Compile Project")

         ' add sub menus
         mnuBrowsePrj = AddOfficeMenuItem(VBE:=oVB, _
            Menu:=mnuBrowse, _
            Caption:="&Procedures", _
            Bitmap:=frm.pic5.Image)
         commandBarEvents = CType(oVB.Events.CommandBarEvents(mnuBrowsePrj), _
            EnvDTE.CommandBarEvents)

         mnuVarBrowse = AddOfficeMenuItem(VBE:=oVB, _
            Menu:=mnuBrowse, _
            Caption:="Variables", _
            Bitmap:=frm.pic5.Image)
         commandBarEvents2 = CType(oVB.Events.CommandBarEvents(mnuVarBrowse), _
            EnvDTE.CommandBarEvents)

         mnuScan = AddOfficeMenuItem(VBE:=oVB, _
            Menu:=mnuCompile, _
            Caption:="&Procedures", _
            Bitmap:=frm.pic1.Image)
         commandBarEvents3 = CType(oVB.Events.CommandBarEvents(mnuScan), _
            EnvDTE.CommandBarEvents)

         mnuSearch = AddOfficeMenuItem(VBE:=oVB, _
            Menu:=mnuVBExpoPopup, _
            Caption:="&Multi-String Search", _
            Bitmap:=frm.pic6.Image)
         commandBarEvents4 = CType(oVB.Events.CommandBarEvents(mnuSearch), _
            EnvDTE.CommandBarEvents)

         mnuQuikFind = AddOfficeMenuItem(VBE:=oVB, _
            Menu:=mnuVBExpoPopup, _
            Caption:="&Quik Find Selection", _
            Bitmap:=frm.PictureBox25.Image)
         commandBarEvents5 = CType(oVB.Events.CommandBarEvents(mnuQuikFind), _
            EnvDTE.CommandBarEvents)

         mnuIfAnalyzer = AddOfficeMenuItem(VBE:=oVB, _
            Menu:=mnuVBExpoPopup, _
            Caption:="CtrlStructure &Analyzer", _
            Bitmap:=frm.PictureBox36.Image)
         commandBarEvents6 = CType(oVB.Events.CommandBarEvents(mnuIfAnalyzer), _
            EnvDTE.CommandBarEvents)

         mnuProjectExplorer = AddOfficeMenuItem(VBE:=oVB, _
            Menu:=mnuVBExpoPopup, _
            Caption:="&Project Explorer", _
            Bitmap:=frm.PictureBox21.Image)
         commandBarEvents7 = CType(oVB.Events.CommandBarEvents(mnuProjectExplorer), _
            EnvDTE.CommandBarEvents)

         mnuVarScan = AddOfficeMenuItem(VBE:=oVB, _
            Menu:=mnuCompile, Caption:="&Variables", _
            Bitmap:=frm.PictureBox16.Image)
         commandBarEvents8 = CType(oVB.Events.CommandBarEvents(mnuVarScan), _
            EnvDTE.CommandBarEvents)

         mnuAbout = AddOfficeMenuItem(VBE:=oVB, _
            Menu:=mnuVBExpoPopup, _
            Caption:="&About", _
            Bitmap:=frm.PictureBox32.Image)
         commandBarEvents9 = CType(oVB.Events.CommandBarEvents(mnuAbout), _
            EnvDTE.CommandBarEvents)

         Exit Sub
      Catch e As System.Exception
         MsgBox(e.Message)
      End Try
   End Sub


   Public Function AddOfficeMenuItem(ByVal VBE As EnvDTE.DTE, _
      ByVal Menu As Microsoft.Office.Core.CommandBarControl, _
      ByVal Caption As String, _
      Optional ByVal pos As Byte = 0, _
      Optional ByVal sep As Boolean = False, _
      Optional ByVal Bitmap As Object = Nothing) _
      As Microsoft.Office.Core.CommandBarControl

      ' This method will add an office menuitem to an existing 
      ' office popupup menu
      Dim menuItem As Microsoft.Office.Core.CommandBarControl

      Try
         If Not (Bitmap Is Nothing) Then
            System.Windows.Forms.Clipboard.SetDataObject(Bitmap)
         End If

         ' Add menu item to VB menu:
         If pos = 0 Then pos = Menu.Controls.Count + 1
         menuItem = _
            Menu.Controls.Add(Type:=Microsoft.Office.Core.MsoControlType.msoControlButton, _
            Before:=pos, _
            Temporary:=True)

         ' Set properties of menu item:
         menuItem.Caption = Caption
         If sep Then menuItem.BeginGroup = True
         If Not (Bitmap Is Nothing) Then
            menuItem.Style = Microsoft.Office.Core.MsoButtonStyle.msoButtonIconAndCaption
            menuItem.PasteFace()
         End If
         Return menuItem
      Catch e As System.Exception
         Return menuItem
      End Try
   End Function

   Public Function AddOfficePopupMenu(ByVal VBE As EnvDTE.DTE, _
      ByVal Menu As Microsoft.Office.Core.CommandBarControl, _
      ByVal Caption As String, _
      Optional ByVal pos As Byte = 0, _
      Optional ByVal sep As Boolean = False) _
      As Microsoft.Office.Core.CommandBarControl

      ' This method adds an office popup menu to an existing menu
      ' The existing menu can be another popup menu.
      Dim popupMenu As Microsoft.Office.Core.CommandBarControl

      Try

         ' Add popupMenu menu to VB menu:
         If pos = 0 Then pos = Menu.Controls.Count + 1
         popupMenu = _
         Menu.Controls.Add(Type:=Microsoft.Office.Core.MsoControlType.msoControlPopup, _
         Before:=pos, _
         Temporary:=True)

         ' Set properties of popupMenu menu:
         popupMenu.Caption = Caption
         If sep Then popupMenu.BeginGroup = True
         Return popupMenu
      Catch e As System.Exception
         Return popupMenu
      End Try
   End Function

   Public Function AddOfficeToolBar(ByVal VBE As EnvDTE.DTE, _
      ByVal Caption As String, _
      Optional ByVal Floating As Boolean = False) _
      As Microsoft.Office.Core.CommandBar

      ' This method adds an office commandbar (toolbar) to
      ' the IDE.  It will become the container for command buttons.
      Dim Kind As Byte
      Dim toolBar As Microsoft.Office.Core.CommandBar

      Try

         ' Set parameter for pos argument:
         If Floating Then
            Kind = Microsoft.Office.Core.MsoBarPosition.msoBarFloating
         Else
            Kind = Microsoft.Office.Core.MsoBarPosition.msoBarTop
         End If

         ' Add custom toolbar and display it:
         toolBar = VBE.CommandBars.Add(Name:=Caption, _
                                    Position:=Kind, _
                                    Temporary:=True)
         toolBar.Visible = True
         Return toolBar
      Catch e As System.Exception
         Return toolBar
      End Try
   End Function

   Public Function AddOfficeToolBarButton(ByVal VBE As EnvDTE.DTE, _
      ByVal ToolBar As Microsoft.Office.Core.CommandBar, _
      ByVal Caption As String, _
      ByVal Bitmap As Object, _
      Optional ByVal pos As Byte = 0, _
      Optional ByVal sep As Boolean = False) _
      As Microsoft.Office.Core.CommandBarControl

      ' Variables:
      Dim cmdBtn As Microsoft.Office.Core.CommandBarControl

      Try
         If Caption = "" Or Bitmap Is Nothing Then Exit Function

         Clipboard.SetDataObject(Bitmap)

         ' Add button to Visual Studio IDE toolbar
         If pos = 0 Then pos = ToolBar.Controls.Count + 1
         cmdBtn = ToolBar.Controls.Add(Type:=Microsoft.Office.Core.MsoControlType.msoControlButton, _
                                        Before:=pos, _
                                        Temporary:=True)

         ' Set properties of button
         cmdBtn.Caption = Caption
         If sep Then cmdBtn.BeginGroup = True
         cmdBtn.Style = Microsoft.Office.Core.MsoButtonStyle.msoButtonIcon
         cmdBtn.PasteFace()
         Return cmdBtn
      Catch e As System.Exception
         Return cmdBtn
      End Try
   End Function

   Public Function AddOfficeToolBarIconAndCaption(ByVal VBE As EnvDTE.DTE, _
      ByVal ToolBar As Microsoft.Office.Core.CommandBar, _
      ByVal Caption As String, _
      ByVal Bitmap As Object, _
      Optional ByVal pos As Byte = 0, _
      Optional ByVal sep As Boolean = False) _
      As Microsoft.Office.Core.CommandBarControl

      ' Variables:
      Dim cmdBtn As Microsoft.Office.Core.CommandBarControl

      Try
         If Caption = "" Or Bitmap Is Nothing Then Exit Function

         Clipboard.SetDataObject(Bitmap)

         ' Add button to VB toolbar:
         If pos = 0 Then pos = ToolBar.Controls.Count + 1
         cmdBtn = ToolBar.Controls.Add(Type:=Microsoft.Office.Core.MsoControlType.msoControlButton, _
                                        Before:=pos, _
                                        Temporary:=True)

         ' Set properties of button:
         cmdBtn.Caption = Caption
         If sep Then cmdBtn.BeginGroup = True
         cmdBtn.Style = Microsoft.Office.Core.MsoButtonStyle.msoButtonIconAndCaption
         cmdBtn.PasteFace()
         Return cmdBtn
      Catch e As System.Exception
         Return cmdBtn
      End Try
   End Function

End Class
