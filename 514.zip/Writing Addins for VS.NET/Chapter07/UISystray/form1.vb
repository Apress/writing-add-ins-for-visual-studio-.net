Imports System.ComponentModel
Imports System.Drawing
Imports System.Windows.Forms
Imports System.Resources


Public Class Form1
   Inherits System.Windows.Forms.Form
   Private mSmileyDisplayed As Boolean

   Public Sub New()
      MyBase.New()

      Form1 = Me

      'This call is required by the Win Form Designer.
      InitializeComponent()

      ' we don't use this form so hide it
      Me.Hide()

      'setup the tray icon
      'InitializeNotifyicon()
   End Sub


   Public Sub DisplayMsg1(ByVal sender As Object, ByVal e As System.EventArgs)
      MessageBox.Show("You clicked Display Message1 Menu")
   End Sub

   Public Sub DisplayMsg2(ByVal sender As Object, ByVal e As System.EventArgs)
      MessageBox.Show("You clicked Dispaly Message2 Menu Item")
   End Sub


   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub
   Private components As System.ComponentModel.IContainer


#Region " Windows Form Designer generated code "

   'Required by the Windows Form Designer

   Dim WithEvents Form1 As System.Windows.Forms.Form

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Private WithEvents notifyicon As System.Windows.Forms.NotifyIcon
   Friend WithEvents ContextMenu1 As System.Windows.Forms.ContextMenu
   Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
   Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
   Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
   Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
   Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
   Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
   Friend WithEvents MenuItem7 As System.Windows.Forms.MenuItem
   Friend WithEvents MenuItem8 As System.Windows.Forms.MenuItem
   Private Sub InitializeComponent()
      Me.components = New System.ComponentModel.Container()
      Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
      Me.notifyicon = New System.Windows.Forms.NotifyIcon(Me.components)
      Me.ContextMenu1 = New System.Windows.Forms.ContextMenu()
      Me.MenuItem1 = New System.Windows.Forms.MenuItem()
      Me.MenuItem5 = New System.Windows.Forms.MenuItem()
      Me.MenuItem6 = New System.Windows.Forms.MenuItem()
      Me.MenuItem2 = New System.Windows.Forms.MenuItem()
      Me.MenuItem3 = New System.Windows.Forms.MenuItem()
      Me.MenuItem4 = New System.Windows.Forms.MenuItem()
      Me.MenuItem7 = New System.Windows.Forms.MenuItem()
      Me.MenuItem8 = New System.Windows.Forms.MenuItem()
      '
      'notifyicon
      '
      Me.notifyicon.ContextMenu = Me.ContextMenu1
      Me.notifyicon.Icon = CType(resources.GetObject("notifyicon.Icon"), System.Drawing.Icon)
      Me.notifyicon.Text = "Right click for menu"
      Me.notifyicon.Visible = True
      '
      'ContextMenu1
      '
      Me.ContextMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem2, Me.MenuItem3, Me.MenuItem4})
      '
      'MenuItem1
      '
      Me.MenuItem1.Index = 0
      Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem5, Me.MenuItem6})
      Me.MenuItem1.Text = "Messages 1"
      '
      'MenuItem5
      '
      Me.MenuItem5.Index = 0
      Me.MenuItem5.Text = "Display Messag1"
      '
      'MenuItem6
      '
      Me.MenuItem6.Index = 1
      Me.MenuItem6.Text = "Display Messag3"
      '
      'MenuItem2
      '
      Me.MenuItem2.Index = 1
      Me.MenuItem2.Text = "Mesage 2"
      '
      'MenuItem3
      '
      Me.MenuItem3.Index = 2
      Me.MenuItem3.Text = "-"
      '
      'MenuItem4
      '
      Me.MenuItem4.Index = 3
      Me.MenuItem4.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem7, Me.MenuItem8})
      Me.MenuItem4.Text = "Message 4"
      '
      'MenuItem7
      '
      Me.MenuItem7.Index = 0
      Me.MenuItem7.Text = "Dispaly Msg5"
      '
      'MenuItem8
      '
      Me.MenuItem8.Index = 1
      Me.MenuItem8.Text = "Display Msg6"
      '
      'Form1
      '
      Me.AccessibleRole = System.Windows.Forms.AccessibleRole.None
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(200, 168)
      Me.ControlBox = False
      Me.Enabled = False
      Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
      Me.MaximizeBox = False
      Me.MinimizeBox = False
      Me.Name = "Form1"
      Me.Opacity = 0
      Me.ShowInTaskbar = False
      Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
      Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual

   End Sub

#End Region

   Private Sub ContextMenu1_Popup(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles ContextMenu1.Popup

   End Sub

   Private Sub MenuItem1_Click(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles MenuItem1.Click
   End Sub

   Private Sub MenuItem2_Click(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles MenuItem2.Click
      MsgBox("Display msg2")
   End Sub

   Private Sub MenuItem4_Click(ByVal sender As System.Object, _
      ByVal e As System.EventArgs)
      notifyicon.Visible = False
      Me.Close()
   End Sub

   Private Sub MenuItem5_Click(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles MenuItem5.Click
      MsgBox("You clicked to display Msg1")
   End Sub

   Private Sub MenuItem6_Click(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles MenuItem6.Click
      MsgBox("You clicked to display Msg3")
   End Sub

   Private Sub MenuItem7_Click(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles MenuItem7.Click
      MsgBox("You clicked to display Msg5")
   End Sub

   Private Sub MenuItem8_Click(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles MenuItem8.Click
      MsgBox("You clicked to display Msg6")
   End Sub
End Class
