Imports Microsoft.Office.Core
imports Extensibility
imports System.Runtime.InteropServices
Imports EnvDTE

#Region " Read me for Add-in installation and setup information. "
' When run, the Add-in wizard prepared the registry for the Add-in.
' At a later time, if the Add-in becomes unavailable for reasons such as:
'   1) You moved this project to a computer other than which is was 
'  originally created on.
'   2) You chose 'Yes' when presented with a message asking if you _
'   wish to remove the Add-in.
'   3) Registry corruption.
' you will need to re-register the Add-in by building the _
' UISystraySetup project 
' by right clicking the project in the Solution Explorer, _
' then choosing install.
#End Region

<GuidAttribute("C95EA7C5-2E2E-4A89-BE99-8027DFA3C358"), _
ProgIdAttribute("UISystray.Connect")> _
Public Class Connect

   Implements Extensibility.IDTExtensibility2
   Implements IDTCommandTarget

   Dim oVB As EnvDTE.DTE
   Dim addInInstance As EnvDTE.AddIn
   Dim oFrm As Object

   Public Sub OnBeginShutdown(ByRef custom As System.Array) _
       Implements Extensibility.IDTExtensibility2.OnBeginShutdown
   End Sub

   Public Sub OnAddInsUpdate(ByRef custom As System.Array) _
      Implements Extensibility.IDTExtensibility2.OnAddInsUpdate
   End Sub

   Public Sub OnStartupComplete(ByRef custom As System.Array) _
      Implements Extensibility.IDTExtensibility2.OnStartupComplete
   End Sub

   Public Sub OnDisconnection(ByVal RemoveMode As _
      Extensibility.ext_DisconnectMode, _
      ByRef custom As System.Array) _
      Implements Extensibility.IDTExtensibility2.OnDisconnection
      oFrm.Dispose()
   End Sub

   Public Sub OnConnection(ByVal application As Object, _
      ByVal connectMode As Extensibility.ext_ConnectMode, _
      ByVal addInInst As Object, _
      ByRef custom As System.Array) _
      Implements Extensibility.IDTExtensibility2.OnConnection
      Dim frmIcon As New Form1()
      oVB = CType(application, EnvDTE.DTE)
      addInInstance = CType(addInInst, EnvDTE.AddIn)
      'frmIcon = New Form1()
      'frmIcon.Show()
      oFrm = frmIcon
   End Sub

   Public Sub Exec(ByVal cmdName As String, _
      ByVal executeOption As vsCommandExecOption, _
      ByRef varIn As Object, _
      ByRef varOut As Object, _
      ByRef handled As Boolean) _
      Implements IDTCommandTarget.Exec
      'handled = False
   End Sub

   Public Sub QueryStatus(ByVal cmdName As String, _
      ByVal neededText As vsCommandStatusTextWanted, _
      ByRef statusOption As vsCommandStatus, _
      ByRef commandText As Object) _
      Implements IDTCommandTarget.QueryStatus
   End Sub
End Class
