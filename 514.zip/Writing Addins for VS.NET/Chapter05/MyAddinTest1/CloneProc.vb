Option Strict On
Public Class CloneProc

   Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents txtProcToClone As System.Windows.Forms.TextBox
   Friend WithEvents btnPasteToModule As System.Windows.Forms.Button
   Friend WithEvents btnCopyToClipboard As System.Windows.Forms.Button
   Friend WithEvents Label1 As System.Windows.Forms.Label
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.txtProcToClone = New System.Windows.Forms.TextBox()
      Me.btnPasteToModule = New System.Windows.Forms.Button()
      Me.btnCopyToClipboard = New System.Windows.Forms.Button()
      Me.Label1 = New System.Windows.Forms.Label()
      Me.SuspendLayout()
      '
      'txtProcToClone
      '
      Me.txtProcToClone.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                  Or System.Windows.Forms.AnchorStyles.Left) _
                  Or System.Windows.Forms.AnchorStyles.Right)
      Me.txtProcToClone.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.txtProcToClone.Multiline = True
      Me.txtProcToClone.Name = "txtProcToClone"
      Me.txtProcToClone.ScrollBars = System.Windows.Forms.ScrollBars.Both
      Me.txtProcToClone.Size = New System.Drawing.Size(512, 229)
      Me.txtProcToClone.TabIndex = 0
      Me.txtProcToClone.Text = ""
      '
      'btnPasteToModule
      '
      Me.btnPasteToModule.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
      Me.btnPasteToModule.Location = New System.Drawing.Point(389, 240)
      Me.btnPasteToModule.Name = "btnPasteToModule"
      Me.btnPasteToModule.Size = New System.Drawing.Size(115, 32)
      Me.btnPasteToModule.TabIndex = 1
      Me.btnPasteToModule.Text = "&Paste To Module"
      '
      'btnCopyToClipboard
      '
      Me.btnCopyToClipboard.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
      Me.btnCopyToClipboard.Location = New System.Drawing.Point(263, 240)
      Me.btnCopyToClipboard.Name = "btnCopyToClipboard"
      Me.btnCopyToClipboard.Size = New System.Drawing.Size(115, 32)
      Me.btnCopyToClipboard.TabIndex = 2
      Me.btnCopyToClipboard.Text = "&Copy To Clipboard"
      '
      'Label1
      '
      Me.Label1.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left)
      Me.Label1.Location = New System.Drawing.Point(16, 240)
      Me.Label1.Name = "Label1"
      Me.Label1.Size = New System.Drawing.Size(192, 24)
      Me.Label1.TabIndex = 3
      Me.Label1.Text = "Change the name of the Method and click the desired button."
      '
      'CloneProc
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(514, 277)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label1, Me.btnCopyToClipboard, Me.btnPasteToModule, Me.txtProcToClone})
      Me.Name = "CloneProc"
      Me.Text = "CloneProc"
      Me.TopMost = True
      Me.ResumeLayout(False)

   End Sub

#End Region
   Dim sTextSave As String
   Dim sOrigType As String
   Dim sOrigName As String
   Dim bFormLoading As Boolean
   Dim mbWait As Boolean

   Public Function Display(ByVal sText As String) As String
      Dim sTemp As String
      Dim sWord As String
      Dim i As Integer

      sTextSave = sText

      ' get the "Sub Name("
      sTemp = Microsoft.VisualBasic.Left(sText, InStr(sText, "(") - 1)

      If InStr(sTemp, "Sub") > 0 Then
         sOrigType = "Sub"
      Else
         sOrigType = "Function"
      End If

      ' loop to get proc orig name
      ' when loop terminates, sOrigName is the name

      Do While Len(Trim$(sTemp)) > 0
         sWord = Connect.GetToken(sTemp, "_")
         If Trim$(sWord) <> "" Then
            sOrigName = sWord
         Else
            Exit Do
         End If
      Loop

      Me.Show()
      mbWait = True
      Do While mbWait
         System.Windows.Forms.Application.DoEvents()
      Loop


      sTemp = sTextSave
      'Me.Dispose()
      Return sTemp
   End Function


   Private Sub UpdateFunctionReturns()
      ' If the procedure is a function, get the
      ' name and propagate it thru the function
      ' also propagate any changes from the sub to a
      ' function and vice-versa thru the proc.
      Dim sWord As String
      Dim NextWord As String
      Dim sTemp As String
      Dim nL As Integer
      Dim sTemp2 As String
      Dim i As Integer
      Dim sNewName As String
      Dim sNewType As String
      Dim sLine As String
      Dim sTempLine As String
      Dim bFoundProcType As Boolean

      sTemp = Me.txtProcToClone.Text
      sTemp2 = ""

      nL = Connect.MLCount(sTemp, 0)
      For i = 1 To nL
         sLine = Connect.MemoLine(sTemp, 0, i)

         ' if Proc Def Line get new name, assumming it was changed

         If Not bFoundProcType And (InStr(sLine, "Sub ") > 0 Or InStr(sLine, "Function ") > 0) Then
            ' loop to get proc new name and new type
            ' when loop terminates, sNewName is the name
            bFoundProcType = True

            sTempLine = sLine
            Do While Trim$(sTempLine) <> ""
               sWord = Connect.GetToken(sTempLine, "")
               If sWord = "Sub" Then
                  sNewType = "Sub"
                  Exit Do
               ElseIf sWord = "Function" Then
                  sNewType = "Function"
                  Exit Do
               End If
            Loop
            sNewName = Connect.GetToken(sTempLine, "_")
         ElseIf bFoundProcType Then
            ' if the type changed, we must substitute the new type
            ' for the old type and change any functions name returns
            ' if new type is a function
            sLine = Replace(sLine, sOrigType, sNewType)
            sLine = Replace(sLine, sOrigName, sNewName)
         End If
GetNextLine:
         ' write the output string
         sTemp2 = sTemp2 & sLine & vbCrLf

      Next

      Me.txtProcToClone.Text = sTemp2
   End Sub

   Private Sub CloneProc_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      Me.txtProcToClone.Text = sTextSave
   End Sub

   Private Sub btnCopyToClipboard_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCopyToClipboard.Click
      Dim datobj As New System.Windows.Forms.DataObject()

      UpdateFunctionReturns()

      datobj.SetData(System.Windows.Forms.DataFormats.Text, txtProcToClone.Text)

      mbWait = False

   End Sub

   Private Sub btnPasteToModule_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPasteToModule.Click
      UpdateFunctionReturns()

      sTextSave = Me.txtProcToClone.Text
      mbWait = False
   End Sub

   Protected Overrides Sub Finalize()
      MyBase.Finalize()
   End Sub

   Private Sub CloneProc_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
      sTextSave = ""
      mbWait = False
   End Sub
End Class
