Imports Microsoft.Office.Core
imports Extensibility
imports System.Runtime.InteropServices
Imports EnvDTE

#Region " Read me for Add-in installation and setup information. "
' When run, the Add-in wizard prepared the registry for the Add-in.
' At a later time, if the Add-in becomes unavailable for reasons such as:
'   1) You moved this project to a computer other than which is was originally created on.
'   2) You chose 'Yes' when presented with a message asking if you wish to remove the Add-in.
'   3) Registry corruption.
' you will need to re-register the Add-in by building the MyAddinTest1Setup project 
' by right clicking the project in the Solution Explorer, then choosing install.
#End Region

<GuidAttribute("EA9E1DDF-0B64-4446-9E29-48DE0CC80523"), ProgIdAttribute("MyAddinTest1.Connect")> _
Public Class Connect
	
	Implements Extensibility.IDTExtensibility2
	Implements IDTCommandTarget
	
    Shared oVB As EnvDTE.DTE
    Shared CommentDelimiter As String = "'*"
    Shared UserName As String = "Les Smith"
    Shared TodaysDate As String

    Dim addInInstance as EnvDTE.AddIn
    ' moved to module level so OnDisconnect can see it
    Dim CommandObj As Command

    Public Sub OnBeginShutdown(ByRef custom As System.Array) Implements Extensibility.IDTExtensibility2.OnBeginShutdown
    End Sub

    Public Sub OnAddInsUpdate(ByRef custom As System.Array) Implements Extensibility.IDTExtensibility2.OnAddInsUpdate
    End Sub

    Public Sub OnStartupComplete(ByRef custom As System.Array) Implements Extensibility.IDTExtensibility2.OnStartupComplete
    End Sub

    Public Sub OnDisconnection(ByVal RemoveMode As _
               Extensibility.ext_DisconnectMode, _
               ByRef custom As System.Array) _
               Implements _
               Extensibility.IDTExtensibility2.OnDisconnection
        Try
            CommandObj.Delete()
            ' MsgBox("Disconnect, remove Tool Button", _
            '        MsgBoxStyle.Information, "MyAddinTest1")

        Catch e As System.Exception
            MsgBox("Error in Disconnect: " & _
                   e.Message, _
                   MsgBoxStyle.Critical, _
                   "MyAddinTest1")
        End Try
    End Sub

    Public Sub OnConnection(ByVal application As Object, ByVal connectMode As Extensibility.ext_ConnectMode, ByVal addInInst As Object, ByRef custom As System.Array) Implements Extensibility.IDTExtensibility2.OnConnection
        Dim iBitMap As Integer

        ' set up today's date for use in all methods
        TodaysDate = Format(Now(), "Long Date")

        oVB = CType(application, EnvDTE.DTE)
        addInInstance = CType(addInInst, EnvDTE.AddIn)
        If connectMode = Extensibility.ext_ConnectMode.ext_cm_AfterStartup Or _
           connectMode = Extensibility.ext_ConnectMode.ext_cm_Startup _
           Then
            Dim objAddIn As AddIn = CType(addInInst, AddIn)

            ' When run, the Add-in wizard prepared the registry for the Add-in.
            ' At a later time, the Add-in or its commands may become unavailable for reasons such as:
            '   1) You moved this project to a computer other than which is was originally created on.
            '   2) You chose 'Yes' when presented with a message asking if you wish to remove the Add-in.
            '   3) You add new commands or modify commands already defined.
            ' You will need to re-register the Add-in by building the MyAddinTest1Setup project,
            ' right-clicking the project in the Solution Explorer, and then choosing install.
            ' Alternatively, you could execute the ReCreateCommands.reg file the Add-in Wizard generated in
            ' the project directory, or run 'devenv /setup' from a command prompt.
            Try
                iBitMap = 59
                CommandObj = oVB.Commands.AddNamedCommand(objAddIn, _
                             "MyAddinTest1", "Smart Desktop", _
                             "Executes the command for MyAddinTest1", _
                             True, iBitMap, Nothing, 1 + 2) _
                             '1+2 == vsCommandStatusSupported+vsCommandStatusEnabled
                CommandObj.AddControl(oVB.CommandBars.Item("Tools"))
            Catch e As System.Exception
                MsgBox("Error in placing control: " & e.Message)
            End Try
        End If
    End Sub

    Public Sub Exec(ByVal cmdName As String, _
                    ByVal executeOption As vsCommandExecOption, _
                    ByRef varIn As Object, _
                    ByRef varOut As Object, _
                    ByRef handled As Boolean) _
                    Implements IDTCommandTarget.Exec
        Dim oFrm As New frmTreeView()

        handled = False
        If (executeOption = vsCommandExecOption.vsCommandExecOptionDoDefault) Then
            If cmdName = "MyAddinTest1.Connect.MyAddinTest1" Then
                handled = True
                ' MsgBox("You rang?")
                oFrm.Show()
                Exit Sub
            End If
        End If
    End Sub

    Public Sub QueryStatus(ByVal cmdName As String, _
               ByVal neededText As vsCommandStatusTextWanted, _
               ByRef statusOption As vsCommandStatus, _
               ByRef commandText As Object) _
               Implements IDTCommandTarget.QueryStatus
        If neededText = EnvDTE.vsCommandStatusTextWanted.vsCommandStatusTextWantedNone _
           Then
            If cmdName = "MyAddinTest1.Connect.MyAddinTest1" Then
                statusOption = CType(vsCommandStatus.vsCommandStatusEnabled + _
                               vsCommandStatus.vsCommandStatusSupported, vsCommandStatus)
            Else
                statusOption = vsCommandStatus.vsCommandStatusUnsupported
            End If
        End If
    End Sub

    Shared Sub OrigBlockComment()
        Dim selCodeBlock As TextSelection '= oVB.ActiveDocument.Selection()
        Dim sp As EditPoint '= selCodeBlock.TopPoint.CreateEditPoint()
        Dim ep As TextPoint '= selCodeBlock.BottomPoint
        Dim comntChr As String = "'"

        ' Option Strict does not allow implied conversion of an object
        Try
            oVB.UndoContext.Open("Block Comment")
            selCodeBlock = CType(oVB.ActiveDocument.Selection(), EnvDTE.TextSelection)
            sp = CType(selCodeBlock.TopPoint.CreateEditPoint(), EnvDTE.EditPoint)
            ep = CType(selCodeBlock.BottomPoint, EnvDTE.TextPoint)
            'ep = selCodeBlock.BottomPoint
        Catch
            MsgBox("Failed to set up text objects.", MsgBoxStyle.Critical)
            'set up an undo context for the whole commented block
        End Try

        Try
            sp.Insert("'* Block Commented by " & UserName & " on " & _
                Format(DateValue(CType(Today, String)), "mm/dd/yyyy") & vbCrLf)
            Do While (sp.Line < ep.Line)
                sp.Insert(comntChr)
                sp.LineDown()
                sp.StartOfLine()
            Loop
            sp.Insert("'* End of Block Commented by " & UserName & vbCrLf)
        Catch
            ' if error, clean up the undo context
            ' other wise the editor can be left in perpetual undo context
            oVB.UndoContext.Close()
        End Try
    End Sub

    Shared Sub BlockComment()
        Dim iNL As Integer ' number of lines in block
        Dim sIN As String ' input selection
        Dim sOUT As String ' commented output
        Dim i As Integer
        Dim n As Short ' number of chars before first non blank in first line
        Dim s As String

        Try
            ' Get selected text from active window
            sIN = GetCodeFromWindow()

            ' ensure the user selected something
            If sIN.Length < 1 Then
                MsgBox("Please select block to be commented.", _
                     vbExclamation, "BlockComment")
                Exit Sub
            End If
            ' get the number of lines in the text
            iNL = MLCount(sIN, 0)

            ' comment the block
            For i = 1 To iNL
                s = MemoLine(sIN, 0, i)
                If i = 1 Then
                    n = CountSpacesBeforeFirstChar(s)
                    sOUT = CType(IIf(n = 0, "", Space(n)), String) & _
                          "'* Block Commented by " & UserName & " on " & _
                          TodaysDate & vbCrLf
                End If

                sOUT = sOUT & Space(n) & CommentDelimiter & s & vbCrLf

            Next i

            ' now end the block
            sOUT = sOUT & CType(IIf(n = 0, "", Space(n)), String) & _
                  "'* End of Block Commented by " & UserName & vbCrLf

            ' now put the code back
            PutCodeBack(sOUT)
        Catch e As System.Exception
            MsgBox("Error: " & e.Message, vbCritical, "BlockComment")
        End Try
    End Sub

    Shared Sub BlockDelete()
        ' Insert a deletion comment block around a block
        ' that is about to be deleted
        Dim sCC As String
        Dim sText As String
        Dim sLine As String
        Dim i As Long
        Dim nL As Integer
        Dim sTmpText As String
        Dim liCnt As Integer
        ' get the selected code from the code window

        Try

            sText = GetCodeFromWindow()

            If Trim$(sText) = "" Then
                MsgBox("No deletion text selected!")
                Exit Sub
            End If

            ' we have the text that is to be deleted
            ' comment it to delete it
            sTmpText = ""
            nL = MLCount(sText, 0)

            For i = 1 To nL
                sLine = MemoLine(sText, 0, i)
                If i = 1 Then
                    liCnt = CountSpacesBeforeFirstChar(sLine)
                End If
                sTmpText = sTmpText & IIf(liCnt > 0, Space(liCnt), "") _
                       & "'* " & sLine & vbCrLf
            Next i

            sCC = IIf(liCnt > 0, Space(liCnt), "") & CommentDelimiter & _
                   " Block Deleted by " & UserName & " on " & _
                   TodaysDate & vbCrLf
            sCC = sCC & sTmpText
            sCC = sCC & IIf(liCnt > 0, Space(liCnt), "") & CommentDelimiter & _
                 " End of Block Deleted by " & UserName & " on " & _
                 TodaysDate & vbCrLf

            PutCodeBack(sCC)
        Catch e As System.Exception
            MsgBox("Error in Block Delete: " & e.Message)
        End Try
        Exit Sub
    End Sub

    Shared Sub BlockChange()
        Dim sText As String
        Dim sCC As String
        Dim liCnt As Integer
        Dim lsLine As String

        Try
            sText = GetCodeFromWindow()

            If Trim$(sText) = "" Then
                MsgBox("No change text selected!")
                Exit Sub
            End If
            liCnt = MLCount(sText, 0)
            If liCnt > 0 Then
                lsLine = MemoLine(sText, 0, 1)
                liCnt = CountSpacesBeforeFirstChar(lsLine)
            Else
                liCnt = 0
            End If

            sCC = vbCrLf & IIf(liCnt > 0, Space(liCnt), "") & CommentDelimiter & _
                 " Block Changed by " & UserName & " on " & TodaysDate & vbCrLf
            sCC = sCC & sText & vbCrLf
            sCC = sCC & IIf(liCnt > 0, Space(liCnt), "") & CommentDelimiter & _
                  " End of Block Changed by " & UserName & " on " & _
                  TodaysDate & vbCrLf & vbCrLf

            PutCodeBack(sCC)

            Exit Sub
        Catch e As System.Exception
            MsgBox("Error in Block Change: " & e.Message)
        End Try
    End Sub

    Shared Sub BlockUnComment()
        Dim iNL As Integer ' number of lines in block
        Dim sIN As String ' input selection
        Dim sOUT As String ' commented output
        Dim i As Integer
        Dim n As Short ' number of chars before first non blank in first line
        Dim n2 As Short ' nbr chars before first nb char subsequent lines
        Dim s As String
        Dim lsCD As String = "'* "

        Try
            ' Get selected text from active window
            sIN = GetCodeFromWindow()

            ' ensure the user selected something
            If sIN.Length < 1 Then
                MsgBox("Please select block to be commented.", _
                     vbExclamation, "BlockComment")
                Exit Sub
            End If
            ' get the number of lines in the text
            iNL = MLCount(sIN, 0)

            ' comment the block
            For i = 1 To iNL
                s = MemoLine(sIN, 0, i)
                ' check the uncommented code, it is leaving it to the left margin
                ' look for commented lines
                Select Case True
               Case Left(Trim(s), 8) = "'* Block"
                  ' comment header, dont write to output
               Case Left(Trim(s), 15) = "'* End of Block"
                  ' comment footer, dont write to output
               Case Left(Trim(s), 3) = lsCD
                  sOUT = sOUT & Replace(s, lsCD, "", , 1) & vbCrLf
               Case Left(Trim(s), 1) = "'"
                  sOUT = sOUT & Replace(s, lsCD, "", , 1) & vbCrLf
            End Select
            Next i

            ' now put the code back
            PutCodeBack(sOUT)

        Catch e As System.Exception
            MsgBox("Error: " & e.Message, vbCritical, "BlockUnComment")
        End Try
    End Sub

    Shared Sub GenLocalErrorTrap()
        Dim sLine As String
        Dim sTemp As String
        Dim sTemp2 As String
        Dim sWord As String
        Dim i As Long
        Dim nL As Integer
        Dim bFound As Boolean
        Dim sTempLine As String
        Dim sProcType As String
        Dim sProcName As String
        Dim bFoundDefLine As Boolean
        Const EM = "   MsgBox(Error in "

        Try
            sTemp = GetCodeFromWindow()

            sTemp2 = ""

            nL = MLCount(sTemp, 0)
            bFound = False

            For i = 1 To nL

                ' look for the first line of code
                sLine = MemoLine(sTemp, 0, i)

                ' get the procname to make the goto label unique
                If Not bFoundDefLine Then
                    If InStr(sLine, "Sub ") > 0 Then
                        sProcType = "Sub"
                    ElseIf InStr(sLine, "Function ") > 0 Then
                        sProcType = "Function"
                    Else
                        sTemp2 = sTemp2 & sLine & vbCrLf
                        GoTo JustOutPutThisLine
                    End If
                    bFoundDefLine = True
                    sTempLine = sLine
                    Do While Trim$(sTempLine) <> ""
                        sWord = GetToken(sTempLine, "_")
                        ' when we find the Proc type, term the loop
                        ' and retrieve the name next below
                        If sWord = "Sub" Or sWord = "Function" Then Exit Do
                        If Trim$(sWord) = "" Then Exit Do
                        sProcName = sWord
                    Loop
                    sProcName = GetToken(sTempLine, "_")
                End If

                If Not bFound Then
                    If InStr(sLine, "Sub ") > 0 Or _
                       InStr(sLine, "Function ") > 0 Or _
                       InStr(sLine, "Global ") > 0 Or _
                       InStr(sLine, "Const ") > 0 Or _
                       InStr(sLine, "Dim ") > 0 Then
                        sTemp2 = sTemp2 & sLine & vbCrLf
                    ElseIf Left$(Trim$(sLine), 1) = "'" Then
                        sTemp2 = sTemp2 & sLine & vbCrLf
                    ElseIf Trim$(sLine) = "" Then
                        sTemp2 = sTemp2 & sLine & vbCrLf
                    Else
                        bFound = True
                        sTemp2 = sTemp2 & vbCrLf & "      Try" & vbCrLf
                        If Trim$(sLine) <> "End " & sProcType Then
                            sTemp2 = sTemp2 & sLine & vbCrLf
                        Else
                            sTemp2 = sTemp2 & "      Catch e as System.Exception" & vbCrLf
                            sTemp2 = sTemp2 & "         MsgBox(" & Chr(34) & "Error in " & _
                                     sProcName & ": " & Chr(34) & " & e.Message)" & vbCrLf
                            sTemp2 = sTemp2 & "      End Try" & vbCrLf
                            sTemp2 = sTemp2 & sLine & vbCrLf
                        End If
                    End If
                Else

                    If InStr(sLine, "End " & sProcType) > 0 Then
                        sTemp2 = sTemp2 & "      Catch e as System.Exception" & vbCrLf
                        sTemp2 = sTemp2 & "         MsgBox(" & Chr(34) & "Error in " & _
                                 sProcName & ": " & Chr(34) & " & e.Message)" & vbCrLf
                        sTemp2 = sTemp2 & "      End Try" & vbCrLf
                        sTemp2 = sTemp2 & sLine & vbCrLf
                        Exit For
                    Else
                        sTemp2 = sTemp2 & sLine & vbCrLf
                    End If
                End If
JustOutPutThisLine:
            Next

            ' now the proc with err code added is ready to paste
            PutCodeBack(sTemp2)
            Exit Sub
        Catch e As System.Exception
            MsgBox("Error in GenLocalErrorTrap: " & e.Message)
        End Try
    End Sub

    Shared Function GetToken(ByRef srcline As String, _
                             ByVal rsNonDelimiters As String, _
                             Optional ByVal rsDel As String = "N") _
                             As String
        '-----
        ' If rsDel = "N" then the rsNondelimiters is a list of non delimters
        ' which is added to a list of AN Chars (a-z, A-Z, 0-9), which are
        ' always assumed to be non delimiters.
        ' If rsDel="D" then rsNonDelimiters is the list of delimiters, anything
        ' else in the string is assumed to be non deliter.
        ' Get Next word from srcLine.  An alphanumeric and any character
        ' found in strDelimtrs is a valid char for the word.  i.e. a char
        ' which is not alphanumeric and not found in the delimiter string
        ' will terminate the word.  If space is not a delimiter it must be
        ' included in the strNonDelimitrs.
        ' Typicall call is:
        '     srcLine = GetToken(srcLine, " ().!" or
        '     srcLine = GetToken(srcLine, " ,") where space and comma are the delimiters.
        ' Any non alphanumeric and not in the " ().!" would terminate the string
        ' To include " in the set of allowable chars, concatenate chr(34) with the
        ' other non delimiters.
        ' If non delimiters are not supplied, dont compare for them
        ' and performance is increased...
        '-----
        Dim n_w As String ' staging area for return string
        Dim FC As String ' first char of string
        Dim lsTemp As String
        Dim lsTemp2 As String
        Const AN_DIGITS = "abcdefghijklmnopqrstuvwxyz" & _
                          "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
        Try
            n_w = ""
            If rsDel = "N" Then
                lsTemp2 = AN_DIGITS & rsNonDelimiters
            Else
                lsTemp2 = rsNonDelimiters
            End If

            Do While Trim$(srcline) <> ""
                FC = Left$(srcline, 1)
                lsTemp = "*" & FC & "*"
                If rsDel = "N" Then
                    If Not (lsTemp2 Like lsTemp) Then
                        srcline = Mid(srcline, 2) ' save all but first char for next call
                        If Trim$(n_w) <> "" Then
                            GetToken = n_w
                            Exit Function
                        End If
                    Else
                        n_w = n_w & FC
                        srcline = Mid(srcline, 2)
                    End If
                Else
                    If (lsTemp2 Like lsTemp) Then
                        srcline = Mid(srcline, 2) ' save all but first char for next call
                        If Trim$(n_w) <> "" Then
                            GetToken = n_w
                            Exit Function
                        End If
                    Else
                        n_w = n_w & FC
                        srcline = Mid(srcline, 2)
                    End If
                End If
            Loop

            GetToken = n_w
            Exit Function
        Catch e As System.Exception
            MsgBox("Error in GetToken: " & e.Message)
            GetToken = n_w
        End Try
    End Function

    Shared Function GetCodeFromWindow() As String
        Dim s As String
        Dim selCodeBlock As TextSelection '= oVB.ActiveDocument.Selection()

        Try
            selCodeBlock = CType(oVB.ActiveDocument.Selection(), EnvDTE.TextSelection)
            GetCodeFromWindow = selCodeBlock.Text
        Catch e As System.Exception
            MsgBox("Error: " & e.Message, MsgBoxStyle.Critical, "GetCodeFromWindow")
        End Try
    End Function
   Shared Sub AddMethodToEndOfDocument(ByVal NewMethod As String)
      Dim objTD As TextDocument = oVB.ActiveDocument.Object
      Dim objEP As EditPoint = objTD.EndPoint.CreateEditPoint

      ' We are past the end of the last line of the document
      ' move back in front of the End Module/Class
      objEP.LineUp(1)
      objEP.Insert(NewMethod)
   End Sub

   Shared Sub PutCodeBack(ByVal s As String)
      Dim selCodeBlock As TextSelection
      Dim datobj As New System.Windows.Forms.DataObject()

      Try
         selCodeBlock = CType(oVB.ActiveDocument.Selection(), EnvDTE.TextSelection)
         datobj.SetData(System.Windows.Forms.DataFormats.Text, s)
         System.Windows.Forms.Clipboard.SetDataObject(datobj)

         selCodeBlock.Paste()

      Catch e As System.Exception
         MsgBox("Could not put code back in window.", _
              MsgBoxStyle.Critical, _
              "PutCodeBackInWindow")
      End Try
   End Sub

   Shared Function CountSpacesBeforeFirstChar(ByVal sIN As String) As Short
      ' Return the number of spaces before the first non blank character
      Dim iSpCnt As Short = 0
      Try
         For iSpCnt = 0 To CType(sIN.Length - 1, Short)
            If Mid$(sIN, iSpCnt + 1, 1) <> " " Then
               Return iSpCnt
            End If
         Next iSpCnt
      Catch
         CountSpacesBeforeFirstChar = iSpCnt
      End Try
   End Function

   Shared Function MLCount(ByVal cStrng As String, ByVal nL As Integer) As Integer
      '-----
      ' VB Replacement for Clipper MLCount Function
      ' It does handle word wrap, nL is the max char
      ' count per line.
      '-----
      Dim nStptr As Integer, nLenStr As Integer, nLineCtr As Integer
      Dim sTemp As String
      Dim i As Integer

      ' nStPtr is the pointer to position in cStrng

      Try
         nStptr = 1
         nLenStr = Len(cStrng)
         nLineCtr = 0

         While True
            ' If the pointer to the beginning of the next line
            ' is >= the length of the string, we are outta here!
            If nStptr >= nLenStr Then
               Return nLineCtr
               Exit Function
            End If

            ' Get the next line, not to exceed the length of nL
            ' if nL was greater than 0
            If nL > 0 Then
               sTemp = Mid$(cStrng, nStptr, nL)
               If InStr(sTemp, vbCrLf) > 0 Then
                  ' there is a CRLF in the string
                  sTemp = Left$(sTemp, InStr(sTemp, vbCrLf) - 1)
                  nStptr = nStptr + Len(sTemp) + 2
               Else
                  ' new code to handle lines with no crlf
                  If Len(sTemp) = nL Then
                     ' we have a full line left (at least)
                     i = InStrRev(" ", sTemp)
                     ' truncate the partial word from the end
                     sTemp = Left$(sTemp, i - 1)
                     'set the pointer to start the next line at
                     'current start point + len(stemp)
                     nStptr = nStptr + Len(sTemp)
                  Else
                     ' this is the last line, because the string is
                     ' shorter than the nL length
                     Return nLineCtr + 1
                     Exit Function
                  End If
               End If
            Else
               ' nL was supplied as 0 meaning we just look for CRLf
               nStptr = InStr(nStptr, cStrng, vbCrLf) + 2
            End If

            ' if the ptr = 2 then there was no crlf in the line
            If nStptr = 2 Then
               Return nLineCtr + 1
            End If

            nLineCtr = nLineCtr + 1
            If nStptr + 1 > nLenStr Then
               Return nLineCtr
            End If
         End While
         Exit Function
      Catch e As System.Exception
         MsgBox("Error: " & e.Message, vbCritical, "MLCount")
      End Try
   End Function
   Shared Function MemoLine(ByVal cStrng As String, _
            ByVal nLL As Integer, ByVal nL As Integer) As String
      '-----
      ' VB Replacement for Clipper MemoLine() Function.
      ' Handles Word Wrap.  nLL is the max char/line.
      ' Note that if the user asks for a line that is beyond the
      ' end of the string, i.e. more lines than are in the string
      ' unpredictable results will be returned, assuming we
      ' return at all.  Therefore, MLCount() must be called
      ' before calling MemoLine() and MemoLine must not be called
      ' to return a line numbered higher than MLCount() returened.
      '-----

      Static nStptr As Integer
      Dim i As Integer
      Dim nTmpPtr As Integer
      Dim sTemp As String
      Dim nPrevStPtr As Integer
      Dim lFoundSpace As Integer
      Static j As Integer
      Dim iST As Integer

      Try
         ' if NL is 1 > than J then
         ' this is a subsequent call to get the next
         ' line
         If nL = 1 Then
            nStptr = 1
            iST = 1
         ElseIf (nL - (j - 1) = 1) And (j <> 0) Then
            iST = nL
         Else
            nStptr = 1
            iST = 1
         End If

         ' Loop through the string until we find the requested line.
         For j = iST To nL
            ' Remembering where the previous line started will allow
            ' us to know where the requested line began when we have gone
            ' just past it with the following loop
            nPrevStPtr = nStptr
            ' Get the next line, not to exceed the length of nLL
            ' if nL was greater than 0
            If nLL = 0 Then
               ' nL was supplied as 0 meaning we just look for CRLf
               nStptr = InStr(nStptr, cStrng, Chr(13) & Chr(10)) + 2
            Else
               sTemp = Mid$(cStrng, nStptr, nLL)
               If InStr(sTemp, Chr(13) & Chr(10)) > 0 Then
                  ' there is a CRLF in the string
                  sTemp = Left$(sTemp, InStr(sTemp, Chr(13) & Chr(10)) - 1)
                  nStptr = nStptr + Len(sTemp) + 2
               Else
                  ' new code to handle lines with no crlf
                  If Len(sTemp) = nLL Then
                     ' we have a full line left with no crlf
                     ' find last space
                     i = InStrRev(" ", sTemp)

                     ' truncate the partial word from the end
                     sTemp = Left$(sTemp, i - 1)

                     ' set the pointer to start the next line  at current
                     ' start point + len(stemp)
                     nStptr = nStptr + Len(sTemp)
                  End If
               End If
            End If
         Next j

         ' nStPtr is now positioned to the end of the requested line
         ' Now find the end of the current (requested) line.

         If nLL = 0 Then
            If nStptr = 2 Then
               Return Mid$(cStrng, nPrevStPtr)
            Else
               Return Mid(cStrng, nPrevStPtr, nStptr - (nPrevStPtr + 2))
            End If
         Else
            Return Trim$(sTemp)
         End If

         Exit Function
      Catch e As System.Exception
         MsgBox("Error: " & e.Message, vbCritical, "MemoLine")
      End Try
   End Function
   Shared Sub CloneProcedure()
      Dim s As String
      Dim i As Integer
      Dim rs As String

      Try
         ' get selected proc from active window
         s = GetCodeFromWindow()

         If InStr(1, s, " Sub ", 0) = 0 And _
            InStr(1, s, " Function ", CompareMethod.Binary) = 0 Then
            MsgBox("Please select a whole Procedure to be cloned.", MsgBoxStyle.Exclamation)
            Exit Sub
         End If
         Dim oFrm As New CloneProc()
         rs = oFrm.Display(s)
         oFrm.Dispose()
         If rs <> "" Then
            AddMethodToEndOfDocument(rs)
         End If
      Catch e As System.Exception
         'MsgBox("Error: " & e.Message, MsgBoxStyle.Critical, "Clone Procedure")
         Exit Sub
      End Try
   End Sub
End Class
