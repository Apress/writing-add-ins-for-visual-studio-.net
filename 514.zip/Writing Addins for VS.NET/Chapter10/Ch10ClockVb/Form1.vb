Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
      Timer1.Start()
      ResetClock()
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents Timer1 As System.Windows.Forms.Timer
   Friend WithEvents lblTime As System.Windows.Forms.Label
   Friend WithEvents lblDate As System.Windows.Forms.Label
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.components = New System.ComponentModel.Container()
      Me.lblTime = New System.Windows.Forms.Label()
      Me.lblDate = New System.Windows.Forms.Label()
      Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
      Me.SuspendLayout()
      '
      'lblTime
      '
      Me.lblTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.lblTime.Location = New System.Drawing.Point(24, 24)
      Me.lblTime.Name = "lblTime"
      Me.lblTime.Size = New System.Drawing.Size(216, 32)
      Me.lblTime.TabIndex = 0
      Me.lblTime.Text = "Label1"
      Me.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'lblDate
      '
      Me.lblDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.lblDate.Location = New System.Drawing.Point(24, 72)
      Me.lblDate.Name = "lblDate"
      Me.lblDate.Size = New System.Drawing.Size(216, 32)
      Me.lblDate.TabIndex = 1
      Me.lblDate.Text = "Label2"
      Me.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
      '
      'Timer1
      '
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(264, 125)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblDate, Me.lblTime})
      Me.Name = "Form1"
      Me.Text = "My VB Clock"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub Timer1_Tick(ByVal sender As System.Object, _
                           ByVal e As System.EventArgs) _
                           Handles Timer1.Tick
      ResetClock()
   End Sub
   Protected Sub ResetClock()
      Dim s As String = Now.ToString()
      Dim i As Short = s.IndexOf(" ")
      Me.lblTime.Text = s.Substring(i + 1)
      Me.lblDate.Text = s.Substring(0, i)
   End Sub
End Class
