Imports Extensibility
Imports EnvDTE

Public Class VBClass
   Public Sub HelloWorld(ByVal appObject As EnvDTE._DTE)
      MsgBox("Hello World from VB DLL called by C# Add-in." & _
             Chr(10) & "IDE Instance: " & appObject.Name)
   End Sub
End Class
