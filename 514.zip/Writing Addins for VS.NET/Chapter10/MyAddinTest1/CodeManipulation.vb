Imports Microsoft.Office.Core
Imports Extensibility
Imports System.Runtime.InteropServices
Imports EnvDTE

Public Class CodeManipulation
   Shared CommentDelimiter As String = "'*"
   Shared UserName As String = "Les Smith"
   Shared TodaysDate As String
   Public oVB As DTE
   Const UnknownDoc = "Unrecognizible document type."
   Const DocVB = 8
   Const DocCSharp = 9
   Const DocCPP = 1

   Private sCommentChar As String

   Public Sub BlockComment()
      Dim iNL As Integer ' number of lines in block
      Dim sIN As String ' input selection
      Dim sOUT As String ' commented output
      Dim i As Integer
      Dim n As Short ' number of chars before first non blank in first line
      Dim s As String
      Dim oUtil As New Utilities(oVB)

      Try
         sCommentChar = oUtil.GetCommentCharForDoc(oVB.ActiveDocument)
         If Len(sCommentChar) = 0 Then
            MsgBox(UnknownDoc)
            Exit Sub
         End If

         ' Get selected text from active window
         sIN = oUtil.GetCodeFromWindow()

         ' ensure the user selected something
         If sIN.Length < 1 Then
            MsgBox("Please select block to be commented.", _
                 vbExclamation, "BlockComment")
            Exit Sub
         End If
         ' get the number of lines in the text
         iNL = oUtil.MLCount(sIN, 0)

         ' comment the block
         For i = 1 To iNL
            s = oUtil.MemoLine(sIN, 0, i)
            If i = 1 Then
               n = oUtil.CountSpacesBeforeFirstChar(s)
               sOUT = CType(IIf(n = 0, "", Space(n)), String) & _
                     sCommentChar & " Block Commented by " & UserName & " on " & _
                     TodaysDate & vbCrLf
            End If

            sOUT = sOUT & Space(n) & sCommentChar & s & vbCrLf

         Next i

         ' now end the block
         sOUT = sOUT & CType(IIf(n = 0, "", Space(n)), String) & _
               sCommentChar & " End of Block Commented by " & UserName & vbCrLf

         ' now put the code back
         oUtil.PutCodeBack(sOUT)
      Catch e As System.Exception
         MsgBox("Error: " & e.Message, vbCritical, "BlockComment")
      End Try
      oUtil = Nothing
   End Sub

   Public Sub BlockDelete()
      ' Insert a deletion comment block around a block
      ' that is about to be deleted
      Dim sCC As String
      Dim sText As String
      Dim sLine As String
      Dim i As Long
      Dim nL As Integer
      Dim sTmpText As String
      Dim liCnt As Integer
      Dim oUtil As New Utilities(oVB)
      ' get the selected code from the code window

      Try
         sCommentChar = oUtil.GetCommentCharForDoc(oVB.ActiveDocument)
         If Len(sCommentChar) = 0 Then
            MsgBox(UnknownDoc)
            Exit Sub
         End If

         sText = oUtil.GetCodeFromWindow()

         If Trim$(sText) = "" Then
            MsgBox("No deletion text selected!")
            Exit Sub
         End If

         ' we have the text that is to be deleted
         ' comment it to delete it
         sTmpText = ""
         nL = oUtil.MLCount(sText, 0)

         For i = 1 To nL
            sLine = oUtil.MemoLine(sText, 0, i)
            If i = 1 Then
               liCnt = oUtil.CountSpacesBeforeFirstChar(sLine)
            End If
            sTmpText = sTmpText & IIf(liCnt > 0, Space(liCnt), "") _
                   & sCommentChar & " " & sLine & vbCrLf
         Next i

         sCC = IIf(liCnt > 0, Space(liCnt), "") & sCommentChar & _
                " Block Deleted by " & UserName & " on " & _
                TodaysDate & vbCrLf
         sCC = sCC & sTmpText
         sCC = sCC & IIf(liCnt > 0, Space(liCnt), "") & sCommentChar & _
              " End of Block Deleted by " & UserName & " on " & _
              TodaysDate & vbCrLf

         oUtil.PutCodeBack(sCC)
      Catch e As System.Exception
         MsgBox("Error in Block Delete: " & e.Message)
      End Try
      oUtil = Nothing
      Exit Sub
   End Sub

   Public Sub BlockChange()
      Dim sText As String
      Dim sCC As String
      Dim liCnt As Integer
      Dim lsLine As String
      Dim oUtil As New Utilities(oVB)

      Try
         sCommentChar = oUtil.GetCommentCharForDoc(oVB.ActiveDocument)
         If Len(sCommentChar) = 0 Then
            MsgBox(UnknownDoc)
            Exit Sub
         End If

         sText = oUtil.GetCodeFromWindow()

         If Trim$(sText) = "" Then
            MsgBox("No change text selected!")
            Exit Sub
         End If
         liCnt = oUtil.MLCount(sText, 0)
         If liCnt > 0 Then
            lsLine = oUtil.MemoLine(sText, 0, 1)
            liCnt = oUtil.CountSpacesBeforeFirstChar(lsLine)
         Else
            liCnt = 0
         End If

         sCC = vbCrLf & IIf(liCnt > 0, Space(liCnt), "") & sCommentChar & _
              " Block Changed by " & UserName & " on " & TodaysDate & vbCrLf
         sCC = sCC & sText & vbCrLf
         sCC = sCC & IIf(liCnt > 0, Space(liCnt), "") & sCommentChar & _
               " End of Block Changed by " & UserName & " on " & _
               TodaysDate & vbCrLf & vbCrLf

         oUtil.PutCodeBack(sCC)

         Exit Sub
      Catch e As System.Exception
         MsgBox("Error in Block Change: " & e.Message)
      End Try
      oUtil = Nothing
   End Sub

   Public Sub BlockUnComment()
      Dim iNL As Integer ' number of lines in block
      Dim sIN As String ' input selection
      Dim sOUT As String ' commented output
      Dim i As Integer
      Dim n As Short ' number of chars before first non blank in first line
      Dim n2 As Short ' nbr chars before first nb char subsequent lines
      Dim s As String
      Dim lsCD As String
      Dim oUtil As New Utilities(oVB)

      Try
         sCommentChar = oUtil.GetCommentCharForDoc(oVB.ActiveDocument)
         If Len(sCommentChar) = 0 Then
            MsgBox(UnknownDoc)
            Exit Sub
         End If
         lsCD = sCommentChar & " "

         ' Get selected text from active window
         sIN = oUtil.GetCodeFromWindow()

         ' ensure the user selected something
         If sIN.Length < 1 Then
            MsgBox("Please select block to be commented.", _
                 vbExclamation, "BlockComment")
            Exit Sub
         End If
         ' get the number of lines in the text
         iNL = oUtil.MLCount(sIN, 0)

         ' comment the block
         For i = 1 To iNL
            s = oUtil.MemoLine(sIN, 0, i)
            ' check the uncommented code, it is leaving it to the left margin
            ' look for commented lines
            Select Case True
               Case Left(Trim(s), 8) = sCommentChar & " Block"
                  ' comment header, dont write to output
               Case Left(Trim(s), 15) = sCommentChar & " End of Block"
                  ' comment footer, dont write to output
               Case Left(Trim(s), 3) = lsCD
                  sOUT = sOUT & Replace(s, lsCD, "", , 1) & vbCrLf
               Case Left(Trim(s), 1) = "'"
                  sOUT = sOUT & Replace(s, lsCD, "", , 1) & vbCrLf
            End Select
         Next i

         ' now put the code back
         oUtil.PutCodeBack(sOUT)

      Catch e As System.Exception
         MsgBox("Error: " & e.Message, vbCritical, "BlockUnComment")
      End Try
      oUtil = Nothing
   End Sub

   Public Sub GenLocalErrorTrap()
      Dim sLine As String
      Dim sTemp As String
      Dim sTemp2 As String
      Dim sWord As String
      Dim i As Long
      Dim nL As Integer
      Dim bFound As Boolean
      Dim sTempLine As String
      Dim sProcType As String
      Dim sProcName As String
      Dim bFoundDefLine As Boolean
      Const EM = "   MsgBox(Error in "
      Dim oUtil As New Utilities(oVB)

      Try
         If oUtil.GetFileType(oVB.ActiveDocument) <> DocVB Then
            MsgBox("GenLocalErrorTrap only works for VB Code.")
            Exit Sub
         End If
         sTemp = oUtil.GetCodeFromWindow()

         sTemp2 = ""

         nL = oUtil.MLCount(sTemp, 0)
         bFound = False

         For i = 1 To nL

            ' look for the first line of code
            sLine = oUtil.MemoLine(sTemp, 0, i)

            ' get the procname to make the goto label unique
            If Not bFoundDefLine Then
               If InStr(sLine, "Sub ") > 0 Then
                  sProcType = "Sub"
               ElseIf InStr(sLine, "Function ") > 0 Then
                  sProcType = "Function"
               Else
                  sTemp2 = sTemp2 & sLine & vbCrLf
                  GoTo JustOutPutThisLine
               End If
               bFoundDefLine = True
               sTempLine = sLine
               Do While Trim$(sTempLine) <> ""
                  sWord = oUtil.GetToken(sTempLine, "_")
                  ' when we find the Proc type, term the loop
                  ' and retrieve the name next below
                  If sWord = "Sub" Or sWord = "Function" Then Exit Do
                  If Trim$(sWord) = "" Then Exit Do
                  sProcName = sWord
               Loop
               sProcName = oUtil.GetToken(sTempLine, "_")
            End If

            If Not bFound Then
               If InStr(sLine, "Sub ") > 0 Or _
                  InStr(sLine, "Function ") > 0 Or _
                  InStr(sLine, "Global ") > 0 Or _
                  InStr(sLine, "Const ") > 0 Or _
                  InStr(sLine, "Dim ") > 0 Then
                  sTemp2 = sTemp2 & sLine & vbCrLf
               ElseIf Left$(Trim$(sLine), 1) = "'" Then
                  sTemp2 = sTemp2 & sLine & vbCrLf
               ElseIf Trim$(sLine) = "" Then
                  sTemp2 = sTemp2 & sLine & vbCrLf
               Else
                  bFound = True
                  sTemp2 = sTemp2 & vbCrLf & "      Try" & vbCrLf
                  If Trim$(sLine) <> "End " & sProcType Then
                     sTemp2 = sTemp2 & sLine & vbCrLf
                  Else
                     sTemp2 = sTemp2 & "      Catch e as System.Exception" & vbCrLf
                     sTemp2 = sTemp2 & "         MsgBox(" & Chr(34) & "Error in " & _
                              sProcName & ": " & Chr(34) & " & e.Message)" & vbCrLf
                     sTemp2 = sTemp2 & "      End Try" & vbCrLf
                     sTemp2 = sTemp2 & sLine & vbCrLf
                  End If
               End If
            Else

               If InStr(sLine, "End " & sProcType) > 0 Then
                  sTemp2 = sTemp2 & "      Catch e as System.Exception" & vbCrLf
                  sTemp2 = sTemp2 & "         MsgBox(" & Chr(34) & "Error in " & _
                           sProcName & ": " & Chr(34) & " & e.Message)" & vbCrLf
                  sTemp2 = sTemp2 & "      End Try" & vbCrLf
                  sTemp2 = sTemp2 & sLine & vbCrLf
                  Exit For
               Else
                  sTemp2 = sTemp2 & sLine & vbCrLf
               End If
            End If
JustOutPutThisLine:
         Next

         ' now the proc with err code added is ready to paste
         oUtil.PutCodeBack(sTemp2)
         oUtil = Nothing
         Exit Sub
      Catch e As System.Exception
         MsgBox("Error in GenLocalErrorTrap: " & e.Message)
      End Try
   End Sub


   Public Sub CloneProcedure()
      Dim s As String
      Dim i As Integer
      Dim rs As String
      Dim oUtil As New Utilities(oVB)
      Dim iFileType As Short
      Try
         'If oUtil.GetFileType(oVB.ActiveDocument) <> DocVB Then
         'MsgBox("Clone Procedure only handles VB Procedures.")
         'Exit Sub
         'End If

         ' get selected proc from active window
         iFileType = oUtil.GetFileType(oVB.ActiveDocument)
         If iFileType = DocVB Then
            s = oUtil.GetWholeProc()
         Else
            s = oUtil.GetCodeFromWindow()
         End If

         If s = "" Then Exit Sub
         If iFileType = DocVB Then
            If InStr(1, s, " Sub ", 0) = 0 And _
               InStr(1, s, " Function ", CompareMethod.Binary) = 0 Then
               MsgBox("Please select a whole Procedure to be cloned.", MsgBoxStyle.Exclamation)
               Exit Sub
            End If
         End If

         Dim oFrm As New CloneProc(oVB)
         rs = oFrm.Display(s)
         oFrm.Dispose()
         If rs <> "" Then
            oUtil.AddMethodToEndOfDocument(rs)
         End If
      Catch e As System.Exception
         MsgBox("Error: " & e.Message, MsgBoxStyle.Critical, "Clone Procedure")
         Exit Sub
      End Try
      oUtil = Nothing
   End Sub
   Public Sub DocTemplate()
      ' copy the sub line , insert the Doc Template
      ' copy the remainder of the sub, paste it back
      ' to the codewindow
      Dim i As Long
      Dim iPtr As Integer
      Dim nL As Integer
      Dim bParameters As Boolean
      Dim bPurpose As Boolean
      Dim sOut As String
      Dim sLine As String
      Dim bFoundSub As Boolean
      Dim sDocTemplate As String
      Dim sWord As String
      Dim sTempParams As String
      Dim cComStr As String
      Dim sPar As String
      Dim sRetVal As String
      Dim sProcToCopy As String
      Dim sProcType As String
      Dim j As Integer
      Dim k As Integer
      Const sPurpose = "Purpose:"
      Const sParameters = "Parameters:"
      Const sDateCreated = "Date Created:"
      Const sAuthor = "Author:"
      Const sUserName = "Les Smith"
      Const sCopyright = "Copyright:"
      Const sCompanyName = "HHI Software, Inc."
      Const sReturns = "Returns:"
      Dim s As String
      Dim oUtil As New Utilities(oVB)

      Try
         ' create the doc template
         ' In a production add-in this would be read from a file
         ' so that the file could be customized...
         s = "'***************************************" & vbCrLf
         s = s & "'* Name: ProcName" & vbCrLf
         s = s & "'* Purpose:" & vbCrLf
         s = s & "'*" & vbCrLf
         s = s & "'* " & vbCrLf
         s = s & "'* Parameters:" & vbCrLf
         s = s & "'*" & vbCrLf
         s = s & "'* Returns:" & vbCrLf
         s = s & "'*" & vbCrLf
         s = s & "'* Author: " & vbCrLf
         s = s & "'* Date Created:" & vbCrLf
         s = s & "'* CopyRight: " & vbCrLf
         s = s & "'* Date Last Changed: " & vbCrLf
         s = s & "'***************************************" & vbCrLf
         sDocTemplate = s

         ' if user selected the text prior to clicking the
         ' button, get that code

         sProcToCopy = ""
         sProcToCopy = oUtil.GetWholeProc()

         sOut = ""
         sDocTemplate = ""

         bFoundSub = False


         ' find out some stuff about the template
         bPurpose = (InStr(1, sDocTemplate, sPurpose, 1) > 1)
         bParameters = (InStr(1, sDocTemplate, sParameters, 1) > 1)

         nL = oUtil.MLCount(sProcToCopy, 0)
         cComStr = ""

         For i = 1 To nL
            sLine = oUtil.MemoLine(sProcToCopy, 0, i)
            If Not bFoundSub Then
               If InStr(sLine, "Sub ") > 0 Or _
                  InStr(sLine, "Function ") > 0 Then
                  sOut = sOut & sLine & vbCrLf
                  bFoundSub = True

                  ' get sub name
                  Do While Trim$(sLine) <> ""
                     sWord = oUtil.GetToken(sLine, "")
                     If InStr("Sub_Function", sWord) > 0 Then Exit Do
                     sProcType = sWord
                  Loop

                  ' get sub name
                  sWord = oUtil.GetToken(sLine, "_")

                  'get parameters if applicable
                  If bParameters Then
                     sRetVal = ""
                     sTempParams = ""
                     j = oUtil.CountOccurrences(",", sLine)
                     For k = 1 To j
                        ' the next parm
                        sPar = Left$(sLine, InStr(sLine, ",") - 1)
                        ' remove it from sline
                        sLine = Mid$(sLine, InStr(sLine, ",") + 1)
                        sTempParams = sTempParams & "'*   " & _
                                      Trim(sPar) & vbCrLf
                     Next k
                     ' get last parm
                     k = InStr(sLine, ")") - 1
                     If k > 0 Then
                        sPar = Left$(sLine, InStr(sLine, ")") - 1)
                        sTempParams = sTempParams & "'*   " & _
                        Trim(sPar) & vbCrLf
                     End If
                     sLine = Mid$(sLine, InStr(sLine, ")"))
                     sPar = Trim$(oUtil.GetToken(sLine, " _"))
                     If Left$(sPar, 3) = "As " Then
                        sRetVal = Mid$(sPar, 4)
                     End If
                  End If

                  ' now get any comments after the proc def line
                  Do While i <= nL
                     i = i + 1
                     sLine = oUtil.MemoLine(sProcToCopy, 0, i)
                     ' if this is a comment line let's uncomment it and
                     ' put in cComStr, if a blank, skip it...
                     If Left$(Trim$(sLine), 2) = "'*" Then
                        If InStr(sLine, "***") > 1 Or _
                           InStr(sLine, "---") > 1 Or _
                           InStr(sLine, "$$$") > 1 Or _
                           InStr(sLine, "___") > 1 Then
                        Else
                           sLine = Trim$(sLine)
                           sLine = Mid$(sLine, 3)
                           sLine = Trim$(sLine)
                           cComStr = cComStr & "'*   " & sLine & vbCrLf
                        End If
                     ElseIf Left$(Trim$(sLine), 1) = "'" Then
                        If InStr(sLine, "***") > 1 Or _
                           InStr(sLine, "---") > 1 Or _
                           InStr(sLine, "$$$") > 1 Or _
                           InStr(sLine, "___") > 1 Then
                        Else
                           sLine = Trim$(sLine)
                           sLine = Mid$(sLine, 2)
                           sLine = Trim$(sLine)
                           cComStr = cComStr & "'*   " & sLine & vbCrLf
                        End If
                     ElseIf Trim$(sLine) = "" Then
                        ' discard blank lines before Sub/Function
                     Else
                        Exit Do
                     End If
                  Loop

                  If Trim$(cComStr) <> "" Then
                     ' strip the last crlf so we don't get a blank line
                     iPtr = InStrRev(cComStr, vbCrLf)
                     If iPtr > 0 Then
                        cComStr = Left$(cComStr, iPtr - 1)
                     End If
                  End If

                  If Trim$(sTempParams) <> "" Then
                     ' strip the last crlf so we don't get a blank line
                     iPtr = InStrRev(sTempParams, vbCrLf)
                     If iPtr > 0 Then
                        sTempParams = Left$(sTempParams, iPtr - 1)
                     End If
                  End If

                  ' substitute into the template
                  sDocTemplate = Replace(sDocTemplate, _
                                         "ProcName", sWord)
                  sDocTemplate = Replace(sDocTemplate, _
                                         sCopyright, _
                                         sCopyright & " " & _
                                         sCompanyName)
                  sDocTemplate = Replace(sDocTemplate, _
                                         sDateCreated, _
                                         sDateCreated & " " & _
                                         TodaysDate)
                  sDocTemplate = Replace(sDocTemplate, _
                                         sAuthor, _
                                         sAuthor & " " & _
                                         sUserName)
                  If bPurpose And Trim$(cComStr) <> "" Then
                     sDocTemplate = Replace(sDocTemplate, _
                                            sPurpose, _
                                            sPurpose & " " & _
                                            vbCrLf & cComStr)
                  End If
                  If bParameters And Trim$(sTempParams) <> "" Then
                     sDocTemplate = Replace(sDocTemplate, _
                                            sParameters, _
                                            sParameters & " " & _
                                            vbCrLf & sTempParams)
                  End If
                  If sRetVal <> "" Then
                     sDocTemplate = Replace(sDocTemplate, _
                                            sReturns, _
                                            sReturns & " " & sRetVal)
                  ElseIf sProcType = "Sub" Then
                     sDocTemplate = Replace(sDocTemplate, sReturns, "")
                  Else
                     sDocTemplate = Replace(sDocTemplate, _
                                            sReturns, _
                                            sReturns & _
                                            " Return Value not specified")
                  End If
                  sOut = sOut & sDocTemplate
                  sOut = sOut & sLine & vbCrLf
               Else
                  ' we have not found the proc def line yet
                  ' if this is a comment line let's uncomment it and
                  ' put in cComStr, if a blank, skip it...
                  If Left$(Trim$(sLine), 2) = "'*" Then
                     If InStr(sLine, "***") > 1 Or _
                         InStr(sLine, "---") > 1 Or _
                         InStr(sLine, "$$$") > 1 Or _
                         InStr(sLine, "___") > 1 Then
                     Else
                        sLine = Trim$(sLine)
                        sLine = Mid$(sLine, 3)
                        sLine = Trim$(sLine)
                        cComStr = cComStr & "'*   " & sLine & vbCrLf
                     End If
                  ElseIf Left$(Trim$(sLine), 1) = "'" Then
                     If InStr(sLine, "***") > 1 Or _
                        InStr(sLine, "---") > 1 Or _
                        InStr(sLine, "$$$") > 1 Or _
                        InStr(sLine, "___") > 1 Then
                     Else
                        sLine = Trim$(sLine)
                        sLine = Mid$(sLine, 2)
                        sLine = Trim$(sLine)
                        cComStr = cComStr & "'*   " & sLine & vbCrLf
                     End If
                  ElseIf Trim$(sLine) = "" Then
                     ' discard blank lines before Sub/Function
                  Else
                     sOut = sOut & sLine & vbCrLf
                  End If
               End If
            Else
               sOut = sOut & sLine & vbCrLf
            End If
         Next

         ' paste the code back to the window
         oUtil.PutCodeBack(sOut)

         Exit Sub
      Catch e As System.Exception
      End Try
   End Sub

   Public Sub New(ByVal roVB As DTE)
      oVB = roVB
      ' set up today's date for use in all methods
      TodaysDate = Format(Now(), "Long Date")
   End Sub
End Class
