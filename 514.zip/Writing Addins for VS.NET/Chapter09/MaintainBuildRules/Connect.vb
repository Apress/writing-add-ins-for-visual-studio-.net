Imports Microsoft.Office.Core
imports Extensibility
imports System.Runtime.InteropServices
Imports EnvDTE
Imports System.IO
Imports System

#Region " Read me for Add-in installation and setup information. "
' When run, the Add-in wizard prepared the registry for the Add-in.
' At a later time, if the Add-in becomes unavailable for reasons such as:
'   1) You moved this project to a computer other than which is was 
'      originally created on.
'   2) You chose 'Yes' when presented with a message asking if you wish 
'      to remove the Add-in.
'   3) Registry corruption.
'      you will need to re-register the Add-in by building the 
'      MaintainBuildRulesSetup project 
'      by right clicking the project in the Solution Explorer, 
'      then choosing install.
#End Region

<GuidAttribute("19125D5B-4728-42B6-8206-7B69784E9217"), _
ProgIdAttribute("MaintainBuildRules.Connect")> _
Public Class Connect

   Implements Extensibility.IDTExtensibility2
   Implements IDTCommandTarget
   Dim CommandObj As Command
   Dim WithEvents bldevents As BuildEvents
   Dim form1 As MaintainBuildRules
   Dim bldRules As String()
   Dim oVB As EnvDTE.DTE
   Dim addInInstance As EnvDTE.AddIn

   Public Sub OnBeginShutdown(ByRef custom As System.Array) _
      Implements Extensibility.IDTExtensibility2.OnBeginShutdown
   End Sub

   Public Sub OnAddInsUpdate(ByRef custom As System.Array) _
      Implements Extensibility.IDTExtensibility2.OnAddInsUpdate
   End Sub

   Public Sub OnStartupComplete(ByRef custom As System.Array) _
      Implements Extensibility.IDTExtensibility2.OnStartupComplete
   End Sub

   Public Sub OnDisconnection(ByVal RemoveMode As _
      Extensibility.ext_DisconnectMode, _
      ByRef custom As System.Array) _
      Implements Extensibility.IDTExtensibility2.OnDisconnection
      If Not CommandObj Is Nothing Then
         CommandObj.Delete()
      End If
      bldevents = Nothing
   End Sub

   Public Sub OnConnection(ByVal application As Object, _
      ByVal connectMode As Extensibility.ext_ConnectMode, _
      ByVal addInInst As Object, _
      ByRef custom As System.Array) _
      Implements Extensibility.IDTExtensibility2.OnConnection
      If connectMode = Extensibility.ext_ConnectMode.ext_cm_AfterStartup Or _
         connectMode = Extensibility.ext_ConnectMode.ext_cm_Startup _
         Then
         oVB = CType(application, EnvDTE.DTE)
         addInInstance = CType(addInInst, EnvDTE.AddIn)
         Dim objAddIn As AddIn = CType(addInInst, AddIn)
         'CommandObj = oVB.CommandBars("Tools").Controls.Item("MaintainBuildRules")
         ' When run, the Add-in wizard prepared the registry for the Add-in.
         ' At a later time, the Add-in or its commands may become 
         ' unavailable for reasons such as:
         '   1) You moved this project to a computer other than which 
         '      is was originally created on.
         '   2) You chose 'Yes' when presented with a message asking  
         '      if you wish to remove the Add-in.
         '   3) You add new commands or modify commands already defined.
         ' You will need to re-register the Add-in by building the 
         ' MaintainBuildRulesSetup project,
         ' right-clicking the project in the Solution Explorer, 
         ' and then choosing install.
         ' Alternatively, you could execute the ReCreateCommands.reg 
         ' file the Add-in Wizard generated in
         ' the project directory, or run 'devenv /setup' from a command prompt.
         Try
            CommandObj = oVB.Commands.AddNamedCommand(objAddIn, _
               "MaintainBuildRules2", "MaintainBuildRules", _
               "Executes the command for MaintainBuildRules", _
               True, 59, Nothing, 1 + 2)
            CommandObj.AddControl(oVB.CommandBars.Item("Tools"))
            bldevents = CType(oVB.Events.BuildEvents, EnvDTE.BuildEvents)
         Catch e As System.Exception
            MsgBox("Error in attempting to load menu: " & e.Message)
         End Try
      End If
   End Sub

   Public Sub Exec(ByVal cmdName As String, _
      ByVal executeOption As vsCommandExecOption, _
      ByRef varIn As Object, _
      ByRef varOut As Object, _
      ByRef handled As Boolean) _
      Implements IDTCommandTarget.Exec
      handled = False
      If (executeOption = vsCommandExecOption.vsCommandExecOptionDoDefault) Then
         If cmdName = "MaintainBuildRules.Connect.MaintainBuildRules2" Then
            form1 = New MaintainBuildRules(oVB)
            form1.ShowDialog()
            handled = True
            Exit Sub
         End If
      End If
   End Sub

   Public Sub QueryStatus(ByVal cmdName As String, _
      ByVal neededText As vsCommandStatusTextWanted, _
      ByRef statusOption As vsCommandStatus, _
      ByRef commandText As Object) _
      Implements IDTCommandTarget.QueryStatus
      If neededText = _
         EnvDTE.vsCommandStatusTextWanted.vsCommandStatusTextWantedNone _
         Then
         If cmdName = "MaintainBuildRules.Connect.MaintainBuildRules2" Then
            statusOption = CType(vsCommandStatus.vsCommandStatusEnabled + _
                vsCommandStatus.vsCommandStatusSupported, vsCommandStatus)
         Else
            statusOption = vsCommandStatus.vsCommandStatusUnsupported
         End If
      End If
   End Sub

   Private Sub bldevents_OnBuildDone(ByVal Scope As EnvDTE.vsBuildScope, _
      ByVal Action As EnvDTE.vsBuildAction) Handles bldevents.OnBuildDone
      'apply post build rules when the build event is done
      Dim i As Integer = 0
      Dim tmps As String
      Dim globs As Globals
      globs = oVB.Solution.Globals

      'go through rules saved in solution.globals, 
      ' parse them and then execute
      While globs.VariableExists("SolutionPostBuildRule" & _
         i.ToString()) = True
         If globs.VariableValue("SolutionPostBuildRule" & _
            i.ToString()) <> "" Then
            tmps = globs.VariableValue("SolutionPostBuildRule" & _
               i.ToString())
            bldRules = Split(tmps, " ", 2)
            bldRules(0).Replace("\", "\\")
            If bldRules.Length = 2 Then
               System.Diagnostics.Process.Start(bldRules(0), bldRules(1))
            Else
               System.Diagnostics.Process.Start(bldRules(0))
            End If
         End If
         i = i + 1
      End While

   End Sub

   Private Sub bldevents_OnBuildBegin(ByVal Scope As EnvDTE.vsBuildScope, _
                                      ByVal Action As EnvDTE.vsBuildAction) _
                                      Handles bldevents.OnBuildBegin
      ' apply prebuild rules when solution starts to build
      Dim i As Integer = 0
      Dim tmps As String
      Dim globs As Globals
      globs = oVB.Solution.Globals

      'go through rules saved in solution.globals, 
      ' parse them and then execute
      While globs.VariableExists("SolutionPreBuildRule" & i.ToString()) = True
         If globs.VariableValue("SolutionPreBuildRule" & i.ToString()) <> "" Then
            tmps = globs.VariableValue("SolutionPreBuildRule" & i.ToString())
            bldRules = Split(tmps, " ", 2)
            bldRules(0).Replace("\", "\\")
            If bldRules.Length = 2 Then
               System.Diagnostics.Process.Start(bldRules(0), bldRules(1))
            Else
               System.Diagnostics.Process.Start(bldRules(0))
            End If
         End If
         i = i + 1
      End While
   End Sub
End Class
