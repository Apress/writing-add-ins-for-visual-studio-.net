Option Strict Off
Imports System.IO
Imports System.Diagnostics
Imports System.Runtime.InteropServices
Imports process = System.Diagnostics.Process

<ComVisible(False)> Public Class MaintainBuildRules

   Inherits System.Windows.Forms.Form
   Dim appObject As EnvDTE.DTE
   Dim mbDirty As Boolean
   Const PreBuild = "SolutionPreBuildRule"
   Const PostBuild = "SolutionPostBuildRule"

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   Public Sub New(ByVal applicationObject As EnvDTE.DTE)
      MyBase.New()
      appObject = applicationObject
      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub
   Friend WithEvents Addnewruletextbox As System.Windows.Forms.TextBox
   Friend WithEvents MoveDown As System.Windows.Forms.Button
   Friend WithEvents MoveUp As System.Windows.Forms.Button
   Friend WithEvents OK As System.Windows.Forms.Button
   Friend WithEvents RemoveButton As System.Windows.Forms.Button
   Friend WithEvents AddButton As System.Windows.Forms.Button
   Friend WithEvents Addanewrule As System.Windows.Forms.Label
   Friend WithEvents MyPostBuildRule As System.Windows.Forms.Label
   Friend WithEvents MaintainBuildRuleListBox As System.Windows.Forms.ListBox

   Friend WithEvents btnSaveRules As System.Windows.Forms.Button
   'Required by the Windows Form Designer
   Private components As System.ComponentModel.Container

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
   Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
   Friend WithEvents rbPreBuild As System.Windows.Forms.RadioButton
   <System.Diagnostics.DebuggerStepThrough()> _
   Private Sub InitializeComponent()
      Me.OK = New System.Windows.Forms.Button()
      Me.Addanewrule = New System.Windows.Forms.Label()
      Me.Addnewruletextbox = New System.Windows.Forms.TextBox()
      Me.MaintainBuildRuleListBox = New System.Windows.Forms.ListBox()
      Me.MoveUp = New System.Windows.Forms.Button()
      Me.AddButton = New System.Windows.Forms.Button()
      Me.MoveDown = New System.Windows.Forms.Button()
      Me.MyPostBuildRule = New System.Windows.Forms.Label()
      Me.RemoveButton = New System.Windows.Forms.Button()
      Me.GroupBox1 = New System.Windows.Forms.GroupBox()
      Me.btnSaveRules = New System.Windows.Forms.Button()
      Me.btnLoadRules = New System.Windows.Forms.Button()
      Me.RadioButton1 = New System.Windows.Forms.RadioButton()
      Me.rbPreBuild = New System.Windows.Forms.RadioButton()
      Me.GroupBox1.SuspendLayout()
      Me.SuspendLayout()
      '
      'OK
      '
      Me.OK.Location = New System.Drawing.Point(291, 267)
      Me.OK.Name = "OK"
      Me.OK.Size = New System.Drawing.Size(80, 24)
      Me.OK.TabIndex = 2
      Me.OK.Text = "&OK"
      '
      'Addanewrule
      '
      Me.Addanewrule.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.Addanewrule.Location = New System.Drawing.Point(10, 215)
      Me.Addanewrule.Name = "Addanewrule"
      Me.Addanewrule.Size = New System.Drawing.Size(100, 16)
      Me.Addanewrule.TabIndex = 4
      Me.Addanewrule.Text = "Add a new rule"
      '
      'Addnewruletextbox
      '
      Me.Addnewruletextbox.Location = New System.Drawing.Point(10, 231)
      Me.Addnewruletextbox.Name = "Addnewruletextbox"
      Me.Addnewruletextbox.Size = New System.Drawing.Size(256, 20)
      Me.Addnewruletextbox.TabIndex = 3
      Me.Addnewruletextbox.Text = ""
      '
      'MaintainBuildRuleListBox
      '
      Me.MaintainBuildRuleListBox.Location = New System.Drawing.Point(10, 32)
      Me.MaintainBuildRuleListBox.Name = "MaintainBuildRuleListBox"
      Me.MaintainBuildRuleListBox.Size = New System.Drawing.Size(256, 134)
      Me.MaintainBuildRuleListBox.TabIndex = 0
      '
      'MoveUp
      '
      Me.MoveUp.Location = New System.Drawing.Point(17, 176)
      Me.MoveUp.Name = "MoveUp"
      Me.MoveUp.Size = New System.Drawing.Size(80, 24)
      Me.MoveUp.TabIndex = 2
      Me.MoveUp.Text = "Move &Up"
      '
      'AddButton
      '
      Me.AddButton.Location = New System.Drawing.Point(290, 231)
      Me.AddButton.Name = "AddButton"
      Me.AddButton.Size = New System.Drawing.Size(80, 24)
      Me.AddButton.TabIndex = 2
      Me.AddButton.Text = "&Add Rule"
      '
      'MoveDown
      '
      Me.MoveDown.Location = New System.Drawing.Point(102, 176)
      Me.MoveDown.Name = "MoveDown"
      Me.MoveDown.Size = New System.Drawing.Size(80, 24)
      Me.MoveDown.TabIndex = 2
      Me.MoveDown.Text = "Move &Down"
      '
      'MyPostBuildRule
      '
      Me.MyPostBuildRule.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.MyPostBuildRule.Location = New System.Drawing.Point(10, 8)
      Me.MyPostBuildRule.Name = "MyPostBuildRule"
      Me.MyPostBuildRule.Size = New System.Drawing.Size(112, 16)
      Me.MyPostBuildRule.TabIndex = 1
      Me.MyPostBuildRule.Text = "Build Rules"
      '
      'RemoveButton
      '
      Me.RemoveButton.Location = New System.Drawing.Point(186, 176)
      Me.RemoveButton.Name = "RemoveButton"
      Me.RemoveButton.Size = New System.Drawing.Size(80, 24)
      Me.RemoveButton.TabIndex = 2
      Me.RemoveButton.Text = "&Remove"
      '
      'GroupBox1
      '
      Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnSaveRules, Me.btnLoadRules, Me.RadioButton1, Me.rbPreBuild})
      Me.GroupBox1.Location = New System.Drawing.Point(274, 9)
      Me.GroupBox1.Name = "GroupBox1"
      Me.GroupBox1.Size = New System.Drawing.Size(124, 152)
      Me.GroupBox1.TabIndex = 7
      Me.GroupBox1.TabStop = False
      Me.GroupBox1.Text = "Load  &&  Save"
      '
      'btnSaveRules
      '
      Me.btnSaveRules.Location = New System.Drawing.Point(18, 107)
      Me.btnSaveRules.Name = "btnSaveRules"
      Me.btnSaveRules.Size = New System.Drawing.Size(80, 24)
      Me.btnSaveRules.TabIndex = 10
      Me.btnSaveRules.Text = "&Save Rules"
      '
      'btnLoadRules
      '
      Me.btnLoadRules.Location = New System.Drawing.Point(19, 75)
      Me.btnLoadRules.Name = "btnLoadRules"
      Me.btnLoadRules.Size = New System.Drawing.Size(80, 24)
      Me.btnLoadRules.TabIndex = 9
      Me.btnLoadRules.Text = "&Load Rules"
      '
      'RadioButton1
      '
      Me.RadioButton1.Location = New System.Drawing.Point(9, 47)
      Me.RadioButton1.Name = "RadioButton1"
      Me.RadioButton1.Size = New System.Drawing.Size(102, 16)
      Me.RadioButton1.TabIndex = 8
      Me.RadioButton1.Text = "PostBuild Rules"
      '
      'rbPreBuild
      '
      Me.rbPreBuild.Checked = True
      Me.rbPreBuild.Location = New System.Drawing.Point(8, 21)
      Me.rbPreBuild.Name = "rbPreBuild"
      Me.rbPreBuild.Size = New System.Drawing.Size(99, 16)
      Me.rbPreBuild.TabIndex = 7
      Me.rbPreBuild.TabStop = True
      Me.rbPreBuild.Text = "PreBuild Rules"
      '
      'MaintainBuildRules
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(410, 301)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.GroupBox1, Me.MyPostBuildRule, Me.Addanewrule, Me.AddButton, Me.RemoveButton, Me.OK, Me.MoveDown, Me.MoveUp, Me.MaintainBuildRuleListBox, Me.Addnewruletextbox})
      Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
      Me.Name = "MaintainBuildRules"
      Me.Text = "Build Rules Maintenance"
      Me.GroupBox1.ResumeLayout(False)
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub MaintainBuildRules_Load(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles MyBase.Load
      mbDirty = False
   End Sub
   Private Sub GetSelectedBuildRules()
      Dim i As Integer = 0
      Dim globs As EnvDTE.Globals
      Dim s As String
      If Me.rbPreBuild.Checked Then
         s = PreBuild
      Else
         s = PostBuild
      End If
      globs = appObject.Solution.Globals
      MaintainBuildRuleListBox.Items.Clear()

      'load post build rules save in solution.globals to the form
      While (globs.VariableExists(s & i.ToString()) = True)
         If globs.VariableValue(s & i.ToString()) <> "" Then
            MaintainBuildRuleListBox.Items.Add(globs.VariableValue(s & _
               i.ToString()))
            MaintainBuildRuleListBox.SetSelected(i, True)
         End If
         i = i + 1
      End While
   End Sub

   'move the selected item in the rule list down 
   Private Sub MoveDown_Click(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) _
      Handles MoveDown.Click
      Dim temp As Object
      Dim index As Integer
      mbDirty = True

      If ((MaintainBuildRuleListBox.SelectedIndex = _
         (MaintainBuildRuleListBox.Items.Count - 1)) Or _
         (MaintainBuildRuleListBox.SelectedItem = Nothing)) _
         Then
         Exit Sub
      End If
      index = MaintainBuildRuleListBox.SelectedIndex + 1
      temp = MaintainBuildRuleListBox.SelectedItem

      MaintainBuildRuleListBox.Items.RemoveAt(MaintainBuildRuleListBox.SelectedIndex)
      MaintainBuildRuleListBox.Items.Insert(index, temp)
      MaintainBuildRuleListBox.SetSelected(index, True)

   End Sub

   'remove the selected item from the rule list 
   Private Sub RemoveButton_Click(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles RemoveButton.Click
      Dim sindex As Integer
      mbDirty = True
      If (MaintainBuildRuleListBox.Items.Count = 0) Then
         Exit Sub
      Else
         sindex = MaintainBuildRuleListBox.SelectedIndex
         MaintainBuildRuleListBox.Items.RemoveAt(MaintainBuildRuleListBox.SelectedIndex)
         If (sindex <> 0) Then
            MaintainBuildRuleListBox.SetSelected(sindex - 1, True)
         End If
      End If

   End Sub

   'add a rule to the rule list
   Private Sub AddButton_Click(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles AddButton.Click
      If ((Addnewruletextbox.Text = "") Or _
         (Addnewruletextbox.Text.IndexOf(" ") = 0)) _
         Then
         Addnewruletextbox.Clear()
         Exit Sub
      End If
      mbDirty = True
      MaintainBuildRuleListBox.Items.Add(Addnewruletextbox.Text)
      MaintainBuildRuleListBox.SetSelected(MaintainBuildRuleListBox.Items.Count - 1, True)
      Addnewruletextbox.Clear()
   End Sub

   'move the selected item in the rule list up
   Private Sub MoveUp_Click(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) _
      Handles MoveUp.Click
      Dim temp As Object
      Dim index As Integer
      If ((MaintainBuildRuleListBox.SelectedIndex = 0) Or _
         (MaintainBuildRuleListBox.SelectedItem = Nothing)) Then
         Exit Sub
      End If
      mbDirty = True
      If ((MaintainBuildRuleListBox.SelectedIndex - 1) < 0) Then
         index = 0
      Else
         index = MaintainBuildRuleListBox.SelectedIndex - 1
      End If
      temp = MaintainBuildRuleListBox.SelectedItem

      MaintainBuildRuleListBox.Items.RemoveAt(MaintainBuildRuleListBox.SelectedIndex)
      MaintainBuildRuleListBox.Items.Insert(index, temp)
      MaintainBuildRuleListBox.SetSelected(index, True)

   End Sub

   'click OK button on the form
   Private Sub OK_Click(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles OK.Click
      If mbDirty Then
         If MsgBox("Rules have been changed, " & _
            "do you want to close without saving?", _
            MsgBoxStyle.YesNo, _
            "Confirm Closing") = _
            MsgBoxResult.Yes Then
            Exit Sub
         End If
      End If
      Close()
   End Sub

   Private Sub SaveRules()
      Dim i As Integer = 0
      Dim globs As EnvDTE.Globals
      Dim s As String

      If Me.rbPreBuild.Checked Then
         s = PreBuild
      Else
         s = PostBuild
      End If

      globs = appObject.Solution.Globals

      'clean up the solution.globals variables
      While (globs.VariableExists(s & i.ToString()) = True)
         globs.VariableValue(s & i.ToString()) = ""
         globs.VariablePersists(s & i.ToString()) = False
         i = i + 1
      End While

      'write the rules from the form to solution.globals variables 
      For i = 0 To MaintainBuildRuleListBox.Items.Count - 1
         globs.VariableValue(s & i.ToString()) = _
            MaintainBuildRuleListBox.Items.Item(i)
         globs.VariablePersists(s & i.ToString()) = True
      Next

      ' show no save pending
      mbDirty = False
   End Sub

   Private Sub btnLoadRules_Click(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles btnLoadRules.Click
      GetSelectedBuildRules()
   End Sub
   Friend WithEvents btnLoadRules As System.Windows.Forms.Button

   Private Sub btnSaveRules_Click(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles btnSaveRules.Click
      SaveRules()
   End Sub
End Class
