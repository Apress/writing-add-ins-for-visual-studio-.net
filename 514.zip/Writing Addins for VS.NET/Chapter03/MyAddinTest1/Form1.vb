Public Class frmTreeView
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents tvMenu As System.Windows.Forms.TreeView

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.tvMenu = New System.Windows.Forms.TreeView()
        Me.SuspendLayout()
        '
        'tvMenu
        '
        Me.tvMenu.ImageIndex = -1
        Me.tvMenu.Name = "tvMenu"
        Me.tvMenu.Nodes.AddRange(New System.Windows.Forms.TreeNode() _
           {New System.Windows.Forms.TreeNode("Smart Desktop", _
           New System.Windows.Forms.TreeNode() _
           {New System.Windows.Forms.TreeNode("Block Comment"), _
           New System.Windows.Forms.TreeNode("Uncomment"), _
           New System.Windows.Forms.TreeNode("Block Change"), _
           New System.Windows.Forms.TreeNode("Block Delete")})})
        Me.tvMenu.SelectedImageIndex = -1
        Me.tvMenu.Size = New System.Drawing.Size(248, 232)
        Me.tvMenu.TabIndex = 0
        '
        'frmTreeView
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(232, 213)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.tvMenu})
        Me.Name = "frmTreeView"
        Me.Text = "MyAddinTest1"
        Me.TopMost = True
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub tvMenu_AfterSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles tvMenu.AfterSelect
        Select Case UCase$(e.Node.Text)
            Case "SMART DESKTOP" 'ignore root clicks
            Case "BLOCK COMMENT"
                Call Connect.BlockComment()
            Case "UNCOMMENT"
                Call Connect.BlockUnComment()
            Case "BLOCK CHANGE"
                Call Connect.BlockChange()
            Case "BLOCK DELETE"
                Call Connect.BlockDelete()
            Case Else
                MsgBox("Please click on a Child Node.", _
                            MsgBoxStyle.Information, "Unknown Request")
        End Select

    End Sub

End Class
