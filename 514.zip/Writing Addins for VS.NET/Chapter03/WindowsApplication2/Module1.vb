Module Main
    Public Sub Main()
        Dim oFRM As New Form1()
        oFRM.ShowDialog()
        Exit Sub
    End Sub
    Public Sub test()
        Dim a As String
        Dim b As String
        Dim i As Integer

        Do
            If i = 1 Then
                a = b
            Else
                b = c
            End If
        Loop

    End Sub
    Private Sub Test2()
        Dim count As Integer
        Dim fileHandle As Integer

        ' might have a code sequence here
        ' ....
        ' ....

        For count = 1 To 5
            fileHandle = FreeFile()

            ' if the file being killed does not exist, an eror
            ' will be raised.
            Try
                Kill("TEST" & count & ".TXT")
            Catch e As System.Exception
                ' ignore the error
            End Try
            FileOpen(fileHandle, "TEST" & count & ".TXT", OpenMode.Output)
            PrintLine(fileHandle, "This is a sample.")
            FileClose(fileHandle)
        Next

        ' more code...
        ' ...
    End Sub
End Module
