Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents btnTestButton As System.Windows.Forms.Button
   Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
   Friend WithEvents fileMenuItem As System.Windows.Forms.MenuItem
   Friend WithEvents mainItem2 As System.Windows.Forms.MenuItem
   Friend WithEvents mainItem3 As System.Windows.Forms.MenuItem
   Friend WithEvents mainItem4 As System.Windows.Forms.MenuItem
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.btnTestButton = New System.Windows.Forms.Button()
      Me.mainMenu1 = New System.Windows.Forms.MainMenu()
      Me.fileMenuItem = New System.Windows.Forms.MenuItem()
      Me.mainItem2 = New System.Windows.Forms.MenuItem()
      Me.mainItem3 = New System.Windows.Forms.MenuItem()
      Me.mainItem4 = New System.Windows.Forms.MenuItem()
      Me.SuspendLayout()
      '
      'btnTestButton
      '
      Me.btnTestButton.Location = New System.Drawing.Point(30, 30)
      Me.btnTestButton.Name = "btnTestButton"
      Me.btnTestButton.Size = New System.Drawing.Size(100, 60)
      Me.btnTestButton.TabIndex = 0
      Me.btnTestButton.Text = "&Test Button"
      '
      'mainMenu1
      '
      Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.fileMenuItem, Me.mainItem2})
      '
      'fileMenuItem
      '
      Me.fileMenuItem.Index = 0
      Me.fileMenuItem.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mainItem3, Me.mainItem4})
      Me.fileMenuItem.Text = "&File"
      '
      'mainItem2
      '
      Me.mainItem2.Index = 1
      Me.mainItem2.Text = "&Edit"
      '
      'mainItem3
      '
      Me.mainItem3.Index = 0
      Me.mainItem3.Text = "&Open"
      '
      'mainItem4
      '
      Me.mainItem4.Index = 1
      Me.mainItem4.Text = "&Save"
      '
      'Form1
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(292, 273)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnTestButton})
      Me.Menu = Me.mainMenu1
      Me.Name = "Form1"
      Me.Text = "Form1"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub btnTestButton_OnClick(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles btnTestButton.Click

   End Sub
End Class
