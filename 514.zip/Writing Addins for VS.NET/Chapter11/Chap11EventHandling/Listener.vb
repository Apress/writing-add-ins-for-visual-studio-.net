Imports System.ComponentModel.Design
Imports System.ComponentModel.Component
Imports System.ComponentModel
Imports System.Windows.Forms
Imports Microsoft.Office.Core

Public Class Listener

   ' This designer listens for events from the IDesignerHost and IComponentChangeService.
   Public Class DesignerHostListener
      Private m_host As IDesignerHost
      Private m_changeService As IComponentChangeService
      Public Sub New(ByVal host As IDesignerHost)
         m_host = host
         m_changeService = host.GetService(GetType(IComponentChangeService)) '
         ' Adds an event handler for the ComponentChanged event if an IComponentChangeService was obtained.
         If Not (m_changeService Is Nothing) Then
            AddHandler m_changeService.ComponentChanged, AddressOf OnComponentChanged
         End If
      End Sub 'New
      ' The IComponentChange calls this right after a component has been changed.
      Private Sub OnComponentChanged(ByVal sender As Object, ByVal e As ComponentChangedEventArgs)
         ' If the host is loading, this event was not caused by a user, and can be ignored.
         If m_host.Loading Then
            Return
         End If
         ' If a transaction is in progress, wait for a TransactionClosed event which indicates when it's finished.
         If m_host.InTransaction Then
            AddHandler m_host.TransactionClosed, AddressOf OnDesignerTransactionClosed
            Return
         End If
         ' This is a valid UserChange event, so process it.
         OnUserChange()
      End Sub 'OnComponentChanged

      ' The program began listening to the TransactionClosed event in OnComponentChanged().
      Private Sub OnDesignerTransactionClosed(ByVal sender As Object, ByVal e As DesignerTransactionCloseEventArgs)
         ' To stop listening to transaction messages, remove the handler.
         RemoveHandler m_host.TransactionClosed, AddressOf OnDesignerTransactionClosed
         OnUserChange()
      End Sub 'OnDesignerTransactionClosed

      ' Called in response to a change made by the user.
      Private Sub OnUserChange()
         MsgBox("You have just changed the designer document.")
      End Sub 'OnUserChange

   End Class 'DesignerHostListener

   Public Class DesignerHostUser
      Inherits Component
      ' This method creates a new component of the specified type.
      Public Sub CreateNewComponent(ByVal typeName As String)
         ' Gets the designer host.
         Dim host As IDesignerHost = GetService(GetType(IDesignerHost)) '
         If Not (host Is Nothing) Then
            ' GetType() scans project references to locate the type.
            Dim type As Type = host.GetType(typeName)
            If Not (type Is Nothing) Then
               ' Use a transaction to encapsulate multiple operations for speed and undo support.
               Dim trans As DesignerTransaction = host.CreateTransaction(("Creating new " + typeName))
               Try
                  ' This call creates a new instance of the component and sites it with the designer.
                  Dim component As IComponent = host.CreateComponent(type)
                  ' If the component has a Text property, set its text to be the name of the component.
                  Dim textProperty As PropertyDescriptor = TypeDescriptor.GetProperties(component)("Text")
                  If Not (textProperty Is Nothing) And textProperty Is GetType(String) Then
                     textProperty.SetValue(component, component.Site.Name)
                  End If
                  trans.Commit()
               Catch e As Exception
                  trans.Cancel()
                  Throw e
                  Exit Try
               End Try
               ' Brings the designer to the foreground if it is not already.
               host.Activate()
            End If ' Note that because Activate() doesn't modify any components,
         End If    ' there is no need to execute it in a transaction.
      End Sub 'CreateNewComponent
   End Class 'DesignerHostUser
End Class
