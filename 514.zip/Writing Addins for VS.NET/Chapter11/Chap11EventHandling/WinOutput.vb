Imports EnvDTE
Public Class WinOutput
   Private OWP As OutputWindowPane
   Public Overloads Sub WriteOutputWindow(ByVal s1 As String)
      OWP.OutputString(s1 & vbCrLf)
   End Sub
   Public Overloads Sub WriteOutputWindow(ByVal s1 As String, _
                                          ByVal s2 As String)
      OWP.OutputString(s1 & vbCrLf)
      OWP.OutputString(s2 & vbCrLf)
   End Sub
   Public Overloads Sub WriteOutputWindow(ByVal s1 As String, _
                                          ByVal s2 As String, _
                                          ByVal s3 As String)
      OWP.OutputString(s1 & vbCrLf)
      OWP.OutputString(s2 & vbCrLf)
      OWP.OutputString(s3 & vbCrLf)
   End Sub
   Public Overloads Sub WriteOutputWindow(ByVal s1 As String, _
                                          ByVal s2 As String, _
                                          ByVal s3 As String, _
                                          ByVal s4 As String)
      OWP.OutputString(s1 & vbCrLf)
      OWP.OutputString(s2 & vbCrLf)
      OWP.OutputString(s3 & vbCrLf)
      OWP.OutputString(s4 & vbCrLf)
   End Sub
   Public Overloads Sub WriteOutputWindow(ByVal s1 As String, _
                                         ByVal s2 As String, _
                                         ByVal s3 As String, _
                                         ByVal s4 As String, _
                                         ByVal s5 As String)
      OWP.OutputString(s1 & vbCrLf)
      OWP.OutputString(s2 & vbCrLf)
      OWP.OutputString(s3 & vbCrLf)
      OWP.OutputString(s4 & vbCrLf)
      OWP.OutputString(s5 & vbCrLf)
   End Sub
   Public Overloads Sub WriteOutputWindow(ByVal s1 As String, _
                                          ByVal s2 As String, _
                                          ByVal s3 As String, _
                                          ByVal s4 As String, _
                                          ByVal s5 As String, _
                                          ByVal s6 As String)
      OWP.OutputString(s1 & vbCrLf)
      OWP.OutputString(s2 & vbCrLf)
      OWP.OutputString(s3 & vbCrLf)
      OWP.OutputString(s4 & vbCrLf)
      OWP.OutputString(s5 & vbCrLf)
      OWP.OutputString(s6 & vbCrLf)
   End Sub
   Public Sub New(ByRef oVB As EnvDTE.DTE)
      Dim outputWindow As OutputWindow
      outputWindow = _
         CType(oVB.Windows.Item(Constants.vsWindowKindOutput).Object, _
            EnvDTE.OutputWindow)
      OWP = outputWindow.OutputWindowPanes.Add("DTE Event Information")
   End Sub
End Class
