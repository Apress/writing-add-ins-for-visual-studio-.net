Imports Microsoft.Office.Core
Imports Extensibility
Imports System.Runtime.InteropServices
Imports EnvDTE
Public Class CReminders
   Private sb As System.Text.StringBuilder
   Private oVB As EnvDTE.DTE

   Public Sub CkForRemindOfDefaultName(ByVal winCaption As String)
      ' Display message to remind the developer to change
      ' the name of the file from the default name if they
      ' have not already done so.  However, don't do it but
      ' once per instance of the IDE.
      ' DefaultName is a string variable which simply contains
      ' the winCaption paramter concatenated with all previous
      ' names, separated by "_".

      ' if the name is extant in the string, don't put it
      ' there again or notify the user.

      If sb.ToString.IndexOf(winCaption) > -1 Then Exit Sub
      If (Left(winCaption, 4) = "Form" And _
          winCaption.EndsWith("[Design]")) Or _
         Left(winCaption, 6) = "Module" Or _
         Left(winCaption, 5) = "Class" _
         Then
         MsgBox(winCaption & " still has a default name;" & vbLf & _
                "it should be changed to a more meaningful name.", _
                MsgBoxStyle.Exclamation, "Change Default Name")
         sb.Append(winCaption & "_")
      End If
   End Sub

   Public Sub ActivateTaskList()
      Dim win As Window = oVB.Windows.Item(Constants.vsWindowKindTaskList)
      win.Activate()
      win.AutoHides = False
   End Sub
   Public Sub CkForClosingTaskList()
      Dim win As Window = oVB.Windows.Item(Constants.vsWindowKindTaskList)
      Dim tskList As TaskList = win.Object
      If tskList.TaskItems.Count = 0 Then
         win.AutoHides = True
      End If
   End Sub
   Public Sub New(ByVal roVB As EnvDTE.DTE)
      oVB = roVB
      sb = New System.Text.StringBuilder()
   End Sub
End Class
