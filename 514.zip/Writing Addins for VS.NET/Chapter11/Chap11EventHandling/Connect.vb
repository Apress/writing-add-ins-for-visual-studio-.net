Imports Microsoft.Office.Core
Imports Extensibility
Imports System.Runtime.InteropServices
Imports EnvDTE

<GuidAttribute("65DCDC37-6A98-4862-A91C-81F8B5B83073"), ProgIdAttribute("Chap11EventHandling.Connect")> _
Public Class Connect

   Implements Extensibility.IDTExtensibility2
   Dim oRemind As CReminders
   Dim ow As WinOutput
   Dim oVB As EnvDTE.DTE
   Dim addInInstance As EnvDTE.AddIn
   Public WithEvents refEvents As VSLangProj.ReferencesEvents
   Public WithEvents importEvents As VSLangProj.ImportsEvents
   Public WithEvents prjEvents As EnvDTE.ProjectsEvents
   Public WithEvents eventWindows As EnvDTE.WindowEvents
   ' Fires when a line changes in the active editor window
   Public WithEvents textEditorEvents As EnvDTE.TextEditorEvents
   Public WithEvents taskListEvents As EnvDTE.TaskListEvents
   Public WithEvents solutionEvents As EnvDTE.SolutionEvents
   Public WithEvents selectionEvents As EnvDTE.SelectionEvents
   Public WithEvents outputWindowEvents As EnvDTE.OutputWindowEvents
   Public WithEvents findEvents As EnvDTE.FindEvents
   Public WithEvents dteEvents As EnvDTE.DTEEvents
   Public WithEvents documentEvents As EnvDTE.DocumentEvents
   Public WithEvents debuggerEvents As EnvDTE.DebuggerEvents
   Public WithEvents commandEvents As EnvDTE.CommandEvents
   Public WithEvents buildEvents As EnvDTE.BuildEvents
   ' Events for projects added, removed, or renamed
   Public WithEvents solutionItemsEvents As EnvDTE.ProjectItemsEvents

   Public Sub OnBeginShutdown(ByRef custom As System.Array) _
      Implements Extensibility.IDTExtensibility2.OnBeginShutdown
   End Sub

   Public Sub OnAddInsUpdate(ByRef custom As System.Array) _
      Implements Extensibility.IDTExtensibility2.OnAddInsUpdate
   End Sub

   Public Sub OnStartupComplete(ByRef custom As System.Array) _
      Implements Extensibility.IDTExtensibility2.OnStartupComplete
   End Sub

   Public Sub OnDisconnection(ByVal RemoveMode As _
              Extensibility.ext_DisconnectMode, _
              ByRef custom As System.Array) _
              Implements _
              Extensibility.IDTExtensibility2.OnDisconnection
      eventWindows = Nothing
      textEditorEvents = Nothing
      taskListEvents = Nothing
      solutionEvents = Nothing
      selectionEvents = Nothing
      outputWindowEvents = Nothing
      findEvents = Nothing
      dteEvents = Nothing
      documentEvents = Nothing
      debuggerEvents = Nothing
      commandEvents = Nothing
      buildEvents = Nothing
      solutionItemsEvents = Nothing
      ow = Nothing
   End Sub

   Public Sub OnConnection(ByVal application As Object, _
                        ByVal connectMode As Extensibility.ext_ConnectMode, _
                        ByVal addInInst As Object, _
                        ByRef custom As System.Array) _
                        Implements Extensibility.IDTExtensibility2.OnConnection

      oVB = CType(application, EnvDTE.DTE)
      addInInstance = CType(addInInst, EnvDTE.AddIn)
      ' set up my output window object
      ow = New WinOutput(oVB)
      oRemind = New CReminders(oVB)

      Dim events As EnvDTE.Events
      events = oVB.Events
      eventWindows = CType(events.WindowEvents(Nothing), EnvDTE.WindowEvents)
      textEditorEvents = CType(events.TextEditorEvents(Nothing), _
         EnvDTE.TextEditorEvents)
      taskListEvents = CType(events.TaskListEvents(""), EnvDTE.TaskListEvents)
      solutionEvents = CType(events.SolutionEvents, EnvDTE.SolutionEvents)
      selectionEvents = CType(events.SelectionEvents, EnvDTE.SelectionEvents)
      outputWindowEvents = CType(events.OutputWindowEvents(""), _
         EnvDTE.OutputWindowEvents)
      findEvents = CType(events.FindEvents, EnvDTE.FindEvents)
      dteEvents = CType(events.DTEEvents, EnvDTE.DTEEvents)
      documentEvents = CType(events.DocumentEvents(Nothing), _
         EnvDTE.DocumentEvents)
      debuggerEvents = CType(events.DebuggerEvents, EnvDTE.DebuggerEvents)
      commandEvents = _
         CType(events.CommandEvents("{00000000-0000-0000-0000-000000000000}", _
            0), EnvDTE.CommandEvents)
      buildEvents = CType(events.BuildEvents, EnvDTE.BuildEvents)
      solutionItemsEvents = CType(events.SolutionItemsEvents, _
         EnvDTE.ProjectItemsEvents)
      'oListener = New Listener.DesignerHostListener()
   End Sub
   Private Sub eventWindows_WindowActivated(ByVal GotFocus As EnvDTE.Window, _
      ByVal LostFocus As EnvDTE.Window) Handles eventWindows.WindowActivated
      ow.WriteOutputWindow("WindowEvents::WindowActivated", _
         vbTab & "Window receiving focus: " & _
         GotFocus.Caption, _
         vbTab & "Window that lost focus: " & _
         LostFocus.Caption)
      ' Let's do something useful
      ' if the window name is a default name, e.g, Form(n), 
      ' Module(n) or Class(n)
      ' suggest to the user that they need to rename it
      oRemind.CkForRemindOfDefaultName(GotFocus.Caption)

      ' task item removed does not always fire because of
      ' multiple events firing, so place the calls in this
      ' event to kludge the closing of the task list
      If GotFocus.Caption.StartsWith("Task List") Then
         oRemind.CkForClosingTaskList()
      End If
      If LostFocus.Caption.StartsWith("Task List") Then
         oRemind.CkForClosingTaskList()
      End If
   End Sub
   Private Sub winEvents_WindowClosing(ByVal Window As EnvDTE.Window) _
      Handles eventWindows.WindowClosing
      ow.WriteOutputWindow("WindowEvents::WindowClosing", _
                           vbTab & "Window: " & Window.Caption)
   End Sub
   Private Sub winEvents_WindowCreated(ByVal Window As EnvDTE.Window) _
      Handles eventWindows.WindowCreated
      ow.WriteOutputWindow("WindowEvents::WindowCreated", _
                             vbTab & "Window: " & Window.Caption)
   End Sub
   Private Sub winEvents_WindowMoved(ByVal Window As EnvDTE.Window, _
      ByVal Top As Integer, ByVal Left As Integer, ByVal [Width] As Integer, _
      ByVal Height As Integer) Handles eventWindows.WindowMoved
      ow.WriteOutputWindow("WindowEvents::WindowMoved", _
         vbTab & "Window: " & Window.Caption, _
         vbTab & "Location: (" & Top.ToString() & " , " & Left.ToString() & _
                  " , " & Width.ToString() & _
                  " , " & Height.ToString() & ")")
   End Sub
   Private Sub textEditorEvents_LineChanged(ByVal StartPoint As _
      EnvDTE.TextPoint, _
      ByVal EndPoint As EnvDTE.TextPoint, _
      ByVal Hint As Integer) _
      Handles textEditorEvents.LineChanged
      Dim textChangedHint As EnvDTE.vsTextChanged = CType(Hint, _
         EnvDTE.vsTextChanged)
      ow.WriteOutputWindow("TextEditorEvents::LineChanged", _
                           vbTab & "Document: " & _
                                    StartPoint.Parent.Parent.Name, _
                           vbTab & "Change hint: " & _
                                    textChangedHint.ToString())
   End Sub
   Private Sub taskListEvents_TaskAdded(ByVal TaskItem As EnvDTE.TaskItem) _
      Handles taskListEvents.TaskAdded
      ow.WriteOutputWindow("TaskListEvents::TaskAdded", _
                           vbTab & "Task description: " & TaskItem.Description)
      ' activate the task window
      oRemind.ActivateTaskList()
   End Sub
   Private Sub taskListEvents_TaskModified(ByVal TaskItem As EnvDTE.TaskItem, _
      ByVal ColumnModified As EnvDTE.vsTaskListColumn) _
      Handles taskListEvents.TaskModified
      ow.WriteOutputWindow("TaskListEvents::TaskModified", _
         vbTab & _
                  "Task description: " & TaskItem.Description)
   End Sub
   Private Sub taskListEvents_TaskNavigated(ByVal TaskItem As EnvDTE.TaskItem, _
      ByRef NavigateHandled As Boolean) Handles taskListEvents.TaskNavigated
      ow.WriteOutputWindow("TaskListEvents::TaskNavigated", _
                           vbTab & "Task description: " & _
                                    TaskItem.Description)
   End Sub
   Private Sub taskListEvents_TaskRemoved(ByVal TaskItem As EnvDTE.TaskItem) _
      Handles taskListEvents.TaskRemoved
      ow.WriteOutputWindow("TaskListEvents::TaskRemoved", _
                           vbTab & "Task description: " & _
                                    TaskItem.Description)
      ' if a task is removed and the task list is now empty, hide the tasklist
      oRemind.CkForClosingTaskList()
   End Sub
   Private Sub solutionEvents_AfterClosing() _
      Handles solutionEvents.AfterClosing
      ow.WriteOutputWindow("SolutionEvents::AfterClosing")
   End Sub
   Private Sub solutionEvents_BeforeClosing() _
      Handles solutionEvents.BeforeClosing
      ow.WriteOutputWindow("SolutionEvents::BeforeClosing")
   End Sub
   Private Sub solutionEvents_Opened() Handles solutionEvents.Opened
      ow.WriteOutputWindow("SolutionEvents::Opened")
   End Sub
   Private Sub solutionEvents_ProjectAdded(ByVal Project As EnvDTE.Project) _
      Handles solutionEvents.ProjectAdded
      ow.WriteOutputWindow("SolutionEvents::ProjectAdded", _
                           vbTab & "Project: " & Project.UniqueName)
   End Sub
   Private Sub solutionEvents_ProjectRemoved(ByVal Project As EnvDTE.Project) _
      Handles solutionEvents.ProjectRemoved
      ow.WriteOutputWindow("SolutionEvents::ProjectRemoved", _
                           vbTab & "Project: " & Project.UniqueName)
   End Sub
   Private Sub solutionEvents_ProjectRenamed(ByVal Project As EnvDTE.Project, _
      ByVal OldName As String) Handles solutionEvents.ProjectRenamed
      ow.WriteOutputWindow("SolutionEvents::ProjectRenamed", _
                           vbTab & "Project: " & Project.UniqueName)
   End Sub
   Private Sub solutionEvents_QueryCloseSolution(ByRef fCancel As Boolean) _
      Handles solutionEvents.QueryCloseSolution
      ow.WriteOutputWindow("SolutionEvents::QueryCloseSolution")
   End Sub
   Private Sub solutionEvents_Renamed(ByVal OldName As String) _
      Handles solutionEvents.Renamed
      ow.WriteOutputWindow("SolutionEvents::Renamed")
   End Sub
   Private Sub selectionEvents_OnChange() Handles selectionEvents.OnChange
      ow.WriteOutputWindow("SelectionEvents::OnChange")
      Dim count As Integer = oVB.SelectedItems.Count
      Dim i As Integer
      For i = 1 To oVB.SelectedItems.Count
         ow.WriteOutputWindow("Item name: " & _
            oVB.SelectedItems.Item(i).Name)
      Next
   End Sub
   Private Sub outputWindowEvents_PaneAdded(ByVal pane As _
      EnvDTE.OutputWindowPane) _
      Handles outputWindowEvents.PaneAdded
      ow.WriteOutputWindow("OutputWindowEvents::PaneAdded", _
                           vbTab & "Pane: " & pane.Name)
   End Sub
   Private Sub outputWindowEvents_PaneClearing(ByVal pane As _
      EnvDTE.OutputWindowPane) _
      Handles outputWindowEvents.PaneClearing
      ow.WriteOutputWindow("OutputWindowEvents::PaneClearing", _
                           vbTab & "Pane: " & pane.Name)
   End Sub
   Private Sub outputWindowEvents_PaneUpdated(ByVal pPane As _
      EnvDTE.OutputWindowPane) Handles outputWindowEvents.PaneUpdated
      Static Busy As Boolean
      'If Busy Then Exit Sub
      'Busy = True
      'Dont want to do this one, causes too much output
      'ow.WriteOutputWindow("OutputWindowEvents::PaneUpdated", _
      '                     vbTab & "Pane: " & pPane.Name)
      'Busy = False
   End Sub
   Private Sub findEvents_FindDone(ByVal Result As EnvDTE.vsFindResult, _
      ByVal Cancelled As Boolean) Handles findEvents.FindDone
      ow.WriteOutputWindow("FindEvents::FindDone")
   End Sub
   Private Sub dteEvents_ModeChanged(ByVal LastMode As EnvDTE.vsIDEMode) _
      Handles dteEvents.ModeChanged
      ow.WriteOutputWindow("DTEEvents::ModeChanged", _
                           "LastMode: " & LastMode.ToString)
   End Sub
   Private Sub dteEvents_OnBeginShutdown() Handles dteEvents.OnBeginShutdown
      ow.WriteOutputWindow("DTEEvents::OnBeginShutdown")
   End Sub
   Private Sub dteEvents_OnMacrosRuntimeReset() _
      Handles dteEvents.OnMacrosRuntimeReset
      ow.WriteOutputWindow("DTEEvents::OnMacrosRuntimeReset")
   End Sub
   Private Sub dteEvents_OnStartupComplete() _
      Handles dteEvents.OnStartupComplete
      ow.WriteOutputWindow("DTEEvents::OnStartupComplete")
   End Sub
   Private Sub documentEvents_DocumentClosing(ByVal Document As _
      EnvDTE.Document) _
      Handles documentEvents.DocumentClosing
      ow.WriteOutputWindow("DocumentEvents::DocumentClosing", _
                           vbTab & "Document: " & Document.Name)
   End Sub
   Private Sub documentEvents_DocumentOpened(ByVal Document As EnvDTE.Document) _
      Handles documentEvents.DocumentOpened
      ow.WriteOutputWindow("DocumentEvents::DocumentOpened", _
                           vbTab & "Document: " & Document.Name)
   End Sub
   Private Sub documentEvents_DocumentOpening(ByVal DocumentPath As String, _
      ByVal [ReadOnly] As Boolean) Handles documentEvents.DocumentOpening
      ow.WriteOutputWindow("DocumentEvents::DocumentOpening", _
                           vbTab & "Path: " & DocumentPath)
   End Sub
   Private Sub documentEvents_DocumentSaved(ByVal Document As EnvDTE.Document) _
      Handles documentEvents.DocumentSaved
      ow.WriteOutputWindow("DocumentEvents::DocumentSaved", _
                           vbTab & "Document: " & Document.Name)
   End Sub
   Private Sub debuggerEvents_OnContextChanged(ByVal NewProcess As _
      EnvDTE.Process, ByVal NewProgram As EnvDTE.Program, _
      ByVal NewThread As EnvDTE.Thread, _
      ByVal NewStackFrame As EnvDTE.StackFrame) _
      Handles debuggerEvents.OnContextChanged
      ow.WriteOutputWindow("DebuggerEvents::OnContextChanged")
   End Sub
   Private Sub debuggerEvents_OnEnterBreakMode(ByVal Reason As _
      EnvDTE.dbgEventReason, ByRef ExecutionAction As EnvDTE.dbgExecutionAction) _
      Handles debuggerEvents.OnEnterBreakMode
      ExecutionAction = EnvDTE.dbgExecutionAction.dbgExecutionActionDefault
      ow.WriteOutputWindow("DebuggerEvents::OnEnterBreakMode")
   End Sub
   Private Sub debuggerEvents_OnEnterDesignMode(ByVal Reason As _
      EnvDTE.dbgEventReason) Handles debuggerEvents.OnEnterDesignMode
      ow.WriteOutputWindow("DebuggerEvents::OnEnterDesignMode")
   End Sub
   Private Sub debuggerEvents_OnEnterRunMode(ByVal Reason As _
      EnvDTE.dbgEventReason) Handles debuggerEvents.OnEnterRunMode
      ow.WriteOutputWindow("DebuggerEvents::OnEnterRunMode")
   End Sub
   Private Sub debuggerEvents_OnExceptionNotHandled(ByVal ExceptionType As String, _
      ByVal [Name] As String, ByVal Code As Integer, _
      ByVal Description As String, _
      ByRef ExceptionAction As EnvDTE.dbgExceptionAction) _
      Handles debuggerEvents.OnExceptionNotHandled
      ExceptionAction = EnvDTE.dbgExceptionAction.dbgExceptionActionDefault
      ow.WriteOutputWindow("DebuggerEvents::OnExceptionNotHandled")
   End Sub
   Private Sub debuggerEvents_OnExceptionThrown(ByVal ExceptionType As String, _
      ByVal [Name] As String, ByVal Code As Integer, _
      ByVal Description As String, _
      ByRef ExceptionAction As EnvDTE.dbgExceptionAction) _
      Handles debuggerEvents.OnExceptionThrown
      ExceptionAction = EnvDTE.dbgExceptionAction.dbgExceptionActionDefault
      ow.WriteOutputWindow("DebuggerEvents::OnExceptionThrown")
   End Sub
   Private Sub commandEvents_AfterExecute(ByVal Guid As String, _
      ByVal ID As Integer, ByVal CustomIn As Object, _
      ByVal CustomOut As Object) Handles commandEvents.AfterExecute
      Dim commandName As String
      Try
         commandName = oVB.Commands.Item(Guid, ID).Name
      Catch excep As System.Exception
      End Try
      ow.WriteOutputWindow("CommandEvents::AfterExecute")
      If (commandName <> "") Then
         ow.WriteOutputWindow(vbTab & "Command name: " & commandName)
      End If
      ow.WriteOutputWindow(vbTab & "Command GUID/ID: " & _
         Guid & ", " & ID.ToString())
   End Sub
   Private Sub commandEvents_BeforeExecute(ByVal Guid As String, _
      ByVal ID As Integer, ByVal CustomIn As Object, _
      ByVal CustomOut As Object, ByRef CancelDefault As Boolean) _
      Handles commandEvents.BeforeExecute
      Dim commandName As String
      Try
         commandName = oVB.Commands.Item(Guid, ID).Name
      Catch excep As System.Exception
      End Try
      ow.WriteOutputWindow("CommandEvents::BeforeExecute")
      If (commandName <> "") Then
         ow.WriteOutputWindow(vbTab & _
            "Command name: " & commandName)
      End If
      ow.WriteOutputWindow(vbTab & "Command GUID/ID: " & _
         Guid & ", " & ID.ToString())
   End Sub
   Private Sub buildEvents_OnBuildBegin(ByVal Scope As EnvDTE.vsBuildScope, _
      ByVal Action As EnvDTE.vsBuildAction) Handles buildEvents.OnBuildBegin
      ow.WriteOutputWindow("BuildEvents::OnBuildBegin")
   End Sub
   Private Sub buildEvents_OnBuildDone(ByVal Scope As EnvDTE.vsBuildScope, _
      ByVal Action As EnvDTE.vsBuildAction) Handles buildEvents.OnBuildDone
      ow.WriteOutputWindow("BuildEvents::OnBuildDone")
   End Sub
   Private Sub buildEvents_OnBuildProjConfigBegin(ByVal Project As String, _
      ByVal ProjectConfig As String, ByVal Platform As String, _
      ByVal SolutionConfig As String) _
      Handles buildEvents.OnBuildProjConfigBegin
      ow.WriteOutputWindow("BuildEvents::OnBuildProjConfigBegin", _
         vbTab & "Project: " & Project, _
         vbTab & "Project Configuration: " & ProjectConfig, _
         vbTab & "Platform: " & Platform, _
         vbTab & "Solution Configuration: " & SolutionConfig)
   End Sub
   Private Sub buildEvents_OnBuildProjConfigDone(ByVal Project As String, _
      ByVal ProjectConfig As String, ByVal Platform As String, _
      ByVal SolutionConfig As String, ByVal Success As Boolean) _
      Handles buildEvents.OnBuildProjConfigDone
      ow.WriteOutputWindow("BuildEvents::OnBuildProjConfigDone", _
         vbTab & "Project: " & Project, _
         vbTab & "Project Configuration: " & ProjectConfig, _
         vbTab & "Platform: " & Platform, _
         vbTab & "Build success: " & Success.ToString())
   End Sub
   Private Sub solutionItemsEvents_ItemAdded(ByVal ProjectItem As _
      EnvDTE.ProjectItem) Handles solutionItemsEvents.ItemAdded
      ow.WriteOutputWindow("SolutionItemsEvents::ItemAdded", _
         vbTab & "Project Item: " & _
                  ProjectItem.Name)
   End Sub
   Private Sub solutionItemsEvents_ItemRemoved(ByVal ProjectItem As _
      EnvDTE.ProjectItem) Handles solutionItemsEvents.ItemRemoved
      ow.WriteOutputWindow("SolutionItemsEvents::ItemRemoved", _
                           vbTab & "Project Item: " & _
                                    ProjectItem.Name)
   End Sub
   Private Sub solutionItemsEvents_ItemRenamed(ByVal ProjectItem As _
      EnvDTE.ProjectItem, ByVal OldName As String) _
      Handles solutionItemsEvents.ItemRenamed
      ow.WriteOutputWindow("SolutionItemsEvents::ItemRenamed", _
                           vbTab & "Project Item: " & _
                                    ProjectItem.Name)
   End Sub
   Private Sub prjEvents_ItemAdded(ByVal Project As EnvDTE.Project) _
      Handles prjEvents.ItemAdded
      ow.WriteOutputWindow("ProjectsEvents::ItemAdded", _
                           vbTab & "Project: " & Project.Name)
   End Sub
   Private Sub prjEvents_ItemRemoved(ByVal Project As EnvDTE.Project) _
      Handles prjEvents.ItemRemoved
      ow.WriteOutputWindow("ProjectsEvents::ItemRemoved", _
         vbTab & "Project: " & Project.Name)
   End Sub
   Private Sub prjEvents_ItemRenamed(ByVal Project As EnvDTE.Project, _
                                     ByVal OldName As String) _
                                     Handles prjEvents.ItemRenamed
      ow.WriteOutputWindow("ProjectsEvents::ItemRenamed", _
                           vbTab & "OldProjectName: " & OldName, _
                           vbTab & "NewProjectName: " & Project.Name)
   End Sub
End Class