Imports Microsoft.Office.Core
imports Extensibility
imports System.Runtime.InteropServices
Imports EnvDTE

#Region " Read me for Add-in installation and setup information. "
' When run, the Add-in wizard prepared the registry for the Add-in.
' At a later time, if the Add-in becomes unavailable for reasons such as:
'   1) You moved this project to a computer other than which is was originally created on.
'   2) You chose 'Yes' when presented with a message asking if you wish to remove the Add-in.
'   3) Registry corruption.
' you will need to re-register the Add-in by building the MyAddinTest1Setup project 
' by right clicking the project in the Solution Explorer, then choosing install.
#End Region

<GuidAttribute("EA9E1DDF-0B64-4446-9E29-48DE0CC80523"), ProgIdAttribute("MyAddinTest1.Connect")> _
Public Class Connect
	
	Implements Extensibility.IDTExtensibility2
	Implements IDTCommandTarget
	
   Dim applicationObject As EnvDTE.DTE
   Dim addInInstance As EnvDTE.AddIn

   ' moved to module level so OnDisconnect can see it
   Dim CommandObj As Command

   Public Sub OnBeginShutdown(ByRef custom As System.Array) Implements Extensibility.IDTExtensibility2.OnBeginShutdown
   End Sub

   Public Sub OnAddInsUpdate(ByRef custom As System.Array) Implements Extensibility.IDTExtensibility2.OnAddInsUpdate
   End Sub

   Public Sub OnStartupComplete(ByRef custom As System.Array) Implements Extensibility.IDTExtensibility2.OnStartupComplete
   End Sub

   Public Sub OnDisconnection(ByVal RemoveMode As _
              Extensibility.ext_DisconnectMode, _
              ByRef custom As System.Array) _
              Implements _
              Extensibility.IDTExtensibility2.OnDisconnection
      Try
         CommandObj.Delete()
         MsgBox("Disconnect, remove Tool Button", _
                MsgBoxStyle.Information, "MyAddinTest1")

      Catch e As System.Exception
         MsgBox("Error in Disconnect: " & _
                e.Message, _
                MsgBoxStyle.Critical, _
                "MyAddinTest1")
      End Try
   End Sub

   Public Sub OnConnection(ByVal application As Object, ByVal connectMode As Extensibility.ext_ConnectMode, ByVal addInInst As Object, ByRef custom As System.Array) Implements Extensibility.IDTExtensibility2.OnConnection
      Dim iBitMap As Integer

      applicationObject = CType(application, EnvDTE.DTE)
      addInInstance = CType(addInInst, EnvDTE.AddIn)
      If connectMode = Extensibility.ext_ConnectMode.ext_cm_AfterStartup Or _
         connectMode = Extensibility.ext_ConnectMode.ext_cm_Startup _
         Then
         Dim objAddIn As AddIn = CType(addInInst, AddIn)

         ' When run, the Add-in wizard prepared the registry for the Add-in.
         ' At a later time, the Add-in or its commands may become unavailable for reasons such as:
         '   1) You moved this project to a computer other than which is was originally created on.
         '   2) You chose 'Yes' when presented with a message asking if you wish to remove the Add-in.
         '   3) You add new commands or modify commands already defined.
         ' You will need to re-register the Add-in by building the MyAddinTest1Setup project,
         ' right-clicking the project in the Solution Explorer, and then choosing install.
         ' Alternatively, you could execute the ReCreateCommands.reg file the Add-in Wizard generated in
         ' the project directory, or run 'devenv /setup' from a command prompt.
         Try
            CommandObj = applicationObject.Commands.AddNamedCommand(objAddIn, _
                         "MyAddinTest1", "Click Me", _
                         "Executes the command for MyAddinTest1", _
                         True, 59, Nothing, 1 + 2) _
                         '1+2 == vsCommandStatusSupported+vsCommandStatusEnabled
            CommandObj.AddControl(applicationObject.CommandBars.Item("Tools"))
         Catch e As System.Exception
            MsgBox("Error in placing control: " & e.Message)
         End Try
      End If
   End Sub

   Public Sub Exec(ByVal cmdName As String, _
                   ByVal executeOption As vsCommandExecOption, _
                   ByRef varIn As Object, _
                   ByRef varOut As Object, _
                   ByRef handled As Boolean) _
                   Implements IDTCommandTarget.Exec

      handled = False
      If (executeOption = vsCommandExecOption.vsCommandExecOptionDoDefault) Then
         If cmdName = "MyAddinTest1.Connect.MyAddinTest1" Then
            handled = True
            MsgBox("You rang?")
            Exit Sub
         End If
      End If
   End Sub

   Public Sub QueryStatus(ByVal cmdName As String, _
              ByVal neededText As vsCommandStatusTextWanted, _
              ByRef statusOption As vsCommandStatus, _
              ByRef commandText As Object) _
              Implements IDTCommandTarget.QueryStatus
      If neededText = EnvDTE.vsCommandStatusTextWanted.vsCommandStatusTextWantedNone _
         Then
         If cmdName = "MyAddinTest1.Connect.MyAddinTest1" Then
            statusOption = CType(vsCommandStatus.vsCommandStatusEnabled + _
                           vsCommandStatus.vsCommandStatusSupported, vsCommandStatus)
         Else
            statusOption = vsCommandStatus.vsCommandStatusUnsupported
         End If
      End If
   End Sub
End Class
