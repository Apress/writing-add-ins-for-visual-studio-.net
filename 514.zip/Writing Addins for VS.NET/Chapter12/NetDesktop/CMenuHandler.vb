Imports Microsoft.Office.Core
Imports Extensibility
Imports System.Runtime.InteropServices
Imports EnvDTE
Imports System.Windows.Forms
Public Class CMenuHandler
   Public Sub LoadMenuForm(ByRef oVB As EnvDTE.DTE, ByVal btn As Microsoft.Office.Core.CommandBarControl, ByVal oFrm As Form)
      Dim x As Integer
      Dim y As Integer

      x = btn.Left 'oVB.MainWindow.Left + btn.Left - oVB.MainWindow.Left
      y = btn.Top + btn.Height
      oFrm.Visible = False
      oFrm.Show()
      oFrm.Left = x
      oFrm.Top = y
      oFrm.Visible = True
      oFrm.TopMost = True
      System.Windows.Forms.Application.DoEvents()
   End Sub
   Public Sub HandleMouseMove(ByVal Sender As Object, _
                          ByRef TimerStart As Integer, _
                          ByRef TimeToUnload As Short)
      Dim lbl As System.Windows.Forms.Label
      lbl = CType(Sender, System.Windows.Forms.Label)
      lbl.ForeColor = System.Drawing.SystemColors.Window
      lbl.BackColor = System.Drawing.SystemColors.ActiveCaption
      TimerStart = Microsoft.VisualBasic.DateAndTime.Timer
      TimeToUnload = 30
   End Sub
   Public Sub HandleMouseLeave(ByVal Sender As Object, _
                          ByRef TimerStart As Integer, _
                          ByRef TimeToUnload As Short)
      Dim lbl As System.Windows.Forms.Label
      lbl = CType(Sender, System.Windows.Forms.Label)
      lbl.BackColor = System.Drawing.SystemColors.Control
      lbl.ForeColor = System.Drawing.SystemColors.WindowText
      TimerStart = Microsoft.VisualBasic.DateAndTime.Timer
      TimeToUnload = 1
   End Sub
End Class
