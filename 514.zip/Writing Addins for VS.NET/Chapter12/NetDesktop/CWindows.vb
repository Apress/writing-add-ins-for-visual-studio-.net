' This class contains the methods for closing
' and saving windows in the IDE.
' Its methods are called from the frmWindowsMenus
' click event handlers.
Imports Microsoft.Office.Core
Imports Extensibility
Imports System.Runtime.InteropServices
Imports EnvDTE

Public Class CWindows
   Public oVB As DTE
   Public Sub CloseAndSaveWindowsWithPrompt()
      ' Close all documents.
      Dim i As Integer

      With oVB
         For i = .Documents.Count To 1 Step -1
            ' ignore any erors we may encounter in closing a window
            ' so that we continue to next window
            On Error Resume Next
            .Documents.Item(i).Close(vsSaveChanges.vsSaveChangesPrompt)
            Err.Clear()
         Next i
      End With
   End Sub
   Public Sub CloseAndSaveWindows()
      ' Close all documents.
      Dim i As Integer

      With oVB
         For i = .Documents.Count To 1 Step -1
            ' ignore any erors we may encounter in closing a window
            ' so that we continue to next window
            On Error Resume Next
            .Documents.Item(i).Close(vsSaveChanges.vsSaveChangesYes)
            Err.Clear()
         Next i
      End With
   End Sub
   Public Sub CloseAllButCurrentWindow()
      Dim i As Integer
      Dim sCurrWin As String = oVB.ActiveDocument.Name

      Debug.WriteLine(sCurrWin)
      With oVB
         On Error Resume Next
         For i = .Documents.Count To 1 Step -1
            If .Documents.Item(i).Name <> sCurrWin Then
               If Not .Documents.Item(i).Saved Then
                  .Documents.Item(i).Close(vsSaveChanges.vsSaveChangesYes)
               Else
                  .Documents.Item(i).Close(vsSaveChanges.vsSaveChangesNo)
               End If
            End If
         Next
      End With
   End Sub
   Public Sub CloseAllSavedWindows()
      ' Close all saved documents.
      Dim i As Integer

      With oVB
         On Error Resume Next
         For i = .Documents.Count To 1 Step -1
            If .Documents.Item(i).Saved Then
               .Documents.Item(i).Close(vsSaveChanges.vsSaveChangesPrompt)
            End If
         Next i
      End With
   End Sub
   Public Sub New(ByVal roVB As DTE)
      oVB = roVB
   End Sub
   Sub BackupCurrentWindow()
      '` This method will make a backup copy of
      '` the active window.  It will be saved as
      '` fullname.bak.  For example a .vb file
      '` will be saved as name.vb.bak.  The file
      '` will be saved and closed.  It will not
      '' be added to the project.
      Dim Sel As TextSelection = oVB.ActiveDocument.Selection
      Dim sFileName As String = oVB.ActiveDocument.FullName & ".bak"
      Dim epAnchor As EditPoint = Sel.AnchorPoint.CreateEditPoint
      Dim epActive As EditPoint = Sel.ActivePoint.CreateEditPoint
      Dim txtWin As TextWindow = oVB.ActiveWindow.Object
      Dim actPane As TextPane = txtWin.ActivePane
      Dim Corner As EditPoint = actPane.StartPoint.CreateEditPoint
      Dim Text As String

      Sel.SelectAll()
      Text = Sel.Text

      ' Create, save, and close the backup copy of the current window
      oVB.ItemOperations.NewFile("General\Text File")
      oVB.ActiveDocument.Object("TextDocument").Selection.Insert(Text)
      oVB.ActiveDocument.Save(sFileName)
      oVB.ActiveDocument.Close(EnvDTE.vsSaveChanges.vsSaveChangesNo)

      ' Restore the selection.
      Sel.MoveToPoint(epAnchor)
      Sel.MoveToPoint(epActive, True)
      actPane.TryToShow(Corner, vsPaneShowHow.vsPaneShowTop)
   End Sub
End Class
