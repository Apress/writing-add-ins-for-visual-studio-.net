Imports System.Windows.Forms
Imports Microsoft.VisualBasic.Constants
Imports System.Text
Imports System.Windows.Forms.MessageBox
Public Class frmMessageBox
   Inherits System.Windows.Forms.Form
   Dim intMBOptions As Integer
   Dim strMBType As String
   Dim intMBIcon As Integer
   Dim intMBSystemModal As Integer
   Dim iIcon As Integer
   Dim sBtn1 As String
   Dim sbtn2 As String
   Dim sbtn3 As String
   Dim sbtn4 As String
   Dim sMessage As String
   Dim sCaption As String
   Private oVB As EnvDTE.DTE
   Dim oUtil As Utilities
   Dim iLangType As Integer

#Region " Windows Form Designer generated code "

   Public Sub New(ByVal roVB As EnvDTE.DTE)
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
      oVB = roVB
      oUtil = New Utilities(oVB)
      iLangType = oUtil.GetFileType(oVB.ActiveDocument)
      strMBType = "S"
      intMBOptions = 0
      intMBIcon = 16
      intMBSystemModal = 0
      txtMessage.Text = "Type lines and press Enter for Multiline" & Chr(13) & Chr(10)
      If iLangType <> 8 And iLangType <> 9 Then
         MsgBox("The MessageBox Designer can only handle C# and VB.")
      End If
      Me.txtTitle.Focus()
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
   Friend WithEvents rbOk As System.Windows.Forms.RadioButton
   Friend WithEvents rbOkCancel As System.Windows.Forms.RadioButton
   Friend WithEvents rbAbortRetryCancel As System.Windows.Forms.RadioButton
   Friend WithEvents rbYesNoCancel As System.Windows.Forms.RadioButton
   Friend WithEvents rbYesNo As System.Windows.Forms.RadioButton
   Friend WithEvents rbRetryCancel As System.Windows.Forms.RadioButton
   Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
   Friend WithEvents rbButton1 As System.Windows.Forms.RadioButton
   Friend WithEvents rbButton2 As System.Windows.Forms.RadioButton
   Friend WithEvents rbButton3 As System.Windows.Forms.RadioButton
   Friend WithEvents btnCritical As System.Windows.Forms.Button
   Friend WithEvents btnQuestion As System.Windows.Forms.Button
   Friend WithEvents btnExclamation As System.Windows.Forms.Button
   Friend WithEvents btnInformation As System.Windows.Forms.Button
   Friend WithEvents Label1 As System.Windows.Forms.Label
   Friend WithEvents txtMessage As System.Windows.Forms.TextBox
   Friend WithEvents Label2 As System.Windows.Forms.Label
   Friend WithEvents Label3 As System.Windows.Forms.Label
   Friend WithEvents btnTest As System.Windows.Forms.Button
   Friend WithEvents btnPasteCode As System.Windows.Forms.Button
   Friend WithEvents btnCopyToClipboard As System.Windows.Forms.Button
   Friend WithEvents btnCancel As System.Windows.Forms.Button
   Friend WithEvents txtTitle As System.Windows.Forms.TextBox
   Friend WithEvents btnRefreshCode As System.Windows.Forms.Button
   Friend WithEvents txtCode As System.Windows.Forms.TextBox
   Friend WithEvents chkSystemModal As System.Windows.Forms.CheckBox
   Friend WithEvents chkApplicationModal As System.Windows.Forms.CheckBox
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMessageBox))
      Me.GroupBox1 = New System.Windows.Forms.GroupBox()
      Me.rbRetryCancel = New System.Windows.Forms.RadioButton()
      Me.rbYesNo = New System.Windows.Forms.RadioButton()
      Me.rbYesNoCancel = New System.Windows.Forms.RadioButton()
      Me.rbAbortRetryCancel = New System.Windows.Forms.RadioButton()
      Me.rbOkCancel = New System.Windows.Forms.RadioButton()
      Me.rbOk = New System.Windows.Forms.RadioButton()
      Me.GroupBox2 = New System.Windows.Forms.GroupBox()
      Me.rbButton3 = New System.Windows.Forms.RadioButton()
      Me.rbButton2 = New System.Windows.Forms.RadioButton()
      Me.rbButton1 = New System.Windows.Forms.RadioButton()
      Me.btnCritical = New System.Windows.Forms.Button()
      Me.btnQuestion = New System.Windows.Forms.Button()
      Me.btnExclamation = New System.Windows.Forms.Button()
      Me.btnInformation = New System.Windows.Forms.Button()
      Me.txtTitle = New System.Windows.Forms.TextBox()
      Me.Label1 = New System.Windows.Forms.Label()
      Me.txtMessage = New System.Windows.Forms.TextBox()
      Me.Label2 = New System.Windows.Forms.Label()
      Me.txtCode = New System.Windows.Forms.TextBox()
      Me.Label3 = New System.Windows.Forms.Label()
      Me.chkSystemModal = New System.Windows.Forms.CheckBox()
      Me.chkApplicationModal = New System.Windows.Forms.CheckBox()
      Me.btnTest = New System.Windows.Forms.Button()
      Me.btnPasteCode = New System.Windows.Forms.Button()
      Me.btnCopyToClipboard = New System.Windows.Forms.Button()
      Me.btnCancel = New System.Windows.Forms.Button()
      Me.btnRefreshCode = New System.Windows.Forms.Button()
      Me.GroupBox1.SuspendLayout()
      Me.GroupBox2.SuspendLayout()
      Me.SuspendLayout()
      '
      'GroupBox1
      '
      Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.rbRetryCancel, Me.rbYesNo, Me.rbYesNoCancel, Me.rbAbortRetryCancel, Me.rbOkCancel, Me.rbOk})
      Me.GroupBox1.Location = New System.Drawing.Point(16, 8)
      Me.GroupBox1.Name = "GroupBox1"
      Me.GroupBox1.Size = New System.Drawing.Size(152, 128)
      Me.GroupBox1.TabIndex = 7
      Me.GroupBox1.TabStop = False
      Me.GroupBox1.Text = "Message Box Buttons"
      '
      'rbRetryCancel
      '
      Me.rbRetryCancel.Location = New System.Drawing.Point(8, 109)
      Me.rbRetryCancel.Name = "rbRetryCancel"
      Me.rbRetryCancel.Size = New System.Drawing.Size(128, 14)
      Me.rbRetryCancel.TabIndex = 5
      Me.rbRetryCancel.Text = "Retry, Cancel"
      '
      'rbYesNo
      '
      Me.rbYesNo.Location = New System.Drawing.Point(8, 91)
      Me.rbYesNo.Name = "rbYesNo"
      Me.rbYesNo.Size = New System.Drawing.Size(128, 13)
      Me.rbYesNo.TabIndex = 4
      Me.rbYesNo.Text = "Yes, No"
      '
      'rbYesNoCancel
      '
      Me.rbYesNoCancel.Location = New System.Drawing.Point(8, 73)
      Me.rbYesNoCancel.Name = "rbYesNoCancel"
      Me.rbYesNoCancel.Size = New System.Drawing.Size(128, 13)
      Me.rbYesNoCancel.TabIndex = 3
      Me.rbYesNoCancel.Text = "Yes, No, Cancel"
      '
      'rbAbortRetryCancel
      '
      Me.rbAbortRetryCancel.Location = New System.Drawing.Point(9, 52)
      Me.rbAbortRetryCancel.Name = "rbAbortRetryCancel"
      Me.rbAbortRetryCancel.Size = New System.Drawing.Size(136, 16)
      Me.rbAbortRetryCancel.TabIndex = 2
      Me.rbAbortRetryCancel.Text = "Abort, Retry, Ignore"
      '
      'rbOkCancel
      '
      Me.rbOkCancel.Location = New System.Drawing.Point(8, 34)
      Me.rbOkCancel.Name = "rbOkCancel"
      Me.rbOkCancel.Size = New System.Drawing.Size(128, 13)
      Me.rbOkCancel.TabIndex = 1
      Me.rbOkCancel.Text = "Ok, Cancel"
      '
      'rbOk
      '
      Me.rbOk.Checked = True
      Me.rbOk.Location = New System.Drawing.Point(8, 16)
      Me.rbOk.Name = "rbOk"
      Me.rbOk.Size = New System.Drawing.Size(128, 13)
      Me.rbOk.TabIndex = 0
      Me.rbOk.TabStop = True
      Me.rbOk.Text = "Ok"
      '
      'GroupBox2
      '
      Me.GroupBox2.Controls.AddRange(New System.Windows.Forms.Control() {Me.rbButton3, Me.rbButton2, Me.rbButton1})
      Me.GroupBox2.Location = New System.Drawing.Point(16, 144)
      Me.GroupBox2.Name = "GroupBox2"
      Me.GroupBox2.Size = New System.Drawing.Size(152, 80)
      Me.GroupBox2.TabIndex = 8
      Me.GroupBox2.TabStop = False
      Me.GroupBox2.Text = "Default Button"
      '
      'rbButton3
      '
      Me.rbButton3.Location = New System.Drawing.Point(8, 50)
      Me.rbButton3.Name = "rbButton3"
      Me.rbButton3.Size = New System.Drawing.Size(112, 16)
      Me.rbButton3.TabIndex = 2
      Me.rbButton3.Text = "Button3"
      '
      'rbButton2
      '
      Me.rbButton2.Location = New System.Drawing.Point(8, 33)
      Me.rbButton2.Name = "rbButton2"
      Me.rbButton2.Size = New System.Drawing.Size(112, 16)
      Me.rbButton2.TabIndex = 1
      Me.rbButton2.Text = "Button2"
      '
      'rbButton1
      '
      Me.rbButton1.Checked = True
      Me.rbButton1.Location = New System.Drawing.Point(8, 16)
      Me.rbButton1.Name = "rbButton1"
      Me.rbButton1.Size = New System.Drawing.Size(112, 16)
      Me.rbButton1.TabIndex = 0
      Me.rbButton1.TabStop = True
      Me.rbButton1.Text = "Button1"
      '
      'btnCritical
      '
      Me.btnCritical.Image = CType(resources.GetObject("btnCritical.Image"), System.Drawing.Bitmap)
      Me.btnCritical.Location = New System.Drawing.Point(8, 232)
      Me.btnCritical.Name = "btnCritical"
      Me.btnCritical.Size = New System.Drawing.Size(40, 40)
      Me.btnCritical.TabIndex = 9
      '
      'btnQuestion
      '
      Me.btnQuestion.Image = CType(resources.GetObject("btnQuestion.Image"), System.Drawing.Bitmap)
      Me.btnQuestion.Location = New System.Drawing.Point(56, 232)
      Me.btnQuestion.Name = "btnQuestion"
      Me.btnQuestion.Size = New System.Drawing.Size(40, 40)
      Me.btnQuestion.TabIndex = 10
      '
      'btnExclamation
      '
      Me.btnExclamation.Image = CType(resources.GetObject("btnExclamation.Image"), System.Drawing.Bitmap)
      Me.btnExclamation.Location = New System.Drawing.Point(104, 232)
      Me.btnExclamation.Name = "btnExclamation"
      Me.btnExclamation.Size = New System.Drawing.Size(40, 40)
      Me.btnExclamation.TabIndex = 11
      '
      'btnInformation
      '
      Me.btnInformation.Image = CType(resources.GetObject("btnInformation.Image"), System.Drawing.Bitmap)
      Me.btnInformation.Location = New System.Drawing.Point(152, 232)
      Me.btnInformation.Name = "btnInformation"
      Me.btnInformation.Size = New System.Drawing.Size(40, 40)
      Me.btnInformation.TabIndex = 12
      '
      'txtTitle
      '
      Me.txtTitle.Location = New System.Drawing.Point(213, 24)
      Me.txtTitle.Name = "txtTitle"
      Me.txtTitle.Size = New System.Drawing.Size(241, 20)
      Me.txtTitle.TabIndex = 0
      Me.txtTitle.Text = "Default Title"
      '
      'Label1
      '
      Me.Label1.AutoSize = True
      Me.Label1.Location = New System.Drawing.Point(213, 6)
      Me.Label1.Name = "Label1"
      Me.Label1.Size = New System.Drawing.Size(26, 13)
      Me.Label1.TabIndex = 7
      Me.Label1.Text = "Title"
      '
      'txtMessage
      '
      Me.txtMessage.Location = New System.Drawing.Point(213, 64)
      Me.txtMessage.Multiline = True
      Me.txtMessage.Name = "txtMessage"
      Me.txtMessage.ScrollBars = System.Windows.Forms.ScrollBars.Both
      Me.txtMessage.Size = New System.Drawing.Size(241, 104)
      Me.txtMessage.TabIndex = 1
      Me.txtMessage.Text = "Default Message"
      Me.txtMessage.WordWrap = False
      '
      'Label2
      '
      Me.Label2.AutoSize = True
      Me.Label2.Location = New System.Drawing.Point(215, 50)
      Me.Label2.Name = "Label2"
      Me.Label2.Size = New System.Drawing.Size(194, 13)
      Me.Label2.TabIndex = 9
      Me.Label2.Text = "Message (Press Enter for Multi-Lines)"
      '
      'txtCode
      '
      Me.txtCode.Location = New System.Drawing.Point(213, 192)
      Me.txtCode.Multiline = True
      Me.txtCode.Name = "txtCode"
      Me.txtCode.ScrollBars = System.Windows.Forms.ScrollBars.Both
      Me.txtCode.Size = New System.Drawing.Size(241, 72)
      Me.txtCode.TabIndex = 20
      Me.txtCode.TabStop = False
      Me.txtCode.Text = ""
      Me.txtCode.WordWrap = False
      '
      'Label3
      '
      Me.Label3.AutoSize = True
      Me.Label3.Location = New System.Drawing.Point(217, 177)
      Me.Label3.Name = "Label3"
      Me.Label3.Size = New System.Drawing.Size(31, 13)
      Me.Label3.TabIndex = 11
      Me.Label3.Text = "Code"
      '
      'chkSystemModal
      '
      Me.chkSystemModal.ForeColor = System.Drawing.Color.Red
      Me.chkSystemModal.Location = New System.Drawing.Point(464, 16)
      Me.chkSystemModal.Name = "chkSystemModal"
      Me.chkSystemModal.Size = New System.Drawing.Size(72, 32)
      Me.chkSystemModal.TabIndex = 13
      Me.chkSystemModal.Text = "System Modal"
      '
      'chkApplicationModal
      '
      Me.chkApplicationModal.Location = New System.Drawing.Point(464, 56)
      Me.chkApplicationModal.Name = "chkApplicationModal"
      Me.chkApplicationModal.Size = New System.Drawing.Size(79, 40)
      Me.chkApplicationModal.TabIndex = 14
      Me.chkApplicationModal.Text = "Application Modal"
      '
      'btnTest
      '
      Me.btnTest.Location = New System.Drawing.Point(464, 98)
      Me.btnTest.Name = "btnTest"
      Me.btnTest.Size = New System.Drawing.Size(80, 24)
      Me.btnTest.TabIndex = 2
      Me.btnTest.Text = "&Test"
      '
      'btnPasteCode
      '
      Me.btnPasteCode.Location = New System.Drawing.Point(464, 130)
      Me.btnPasteCode.Name = "btnPasteCode"
      Me.btnPasteCode.Size = New System.Drawing.Size(80, 24)
      Me.btnPasteCode.TabIndex = 3
      Me.btnPasteCode.Text = "&Paste Code"
      '
      'btnCopyToClipboard
      '
      Me.btnCopyToClipboard.Location = New System.Drawing.Point(464, 162)
      Me.btnCopyToClipboard.Name = "btnCopyToClipboard"
      Me.btnCopyToClipboard.Size = New System.Drawing.Size(80, 40)
      Me.btnCopyToClipboard.TabIndex = 4
      Me.btnCopyToClipboard.Text = "&Copy to Clipboard"
      '
      'btnCancel
      '
      Me.btnCancel.Location = New System.Drawing.Point(464, 246)
      Me.btnCancel.Name = "btnCancel"
      Me.btnCancel.Size = New System.Drawing.Size(80, 24)
      Me.btnCancel.TabIndex = 6
      Me.btnCancel.Text = "Ca&ncel"
      '
      'btnRefreshCode
      '
      Me.btnRefreshCode.Location = New System.Drawing.Point(464, 210)
      Me.btnRefreshCode.Name = "btnRefreshCode"
      Me.btnRefreshCode.Size = New System.Drawing.Size(80, 32)
      Me.btnRefreshCode.TabIndex = 5
      Me.btnRefreshCode.Text = "&Refresh Code"
      '
      'frmMessageBox
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(552, 277)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnRefreshCode, Me.btnCancel, Me.btnCopyToClipboard, Me.btnPasteCode, Me.btnTest, Me.chkApplicationModal, Me.chkSystemModal, Me.Label3, Me.Label2, Me.Label1, Me.txtCode, Me.txtMessage, Me.txtTitle, Me.btnInformation, Me.btnExclamation, Me.btnQuestion, Me.btnCritical, Me.GroupBox2, Me.GroupBox1})
      Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
      Me.Name = "frmMessageBox"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
      Me.Text = "Message Box Designer"
      Me.TopMost = True
      Me.GroupBox1.ResumeLayout(False)
      Me.GroupBox2.ResumeLayout(False)
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub rbOk_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbOk.CheckedChanged
      intMBOptions = 0
      strMBType = "S"
      EnableDefaultButtons(1)
   End Sub

   Private Sub rbOkCancel_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbOkCancel.CheckedChanged
      strMBType = "F"
      EnableDefaultButtons(2)
      intMBOptions = 1
   End Sub

   Private Sub rbRetryCancel_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbRetryCancel.CheckedChanged
      strMBType = "F"
      EnableDefaultButtons(2)
      intMBOptions = 5
   End Sub

   Private Sub rbYesNo_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbYesNo.CheckedChanged
      strMBType = "F"
      EnableDefaultButtons(2)
      intMBOptions = 4
   End Sub

   Private Sub rbYesNoCancel_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbYesNoCancel.CheckedChanged
      strMBType = "F"
      EnableDefaultButtons(3)
      intMBOptions = 3
   End Sub

   Private Sub rbAbortRetryCancel_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbAbortRetryCancel.CheckedChanged
      strMBType = "F"
      EnableDefaultButtons(3)
      intMBOptions = 2
   End Sub

   Private Sub btnCritical_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCritical.Click
      intMBIcon = vbCritical
   End Sub

   Private Sub btnQuestion_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuestion.Click
      intMBIcon = vbQuestion
   End Sub

   Private Sub btnExclamation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExclamation.Click
      intMBIcon = vbExclamation
   End Sub

   Private Sub btnInformation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInformation.Click
      intMBIcon = vbInformation
   End Sub

   Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTest.Click
      TestMsgBoxProc()
   End Sub

   Private Sub btnPasteCode_Click(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles btnPasteCode.Click
      Dim strMBPaintMsg As String
      Dim s As String

      Try
         If iLangType = 8 Then
            strMBPaintMsg = SetUpPaintProc()
         Else
            strMBPaintMsg = SetUpPaintProcForCLang()
         End If

         oUtil.PutCodeBack(strMBPaintMsg)
         Me.Dispose()
      Catch ee As System.Exception
         MsgBox(ee.Message)
      End Try
   End Sub
   Private Function SetUpPaintProc() As String
      Dim intNL As Integer
      Dim i As Integer
      Dim strTemp As String
      Dim strTemp2 As String
      Dim iDefault As Integer
      Dim strM As New StringBuilder()
      Dim oUtil As New Utilities(oVB)

      If strMBType = "F" Then
         strM.Append("Dim sMsg as string" & vbCrLf)
         strM.Append("Dim iRV as integer" & vbCrLf)
      Else
         strM.Append("Dim sMsg as string" & vbCrLf)
      End If

      strTemp = CStr(txtMessage.Text)
      intNL = oUtil.MLCount(strTemp, 0)

      ' we have to build msg lines
      For i = 1 To intNL
         strTemp2 = oUtil.MemoLine(strTemp, 0, i)

         If i = 1 Then
            strM.Append("sMsg = " & Chr(34) & strTemp2 & Chr(34))
         Else
            strM.Append("sMsg = sMsg & " & Chr(34) & strTemp2 & Chr(34))
         End If

         ' If last line
         If intNL = 1 Then
            strM.Append(vbCrLf)
         ElseIf i < intNL Then
            strM.Append(" & Chr(10)" & vbCrLf)
         ElseIf i = intNL Then
            strM.Append(vbCrLf)
         End If
      Next i

      ' now build the options
      If rbButton1.Checked Then
         iDefault = CType(vbDefaultButton1, Integer)
      ElseIf rbButton2.Checked Then
         iDefault = CType(vbDefaultButton2, Integer)
      Else
         iDefault = CType(vbDefaultButton3, Integer)
      End If

      strTemp = Format$(intMBOptions + _
         iDefault + _
         intMBSystemModal + _
         CType(IIf(intMBSystemModal = 0, intMBIcon, 0), Integer), "####")
      If Trim(strTemp) = "" Then
         strTemp = "0"
      End If

      ' now build the MsgBox call
      If strMBType = "S" Then
         ' build a statement
         strM.Append("MsgBox sMsg, " & strTemp & ", ")
         strM.Append(Chr(34) & Trim(CStr(txtTitle.Text)) & Chr(34) & vbCrLf & vbCrLf)
      Else
         ' build a function call
         strM.Append("iRV = MsgBox(sMsg, " & strTemp & ", ")
         strM.Append(Chr(34) & Trim(CStr(txtTitle.Text)) & Chr(34) & ")" & vbCrLf)
         strM.Append(vbCrLf)

         ' now set up the analysis code
         Select Case intMBOptions
            Case 0
               ' Ok button
            Case 1
               ' OkCancel
               strM.Append("If iRV = 1 Then" & vbCrLf)
               strM.Append("   ' Ok Code goes here" & vbCrLf)
               strM.Append("Else" & vbCrLf)
               strM.Append("   ' Cancel code goes here" & vbCrLf)
               strM.Append("End If" & vbCrLf)
            Case 2
               ' Abort, Retry, Ignore
               strM.Append("If iRV = 3 Then" & vbCrLf)
               strM.Append("   ' Abort Code goes here" & vbCrLf)
               strM.Append("ElseIf iRV = 4 Then" & vbCrLf)
               strM.Append("   ' Retry code goes here" & vbCrLf)
               strM.Append("Else" & vbCrLf)
               strM.Append("   ' Cancel code goes here" & vbCrLf)
               strM.Append("End If" & vbCrLf)
            Case 3
               ' Yes, No, Cancel
               strM.Append("If iRV = 6 Then" & vbCrLf)
               strM.Append("   ' Yes Code goes here" & vbCrLf)
               strM.Append("ElseIf iRV = 7 Then" & vbCrLf)
               strM.Append("   ' No code goes here" & vbCrLf)
               strM.Append("Else" & vbCrLf)
               strM.Append("   ' Cancel code goes here" & vbCrLf)
               strM.Append("End If" & vbCrLf)
            Case 4
               ' YesNo
               strM.Append("If iRV = 6 Then" & vbCrLf)
               strM.Append("   ' Yes Code goes here" & vbCrLf)
               strM.Append("Else" & vbCrLf)
               strM.Append("   ' No code goes here" & vbCrLf)
               strM.Append("End If" & vbCrLf)
            Case 5
               ' RetryCancel
               strM.Append("If iRV = 4 Then" & vbCrLf)
               strM.Append("   ' Retry Code goes here" & vbCrLf)
               strM.Append("Else" & vbCrLf)
               strM.Append("   ' Cancel code goes here" & vbCrLf)
               strM.Append("End If" & vbCrLf)
         End Select
      End If
      Return strM.ToString
   End Function

   Private Function SetUpPaintProcForCLang() As String
      Dim intNL As Integer
      Dim i As Integer
      Dim strTemp As String
      Dim strTemp2 As String
      Dim sDefaultBtn As String
      Dim strM As New StringBuilder()
      Dim oUtil As New Utilities(oVB)
      Dim sButtons As String
      Dim sIcon As String
      Dim sTitle As String = Chr(34) & Me.txtTitle.Text & Chr(34)

      Try
         If strMBType = "F" Then
            strM.Append("string sMsg;" & vbCrLf)
         Else
            strM.Append("string sMsg;" & vbCrLf)
         End If

         strTemp = CStr(txtMessage.Text)
         intNL = oUtil.MLCount(strTemp, 0)

         ' we have to build msg lines
         For i = 1 To intNL
            strTemp2 = oUtil.MemoLine(strTemp, 0, i)

            If i = 1 Then
               strM.Append("sMsg = " & Chr(34) & _
                  strTemp2 & "\n" & Chr(34) & ";" & vbCrLf)
            Else
               strM.Append("sMsg = sMsg + " & Chr(34) & _
                  strTemp2 & "\n" & Chr(34) & ";" & vbCrLf)
            End If
         Next i

         ' now build the options
         ' Create the default button string
         If rbButton1.Checked Then
            sDefaultBtn = "MessageBoxDefaultButton.Button1"
         ElseIf rbButton2.Checked Then
            sDefaultBtn = "MessageBoxDefaultButton.Button2"
         Else
            sDefaultBtn = "MessageBoxDefaultButton.Button3"
         End If

         ' create the buttons string
         Select Case True
            Case Me.rbOkCancel.Checked
               sButtons = "MessageBoxButtons.OKCancel"
            Case Me.rbOk.Checked
               sButtons = "MessageBoxButtons.OK"
            Case Me.rbAbortRetryCancel.Checked
               sButtons = "MessageBoxButtons.AbortRetryIgnore"
            Case Me.rbRetryCancel.Checked
               sButtons = "MessageBoxButtons.RetryCancel"
            Case Me.rbYesNo.Checked
               sButtons = "MessageBoxButtons.YesNo"
            Case Me.rbYesNoCancel.Checked
               sButtons = "MessageBoxButtons.YesNoCancel"
         End Select

         ' create the icon string
         Select Case intMBIcon
            Case vbQuestion
               sIcon = "MessageBoxIcon.Question"
            Case vbExclamation
               sIcon = "MessageBoxIcon.Exclamation"
            Case vbInformation
               sIcon = "MessageBoxIcon.Information"
            Case vbCritical
               sIcon = "MessageBoxIcon.Stop"
            Case Else
               sIcon = "MessageBoxIcon.Information"
         End Select

         ' now build the MsgBox call
         ' build a statement
         strM.Append("DialogResult iRV = MessageBox.Show(sMsg, " & _
                     sTitle & ", " & _
                     sButtons & ", " & _
                     sIcon & ", " & _
                     sDefaultBtn & ");" & vbCrLf)

         If strMBType = "F" Then

            ' now set up the analysis code
            Select Case intMBOptions
               Case 0
                  ' Ok button
               Case 1
                  ' OkCancel
                  strM.Append("switch (iRV)" & vbCrLf & _
                              "{" & vbCrLf & _
                              "   case DialogResult.OK:" & vbCrLf & _
                              "      // Ok code goes here" & vbCrLf & _
                              "      break;" & vbCrLf & _
                              "   default:" & vbCrLf & _
                              "      // cancel code goes here" & vbCrLf & _
                              "      break;" & vbCrLf & _
                              "}" & vbCrLf)
               Case 2
                  ' Abort, Retry, Ignore
                  strM.Append("switch (iRV)" & vbCrLf & _
                              "{" & vbCrLf & _
                              "   case DialogResult.Abort:" & vbCrLf & _
                              "      // Abort code goes here" & vbCrLf & _
                              "      break;" & vbCrLf & _
                              "   case DialogResult.Retry:" & vbCrLf & _
                              "      // retry code goes here" & vbCrLf & _
                              "      break;" & vbCrLf & _
                              "   default:" & vbCrLf & _
                              "      // Ignore code goes here" & vbCrLf & _
                              "      break;" & vbCrLf & _
                              "}" & vbCrLf)
               Case 3
                  ' Yes, No, Cancel
                  strM.Append("switch (iRV)" & vbCrLf & _
                              "{" & vbCrLf & _
                              "   case DialogResult.Yes:" & vbCrLf & _
                              "      // Yes code goes here" & vbCrLf & _
                              "      break;" & vbCrLf & _
                              "   case DialogResult.No:" & vbCrLf & _
                              "      // No code goes here" & vbCrLf & _
                              "      break;" & vbCrLf & _
                              "   default:" & vbCrLf & _
                              "      // Cancel code goes here" & vbCrLf & _
                              "      break;" & vbCrLf & _
                              "}" & vbCrLf)
               Case 4
                  ' YesNo
                  strM.Append("switch (iRV)" & vbCrLf & _
                              "{" & vbCrLf & _
                              "   case DialogResult.Yes:" & vbCrLf & _
                              "      // Yes code goes here" & vbCrLf & _
                              "      break;" & vbcrlf & _
                              "   default:" & vbCrLf & _
                              "      // No code goes here" & vbCrLf & _
                              "      break;" & vbCrLf & _
                              "}" & vbCrLf)
               Case 5
                  ' RetryCancel
                  strM.Append("switch (iRV)" & vbCrLf & _
                              "{" & vbCrLf & _
                              "   case DialogResult.Retry:" & vbCrLf & _
                              "      // Retry code goes here" & vbCrLf & _
                              "      break;" & vbCrLf & _
                              "   default:" & vbCrLf & _
                              "      // cancel code goes here" & vbCrLf & _
                              "      break;" & vbCrLf & _
                              "}" & vbCrLf)
            End Select
         End If
         Return strM.ToString
      Catch e As System.Exception
         MsgBox("Error in SetupPaintforCLang: " & e.Message)
      End Try
   End Function

   Private Sub TestMsgBoxProc()
      Dim intNL As Integer
      Dim i As Integer
      Dim strTemp As String
      Dim strTemp2 As String
      Dim strM As String
      Dim iDefault As Integer
      Dim j As Integer
      Dim oUtil As New Utilities(oVB)

      Try
         strTemp = CStr(txtMessage.Text)
         intNL = oUtil.MLCount(strTemp, 0)

         ' we have to build msg line
         For i = 1 To intNL
            strTemp2 = oUtil.MemoLine(strTemp, 0, i)
            strM = strM & strTemp2 & CType(IIf(i <> intNL, _
               Chr(13) & Chr(10), ""), String)
         Next i

         iDefault = CType(IIf(rbButton1.Checked, _
            vbDefaultButton1, _
            IIf(rbButton2.Checked, _
            vbDefaultButton2, _
            vbDefaultButton3)), _
            Integer)

         j = CType(intMBOptions + iDefault + intMBSystemModal + _
            CType(IIf(intMBSystemModal > 0, 0, intMBIcon), _
            Integer), Integer)
         MsgBox(strM, CType(j, MsgBoxStyle), txtTitle.Text)
      Catch e As System.Exception
         MsgBox(e.Message)
      End Try
   End Sub
   Sub EnableDefaultButtons(ByVal iButtonCount As Integer)
      Select Case iButtonCount
         Case 1
            rbButton2.Enabled = False
            rbButton3.Enabled = False
            rbButton1.Checked = True
         Case 2
            rbButton2.Enabled = True
            rbButton3.Enabled = False
            rbButton1.Checked = True
         Case 3
            rbButton2.Enabled = True
            rbButton3.Enabled = True
      End Select
   End Sub


   Private Sub btnRefreshCode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRefreshCode.Click
      Dim s As String
      If iLangType = 8 Then ' vb
         s = SetUpPaintProc()
      Else
         s = SetUpPaintProcForCLang()
      End If
      Me.txtCode.Text = s
   End Sub

   Private Sub btnCopyToClipboard_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCopyToClipboard.Click
      Dim s As String
      Dim datobj As New System.Windows.Forms.DataObject()

      If iLangType = 8 Then
         s = SetUpPaintProc()
      Else
         s = SetUpPaintProcForCLang()
      End If

      datobj.SetData(System.Windows.Forms.DataFormats.Text, s)
      System.Windows.Forms.Clipboard.SetDataObject(datobj)
   End Sub

   Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
      Me.Dispose()
      System.Windows.Forms.Application.DoEvents()
   End Sub


   Private Sub txtTitle_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtTitle.Enter
      txtTitle.SelectAll()
   End Sub

   Private Sub txtMessage_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtMessage.Enter
      txtTitle.SelectAll()
   End Sub

   Private Sub chkSystemModal_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkSystemModal.CheckedChanged
      If chkSystemModal.Checked = 1 Then
         intMBSystemModal = 4096
         intMBIcon = 0
      Else
         intMBSystemModal = 0
         intMBIcon = 16
      End If
   End Sub

   Private Sub chkApplicationModal_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkApplicationModal.CheckedChanged
      If chkApplicationModal.Checked = 1 Then
         intMBSystemModal = vbApplicationModal
         intMBIcon = 0
      Else
         intMBSystemModal = 0
         intMBIcon = 16
      End If
   End Sub
End Class
