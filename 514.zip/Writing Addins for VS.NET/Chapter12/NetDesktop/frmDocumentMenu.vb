Public Class frmDocumentMenu
    Inherits System.Windows.Forms.Form
   Private oVB As EnvDTE.DTE
#Region " Windows Form Designer generated code "

   Public Sub New(ByVal roVB As EnvDTE.DTE)
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
      oVB = roVB
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents lblLastChange As System.Windows.Forms.Label
   Friend WithEvents lblDocumentModule As System.Windows.Forms.Label
   Friend WithEvents lblContextComment As System.Windows.Forms.Label
   Friend WithEvents Timer1 As System.Windows.Forms.Timer
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.components = New System.ComponentModel.Container()
      Me.lblLastChange = New System.Windows.Forms.Label()
      Me.lblDocumentModule = New System.Windows.Forms.Label()
      Me.lblContextComment = New System.Windows.Forms.Label()
      Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
      Me.SuspendLayout()
      '
      'lblLastChange
      '
      Me.lblLastChange.Location = New System.Drawing.Point(0, 31)
      Me.lblLastChange.Name = "lblLastChange"
      Me.lblLastChange.Size = New System.Drawing.Size(124, 16)
      Me.lblLastChange.TabIndex = 14
      Me.lblLastChange.Text = "Document &Last Change"
      '
      'lblDocumentModule
      '
      Me.lblDocumentModule.Location = New System.Drawing.Point(0, 16)
      Me.lblDocumentModule.Name = "lblDocumentModule"
      Me.lblDocumentModule.Size = New System.Drawing.Size(124, 16)
      Me.lblDocumentModule.TabIndex = 13
      Me.lblDocumentModule.Text = "Document &Module"
      '
      'lblContextComment
      '
      Me.lblContextComment.BackColor = System.Drawing.Color.LightGray
      Me.lblContextComment.ForeColor = System.Drawing.Color.Black
      Me.lblContextComment.Location = New System.Drawing.Point(0, 1)
      Me.lblContextComment.Name = "lblContextComment"
      Me.lblContextComment.Size = New System.Drawing.Size(124, 16)
      Me.lblContextComment.TabIndex = 12
      Me.lblContextComment.Text = "Context &Comment"
      '
      'frmDocumentMenu
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(120, 48)
      Me.ControlBox = False
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblDocumentModule, Me.lblContextComment, Me.lblLastChange})
      Me.Name = "frmDocumentMenu"
      Me.ResumeLayout(False)

   End Sub

#End Region

End Class
