Public Class frmGetComments
    Inherits System.Windows.Forms.Form
   Dim mbWait As Boolean
   Dim msComments As String
   Dim mbDirty As Boolean
   Dim miWrapColumn As Short
   Private oVB As EnvDTE.DTE
#Region " Windows Form Designer generated code "

   Public Sub New(ByVal roVB As EnvDTE.DTE)
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
      miWrapColumn = GetSetting("NETDesktop", "Settings", "WrapColumn", 65)
      Me.txtWrapColumn.Text = miWrapColumn
      oVB = roVB
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents txtEnterComments As System.Windows.Forms.TextBox
   Friend WithEvents Label1 As System.Windows.Forms.Label
   Friend WithEvents txtWrapColumn As System.Windows.Forms.TextBox
   Friend WithEvents cmdSave As System.Windows.Forms.Button
   Friend WithEvents cmdCancel As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.txtEnterComments = New System.Windows.Forms.TextBox()
      Me.Label1 = New System.Windows.Forms.Label()
      Me.txtWrapColumn = New System.Windows.Forms.TextBox()
      Me.cmdSave = New System.Windows.Forms.Button()
      Me.cmdCancel = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'txtEnterComments
      '
      Me.txtEnterComments.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.txtEnterComments.Location = New System.Drawing.Point(8, 8)
      Me.txtEnterComments.Multiline = True
      Me.txtEnterComments.Name = "txtEnterComments"
      Me.txtEnterComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
      Me.txtEnterComments.Size = New System.Drawing.Size(459, 251)
      Me.txtEnterComments.TabIndex = 0
      Me.txtEnterComments.Text = ""
      '
      'Label1
      '
      Me.Label1.AutoSize = True
      Me.Label1.Location = New System.Drawing.Point(168, 272)
      Me.Label1.Name = "Label1"
      Me.Label1.Size = New System.Drawing.Size(67, 13)
      Me.Label1.TabIndex = 1
      Me.Label1.Text = "Wrap Colum"
      '
      'txtWrapColumn
      '
      Me.txtWrapColumn.Location = New System.Drawing.Point(248, 269)
      Me.txtWrapColumn.MaxLength = 2
      Me.txtWrapColumn.Name = "txtWrapColumn"
      Me.txtWrapColumn.Size = New System.Drawing.Size(24, 20)
      Me.txtWrapColumn.TabIndex = 2
      Me.txtWrapColumn.Text = "40"
      '
      'cmdSave
      '
      Me.cmdSave.Location = New System.Drawing.Point(317, 272)
      Me.cmdSave.Name = "cmdSave"
      Me.cmdSave.Size = New System.Drawing.Size(64, 24)
      Me.cmdSave.TabIndex = 3
      Me.cmdSave.Text = "&Save"
      '
      'cmdCancel
      '
      Me.cmdCancel.Location = New System.Drawing.Point(405, 272)
      Me.cmdCancel.Name = "cmdCancel"
      Me.cmdCancel.Size = New System.Drawing.Size(64, 24)
      Me.cmdCancel.TabIndex = 4
      Me.cmdCancel.Text = "&Cancel"
      '
      'frmGetComments
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(474, 301)
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdCancel, Me.cmdSave, Me.txtWrapColumn, Me.Label1, Me.txtEnterComments})
      Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
      Me.MaximizeBox = False
      Me.MinimizeBox = False
      Me.Name = "frmGetComments"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
      Me.Text = "Enter Comments"
      Me.TopMost = True
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
      msComments = Me.txtEnterComments.Text
      mbWait = False
      mbDirty = False
      If Val(Me.txtWrapColumn.Text) > 0 Then
         Connect.giWrapColumn = Val(Me.txtWrapColumn.Text)
         SaveSetting("NETDesktop", "Settings", "WrapColumn", Connect.giWrapColumn)
      End If
      Me.Dispose()
      System.Windows.Forms.Application.DoEvents()
   End Sub
   Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
      If ShouldExit Then
         mbWait = False
         mbDirty = False
         msComments = ""
         Me.Dispose()
         System.Windows.Forms.Application.DoEvents()
      End If
   End Sub

   Private Sub txtWrapColumn_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtWrapColumn.Enter
      txtWrapColumn.SelectAll()
   End Sub
   Public Function Display(ByVal s As String, _
      Optional ByVal sOldText As String = "") _
      As String
      ' If old comments is populated, then if there are
      ' "'`" continuation marks at the start of a line, 
      ' concatenate the next line to this one.
      Dim iNL As Long
      Dim i As Long
      Dim sLine As String
      Dim sLine2 As New System.Text.StringBuilder()
      Dim sIn As New System.Text.StringBuilder()
      Dim oUtil As New Utilities(oVB)
      Dim sCmtChars As String

      Try
         If sOldText <> "" Then
            sCmtChars = oUtil.GetCommentCharForDoc(oVB.ActiveDocument)
            iNL = oUtil.MLCount(sOldText, 0)
            For i = 1 To iNL
               sLine = Trim(oUtil.MemoLine(sOldText, 0, i))
               If sLine.StartsWith("'` ") Then
                  ' we have a continuation line so concatenate
                  ' the next line to this one
                  sLine2.Append(Mid(sLine, 4) & " ")
               ElseIf sLine.StartsWith("//` ") Then
                  ' we have a c type continued comment
                  sLine2.Append(Mid(sLine, 5) & " ")
               ElseIf sLine.StartsWith("'' ") Then
                  sIn.Append(sLine2.ToString() & Mid(sLine, 4) & vbCrLf)
                  sLine2.Remove(0, sLine2.Length)
               ElseIf sLine.StartsWith("//' ") Then
                  sIn.Append(sLine2.ToString() & Mid(sLine, 5) & vbCrLf)
                  sLine2.Remove(0, sLine2.Length)
               ElseIf sLine.StartsWith("''") Or sLine.StartsWith("'`") Then
                  sIn.Append(sLine2.ToString() & Mid(sLine, 3) & vbCrLf)
               ElseIf sLine.StartsWith("//'") Or sLine.StartsWith("//`") Then
                  sIn.Append(sLine2.ToString() & Mid(sLine, 4) & vbCrLf)
               ElseIf sLine.StartsWith(sCmtChars & " ") Then
                  sIn.Append(Replace(sLine, sCmtChars & " ", "") & vbCrLf)
               ElseIf sLine.StartsWith(sCmtChars) Then
                  sIn.Append(Replace(sLine, sCmtChars, "") & vbCrLf)
               Else
                  sIn.Append(sLine & vbCrLf)
               End If
            Next i
            sOldText = sIn.ToString()
         End If
         mbWait = True
         msComments = ""
         mbDirty = False
         Me.Text = s
         Me.txtEnterComments.Text = sOldText
         Me.Show()
         Do While mbWait
            System.Windows.Forms.Application.DoEvents()
         Loop
         Return msComments
      Catch e As System.Exception
         MsgBox(e.Message)
      End Try
   End Function
   Private Function ShouldExit() As Boolean
      Dim sMsg As String
      Dim iRV As Integer

      ShouldExit = False
      If mbDirty Then
         sMsg = "You have entered comments, are you sure" & Chr(10)
         sMsg = sMsg & "you want to exit without saving?" & Chr(10)
         sMsg = sMsg & "" & Chr(10)
         sMsg = sMsg & "Click Yes to lose changes, No to stop the " & Chr(10)
         sMsg = sMsg & "cancel."
         iRV = MsgBox(sMsg, 308, "Confirm Cancel")

         If iRV = vbYes Then
            ' Yes Code goes here
            ShouldExit = True
         End If
      End If
   End Function

   Private Sub txtEnterComments_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtEnterComments.TextChanged
      mbDirty = True
   End Sub

   Protected Overrides Sub Finalize()
      MyBase.Finalize()
   End Sub

   Private Sub frmGetComments_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
      mbWait = False
      msComments = ""
   End Sub
End Class
