Imports System.Windows.Forms.Application
Public Class frmWindowsMenu
   Inherits System.Windows.Forms.Form
   Private miTimerStart As Single
   Private miTimeToUnload As Short
   Private oVB As EnvDTE.DTE

#Region " Windows Form Designer generated code "
   Public Sub New(ByVal roVB As EnvDTE.DTE)
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
      miTimeToUnload = 5
      miTimerStart = Microsoft.VisualBasic.DateAndTime.Timer
      Me.Timer1.Interval = 500
      Me.Timer1.Enabled = True
      oVB = roVB
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents Timer1 As System.Windows.Forms.Timer
   Friend WithEvents lblCloseAndSave As System.Windows.Forms.Label
   Friend WithEvents lblCloseAllOthers As System.Windows.Forms.Label
   Friend WithEvents lblCloseAllSaved As System.Windows.Forms.Label
   Friend WithEvents lblCloseWithPrompt As System.Windows.Forms.Label
   Friend WithEvents Panel2 As System.Windows.Forms.Panel
   Friend WithEvents lblBackupCurrentWindow As System.Windows.Forms.Label
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.components = New System.ComponentModel.Container()
      Me.lblCloseAndSave = New System.Windows.Forms.Label()
      Me.lblCloseAllOthers = New System.Windows.Forms.Label()
      Me.lblCloseAllSaved = New System.Windows.Forms.Label()
      Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
      Me.lblCloseWithPrompt = New System.Windows.Forms.Label()
      Me.Panel2 = New System.Windows.Forms.Panel()
      Me.lblBackupCurrentWindow = New System.Windows.Forms.Label()
      Me.SuspendLayout()
      '
      'lblCloseAndSave
      '
      Me.lblCloseAndSave.Location = New System.Drawing.Point(0, 32)
      Me.lblCloseAndSave.Name = "lblCloseAndSave"
      Me.lblCloseAndSave.Size = New System.Drawing.Size(144, 16)
      Me.lblCloseAndSave.TabIndex = 11
      Me.lblCloseAndSave.Text = "Close && &Save All"
      '
      'lblCloseAllOthers
      '
      Me.lblCloseAllOthers.Location = New System.Drawing.Point(0, 17)
      Me.lblCloseAllOthers.Name = "lblCloseAllOthers"
      Me.lblCloseAllOthers.Size = New System.Drawing.Size(144, 16)
      Me.lblCloseAllOthers.TabIndex = 10
      Me.lblCloseAllOthers.Text = "Close All But &Current"
      '
      'lblCloseAllSaved
      '
      Me.lblCloseAllSaved.BackColor = System.Drawing.Color.LightGray
      Me.lblCloseAllSaved.ForeColor = System.Drawing.Color.Black
      Me.lblCloseAllSaved.Location = New System.Drawing.Point(0, 2)
      Me.lblCloseAllSaved.Name = "lblCloseAllSaved"
      Me.lblCloseAllSaved.Size = New System.Drawing.Size(144, 16)
      Me.lblCloseAllSaved.TabIndex = 9
      Me.lblCloseAllSaved.Text = "Close All &Saved"
      '
      'Timer1
      '
      '
      'lblCloseWithPrompt
      '
      Me.lblCloseWithPrompt.Location = New System.Drawing.Point(0, 48)
      Me.lblCloseWithPrompt.Name = "lblCloseWithPrompt"
      Me.lblCloseWithPrompt.Size = New System.Drawing.Size(144, 16)
      Me.lblCloseWithPrompt.TabIndex = 12
      Me.lblCloseWithPrompt.Text = "Close && &Save All (Prompt)"
      '
      'Panel2
      '
      Me.Panel2.BackColor = System.Drawing.SystemColors.AppWorkspace
      Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
      Me.Panel2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
      Me.Panel2.Location = New System.Drawing.Point(0, 63)
      Me.Panel2.Name = "Panel2"
      Me.Panel2.Size = New System.Drawing.Size(144, 3)
      Me.Panel2.TabIndex = 13
      '
      'lblBackupCurrentWindow
      '
      Me.lblBackupCurrentWindow.Location = New System.Drawing.Point(0, 68)
      Me.lblBackupCurrentWindow.Name = "lblBackupCurrentWindow"
      Me.lblBackupCurrentWindow.Size = New System.Drawing.Size(144, 16)
      Me.lblBackupCurrentWindow.TabIndex = 14
      Me.lblBackupCurrentWindow.Text = "&Backup Current Window"
      '
      'frmWindowsMenu
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(144, 82)
      Me.ControlBox = False
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblBackupCurrentWindow, Me.Panel2, Me.lblCloseWithPrompt, Me.lblCloseAndSave, Me.lblCloseAllOthers, Me.lblCloseAllSaved})
      Me.Name = "frmWindowsMenu"
      Me.ResumeLayout(False)

   End Sub
#End Region
   Private Sub lblCloseAllSaved_MouseLeave(ByVal sender As Object, _
      ByVal e As System.EventArgs) _
      Handles lblCloseAllSaved.MouseLeave, _
              lblCloseAllOthers.MouseLeave, _
              lblCloseAndSave.MouseLeave, _
              lblCloseWithPrompt.MouseLeave, _
              lblBackupCurrentWindow.MouseLeave
      Dim ofh As New CMenuHandler()
      ofh.HandleMouseLeave(sender, miTimerStart, miTimeToUnload)
   End Sub

   Private Sub lblCloseAllSaved_Click(ByVal sender As Object, _
      ByVal e As System.EventArgs) _
      Handles lblCloseAllSaved.Click, _
              lblCloseAllOthers.Click, _
              lblCloseAndSave.Click, _
              lblCloseWithPrompt.Click, _
              lblBackupCurrentWindow.Click
      Dim lbl As System.Windows.Forms.Label
      Dim oWin As New CWindows(oVB)
      lbl = CType(sender, System.Windows.Forms.Label)
      Me.Dispose()
      DoEvents()
      Select Case lbl.Name
         Case "lblCloseAllSaved"
            oWin.CloseAllSavedWindows()
         Case "lblCloseAllOthers"
            oWin.CloseAllButCurrentWindow()
         Case "lblCloseAndSave"
            oWin.CloseAndSaveWindows()
         Case "lblCloseWithPrompt"
            oWin.CloseAndSaveWindowsWithPrompt()
         Case "lblBackupCurrentWindow"
            oWin.BackupCurrentWindow()
      End Select
   End Sub

   Private Sub lblCloseAllSaved_MouseMove(ByVal sender As Object, _
      ByVal e As System.Windows.Forms.MouseEventArgs) _
      Handles lblCloseAllSaved.MouseMove, _
              lblCloseAllOthers.MouseMove, _
              lblCloseAndSave.MouseMove, _
              lblCloseWithPrompt.MouseMove, _
              lblBackupCurrentWindow.MouseMove
      Dim oMH As New CMenuHandler()
      oMH.HandleMouseMove(sender, miTimerStart, miTimeToUnload)
   End Sub

   Private Sub Timer1_Tick(ByVal sender As Object, _
      ByVal e As System.EventArgs) _
      Handles Timer1.Tick
      If Microsoft.VisualBasic.DateAndTime.Timer - _
         miTimerStart > miTimeToUnload Then
         Me.Dispose()
      End If
   End Sub

   Private Sub frmComment_MouseMove(ByVal sender As Object, _
      ByVal e As System.Windows.Forms.MouseEventArgs) _
      Handles MyBase.MouseMove
      miTimerStart = Microsoft.VisualBasic.DateAndTime.Timer
      miTimeToUnload = 30
   End Sub

   Private Sub frmComment_MouseLeave(ByVal sender As Object, _
      ByVal e As System.EventArgs) _
      Handles MyBase.MouseLeave
      miTimerStart = Microsoft.VisualBasic.DateAndTime.Timer
      miTimeToUnload = 0.5
   End Sub

   Private Sub Panel2_MouseLeave(ByVal sender As Object, _
      ByVal e As System.EventArgs) _
      Handles Panel2.MouseLeave
      miTimerStart = Microsoft.VisualBasic.DateAndTime.Timer
      miTimeToUnload = 0.5
   End Sub

   Private Sub Panel2_MouseMove(ByVal sender As Object, _
      ByVal e As System.Windows.Forms.MouseEventArgs) _
      Handles Panel2.MouseMove
      miTimerStart = Microsoft.VisualBasic.DateAndTime.Timer
      miTimeToUnload = 30
   End Sub
End Class
