Imports Microsoft.Office.Core
Imports Extensibility
Imports System.Runtime.InteropServices
Imports EnvDTE
Imports System.Windows.Forms
Public Class CUIMenus
   Public Function AddOfficeMenuItem(ByVal VBE As EnvDTE.DTE, _
    ByVal Menu As Microsoft.Office.Core.CommandBarControl, _
    ByVal Caption As String, _
    Optional ByVal pos As Byte = 0, _
    Optional ByVal sep As Boolean = False, _
    Optional ByVal Bitmap As Object = Nothing) _
    As Microsoft.Office.Core.CommandBarControl

      ' This method will add an office menuitem to an existing 
      ' office popupup menu
      Dim menuItem As Microsoft.Office.Core.CommandBarControl

      Try
         If Not (Bitmap Is Nothing) Then
            System.Windows.Forms.Clipboard.SetDataObject(Bitmap)
         End If

         ' Add menu item to VB menu:
         If pos = 0 Then pos = Menu.Controls.Count + 1
         menuItem = _
            Menu.Controls.Add(Type:=Microsoft.Office.Core.MsoControlType.msoControlButton, _
            Before:=pos, _
            Temporary:=True)

         ' Set properties of menu item:
         menuItem.Caption = Caption
         If sep Then menuItem.BeginGroup = True
         If Not (Bitmap Is Nothing) Then
            menuItem.Style = Microsoft.Office.Core.MsoButtonStyle.msoButtonIconAndCaption
            menuItem.PasteFace()
         End If
         Return menuItem
      Catch e As System.Exception
         Return menuItem
      End Try
   End Function

   Public Function AddOfficePopupMenu(ByVal VBE As EnvDTE.DTE, _
      ByVal Menu As Microsoft.Office.Core.CommandBarControl, _
      ByVal Caption As String, _
      Optional ByVal pos As Byte = 0, _
      Optional ByVal sep As Boolean = False) _
      As Microsoft.Office.Core.CommandBarControl

      ' This method adds an office popup menu to an existing menu
      ' The existing menu can be another popup menu.
      Dim popupMenu As Microsoft.Office.Core.CommandBarControl

      Try

         ' Add popupMenu menu to VB menu:
         If pos = 0 Then pos = Menu.Controls.Count + 1
         popupMenu = _
         Menu.Controls.Add(Type:=Microsoft.Office.Core.MsoControlType.msoControlPopup, _
         Before:=pos, _
         Temporary:=True)

         ' Set properties of popupMenu menu:
         popupMenu.Caption = Caption
         If sep Then popupMenu.BeginGroup = True
         Return popupMenu
      Catch e As System.Exception
         Return popupMenu
      End Try
   End Function


End Class
