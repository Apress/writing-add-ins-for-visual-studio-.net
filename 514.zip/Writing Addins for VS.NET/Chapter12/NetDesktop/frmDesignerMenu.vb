Imports System.Windows.Forms.Application
Public Class frmDesignerMenu
   Inherits System.Windows.Forms.Form
   Private miTimerStart As Single
   Private miTimeToUnload As Short
   Private oVB As EnvDTE.DTE
#Region " Windows Form Designer generated code "

   Public Sub New(ByVal roVB As EnvDTE.DTE)
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
      oVB = roVB
      miTimeToUnload = 5
      miTimerStart = Microsoft.VisualBasic.DateAndTime.Timer
      Me.Timer1.Interval = 500
      Me.Timer1.Enabled = True
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents lblMessageBox As System.Windows.Forms.Label
   Friend WithEvents Timer1 As System.Windows.Forms.Timer
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.components = New System.ComponentModel.Container()
      Me.lblMessageBox = New System.Windows.Forms.Label()
      Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
      Me.SuspendLayout()
      '
      'lblMessageBox
      '
      Me.lblMessageBox.BackColor = System.Drawing.Color.LightGray
      Me.lblMessageBox.ForeColor = System.Drawing.Color.Black
      Me.lblMessageBox.Location = New System.Drawing.Point(1, 1)
      Me.lblMessageBox.Name = "lblMessageBox"
      Me.lblMessageBox.Size = New System.Drawing.Size(110, 16)
      Me.lblMessageBox.TabIndex = 12
      Me.lblMessageBox.Text = "&Message Box"
      '
      'frmDesignerMenu
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(112, 19)
      Me.ControlBox = False
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblMessageBox})
      Me.Name = "frmDesignerMenu"
      Me.ResumeLayout(False)

   End Sub

#End Region
   Private Sub lblMessageBox_MouseLeave(ByVal sender As Object, _
      ByVal e As System.EventArgs) _
      Handles lblMessageBox.MouseLeave
      Dim ofh As New CMenuHandler()
      ofh.HandleMouseLeave(sender, miTimerStart, miTimeToUnload)
   End Sub

   Private Sub lblMessageBox_Click(ByVal sender As Object, _
      ByVal e As System.EventArgs) _
      Handles lblMessageBox.Click
      Dim lbl As System.Windows.Forms.Label
      lbl = CType(sender, System.Windows.Forms.Label)
      Me.Dispose()
      DoEvents()
      Select Case lbl.Name
         Case "lblMessageBox"
            Dim outil As New Utilities(oVB)
            Dim i As Integer
            i = outil.GetFileType(oVB.ActiveDocument)
            If i <> 8 And i <> 9 Then
               MsgBox("The message box designer only works for VB and C#.")
               Exit Sub
            End If
            Dim oFrm As New frmMessageBox(oVB)
            oFrm.ShowDialog()
      End Select
   End Sub

   Private Sub lblMessageBox_MouseMove(ByVal sender As Object, _
      ByVal e As System.Windows.Forms.MouseEventArgs) _
      Handles lblMessageBox.MouseMove
      Dim oMH As New CMenuHandler()
      oMH.HandleMouseMove(sender, miTimerStart, miTimeToUnload)
   End Sub

   Private Sub Timer1_Tick(ByVal sender As Object, _
      ByVal e As System.EventArgs) _
      Handles Timer1.Tick
      If Microsoft.VisualBasic.DateAndTime.Timer - _
         miTimerStart > miTimeToUnload Then
         Me.Dispose()
      End If
   End Sub

   Private Sub frmComment_MouseMove(ByVal sender As Object, _
      ByVal e As System.Windows.Forms.MouseEventArgs) _
      Handles MyBase.MouseMove
      miTimerStart = Microsoft.VisualBasic.DateAndTime.Timer
      miTimeToUnload = 30
   End Sub

   Private Sub frmComment_MouseLeave(ByVal sender As Object, _
      ByVal e As System.EventArgs) _
      Handles MyBase.MouseLeave
      miTimerStart = Microsoft.VisualBasic.DateAndTime.Timer
      miTimeToUnload = 0.5
   End Sub
End Class
