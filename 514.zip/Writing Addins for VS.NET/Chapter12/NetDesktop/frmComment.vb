Imports System.Windows.Forms.Application
Public Class frmComment
   Inherits System.Windows.Forms.Form
   Private miTimerStart As Single
   Private miTimeToUnload As Short
   Private oVB As EnvDTE.DTE

#Region " Windows Form Designer generated code "

   Public Sub New(ByRef roVB As EnvDTE.DTE)
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
      miTimeToUnload = 5
      miTimerStart = Microsoft.VisualBasic.DateAndTime.Timer
      Me.Timer1.Interval = 500
      Me.Timer1.Enabled = True
      oVB = roVB
   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents lblComment As System.Windows.Forms.Label
   Friend WithEvents lblAddition As System.Windows.Forms.Label
   Friend WithEvents lblChange As System.Windows.Forms.Label
   Friend WithEvents Panel1 As System.Windows.Forms.Panel
   Friend WithEvents lblUncomment As System.Windows.Forms.Label
   Friend WithEvents lblDelete As System.Windows.Forms.Label
   Friend WithEvents Timer1 As System.Windows.Forms.Timer
   Friend WithEvents Panel2 As System.Windows.Forms.Panel
   Friend WithEvents lblContextComment As System.Windows.Forms.Label
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.components = New System.ComponentModel.Container()
      Me.lblComment = New System.Windows.Forms.Label()
      Me.lblAddition = New System.Windows.Forms.Label()
      Me.lblChange = New System.Windows.Forms.Label()
      Me.Panel1 = New System.Windows.Forms.Panel()
      Me.lblUncomment = New System.Windows.Forms.Label()
      Me.lblDelete = New System.Windows.Forms.Label()
      Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
      Me.Panel2 = New System.Windows.Forms.Panel()
      Me.lblContextComment = New System.Windows.Forms.Label()
      Me.SuspendLayout()
      '
      'lblComment
      '
      Me.lblComment.BackColor = System.Drawing.Color.LightGray
      Me.lblComment.ForeColor = System.Drawing.Color.Black
      Me.lblComment.Location = New System.Drawing.Point(0, 1)
      Me.lblComment.Name = "lblComment"
      Me.lblComment.Size = New System.Drawing.Size(104, 16)
      Me.lblComment.TabIndex = 3
      Me.lblComment.Text = "Block &Comment"
      '
      'lblAddition
      '
      Me.lblAddition.Location = New System.Drawing.Point(0, 16)
      Me.lblAddition.Name = "lblAddition"
      Me.lblAddition.Size = New System.Drawing.Size(104, 16)
      Me.lblAddition.TabIndex = 4
      Me.lblAddition.Text = "Block &Addition"
      '
      'lblChange
      '
      Me.lblChange.Location = New System.Drawing.Point(0, 31)
      Me.lblChange.Name = "lblChange"
      Me.lblChange.Size = New System.Drawing.Size(104, 16)
      Me.lblChange.TabIndex = 5
      Me.lblChange.Text = "Block &Change"
      '
      'Panel1
      '
      Me.Panel1.BackColor = System.Drawing.SystemColors.AppWorkspace
      Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
      Me.Panel1.Location = New System.Drawing.Point(1, 62)
      Me.Panel1.Name = "Panel1"
      Me.Panel1.Size = New System.Drawing.Size(101, 3)
      Me.Panel1.TabIndex = 6
      '
      'lblUncomment
      '
      Me.lblUncomment.Location = New System.Drawing.Point(0, 67)
      Me.lblUncomment.Name = "lblUncomment"
      Me.lblUncomment.Size = New System.Drawing.Size(104, 16)
      Me.lblUncomment.TabIndex = 7
      Me.lblUncomment.Text = "Block &Uncomment"
      '
      'lblDelete
      '
      Me.lblDelete.Location = New System.Drawing.Point(0, 46)
      Me.lblDelete.Name = "lblDelete"
      Me.lblDelete.Size = New System.Drawing.Size(104, 16)
      Me.lblDelete.TabIndex = 8
      Me.lblDelete.Text = "Block &Delete"
      '
      'Timer1
      '
      '
      'Panel2
      '
      Me.Panel2.BackColor = System.Drawing.SystemColors.AppWorkspace
      Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
      Me.Panel2.Location = New System.Drawing.Point(1, 83)
      Me.Panel2.Name = "Panel2"
      Me.Panel2.Size = New System.Drawing.Size(101, 3)
      Me.Panel2.TabIndex = 9
      '
      'lblContextComment
      '
      Me.lblContextComment.Location = New System.Drawing.Point(0, 88)
      Me.lblContextComment.Name = "lblContextComment"
      Me.lblContextComment.Size = New System.Drawing.Size(104, 16)
      Me.lblContextComment.TabIndex = 10
      Me.lblContextComment.Text = "Conte&xt Comment"
      '
      'frmComment
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(104, 104)
      Me.ControlBox = False
      Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblContextComment, Me.Panel2, Me.lblDelete, Me.lblUncomment, Me.Panel1, Me.lblChange, Me.lblAddition, Me.lblComment})
      Me.Name = "frmComment"
      Me.ResumeLayout(False)

   End Sub

#End Region

   Private Sub lblComment_MouseLeave(ByVal sender As Object, _
      ByVal e As System.EventArgs) _
      Handles lblComment.MouseLeave, _
              lblAddition.MouseLeave, _
              lblDelete.MouseLeave, _
              lblChange.MouseLeave, _
              lblUncomment.MouseLeave, _
              lblContextComment.MouseLeave
      Dim ofh As New CMenuHandler()
      ofh.HandleMouseLeave(sender, miTimerStart, miTimeToUnload)
   End Sub

   Private Sub lblComment_Click(ByVal sender As Object, _
      ByVal e As System.EventArgs) _
      Handles lblComment.Click, _
              lblAddition.Click, _
              lblDelete.Click, _
              lblChange.Click, _
              lblUncomment.Click, _
              lblContextComment.Click
      Dim lbl As System.Windows.Forms.Label
      Dim oCM As New CodeManipulation(oVB)
      lbl = CType(sender, System.Windows.Forms.Label)
      Me.Dispose()
      DoEvents()
      Select Case lbl.Name
         Case "lblComment"
            oCM.BlockComment()
         Case "lblAddition"
            oCM.BlockAddition()
         Case "lblDelete"
            oCM.BlockDelete()
         Case "lblChange"
            oCM.BlockChange()
         Case "lblUncomment"
            oCM.BlockUnComment()
         Case "lblContextComment"
            oCM.EnterContextComments()
      End Select
   End Sub

   Private Sub lblComment_MouseMove(ByVal sender As Object, _
      ByVal e As System.Windows.Forms.MouseEventArgs) _
      Handles lblComment.MouseMove, _
              lblAddition.MouseMove, _
              lblDelete.MouseMove, _
              lblChange.MouseMove, _
              lblUncomment.MouseMove, _
              lblContextComment.MouseMove
      Dim oMH As New CMenuHandler()
      oMH.HandleMouseMove(sender, miTimerStart, miTimeToUnload)
   End Sub

   Private Sub Timer1_Tick(ByVal sender As Object, _
      ByVal e As System.EventArgs) Handles Timer1.Tick
      If Microsoft.VisualBasic.DateAndTime.Timer - miTimerStart > _
         miTimeToUnload Then
         Me.Dispose()
      End If
   End Sub

   Private Sub frmComment_MouseMove(ByVal sender As Object, _
      ByVal e As System.Windows.Forms.MouseEventArgs) _
      Handles MyBase.MouseMove
      miTimerStart = Microsoft.VisualBasic.DateAndTime.Timer
      miTimeToUnload = 30
   End Sub

   Private Sub frmComment_MouseLeave(ByVal sender As Object, _
      ByVal e As System.EventArgs) _
      Handles MyBase.MouseLeave
      miTimerStart = Microsoft.VisualBasic.DateAndTime.Timer
      miTimeToUnload = 0.5
   End Sub

   Private Sub Panel1_MouseLeave(ByVal sender As Object, _
      ByVal e As System.EventArgs) _
      Handles Panel1.MouseLeave, _
              Panel2.MouseLeave
      miTimerStart = Microsoft.VisualBasic.DateAndTime.Timer
      miTimeToUnload = 0.5
   End Sub

   Private Sub Panel1_MouseMove(ByVal sender As Object, _
      ByVal e As System.Windows.Forms.MouseEventArgs) _
      Handles Panel1.MouseMove, _
              Panel2.MouseMove
      miTimerStart = Microsoft.VisualBasic.DateAndTime.Timer
      miTimeToUnload = 30
   End Sub
End Class
