Imports Microsoft.Office.Core
imports Extensibility
imports System.Runtime.InteropServices
Imports EnvDTE
Imports System.Windows.Forms
<GuidAttribute("F555EECD-3A41-4925-A564-75B2FC619333"), _
ProgIdAttribute("NetDesktop.Connect")> _
Public Class Connect
   Implements Extensibility.IDTExtensibility2
   Public Shared giWrapColumn As Short
   Dim oVB As EnvDTE.DTE
   Dim addInInstance As EnvDTE.AddIn
   Dim frm As New frmPictures()
   Dim oRemind As CReminders

   ' declare instance of CUserInterface Class
   Private oUI As CUIToolBar

   ' declare toolbar object
   Private TBar As Microsoft.Office.Core.CommandBar
   Private Kind As Byte

   ' declare toolbar command buttons
   Private mcbComment As Microsoft.Office.Core.CommandBarControl
   Private mcbDocument As Microsoft.Office.Core.CommandBarControl
   Private mcbWindows As Microsoft.Office.Core.CommandBarControl
   Private mcbClone As Microsoft.Office.Core.CommandBarControl
   Private mcbSetupAbout As Microsoft.Office.Core.CommandBarControl
   Private mcbDesigner As Microsoft.Office.Core.CommandBarControl

   ' declare commandbar event handlers
   Public WithEvents mnuCommentHandler As EnvDTE.CommandBarEvents
   Public WithEvents mnuDocumentHandler As EnvDTE.CommandBarEvents
   Public WithEvents mnuWindowsHandler As EnvDTE.CommandBarEvents
   Public WithEvents mnuCloneHandler As EnvDTE.CommandBarEvents
   Public WithEvents mnuSetupAboutHandler As EnvDTE.CommandBarEvents
   Public WithEvents mnuDesignerHandler As EnvDTE.CommandBarEvents

   ' declare DTE events we want to handle
   Public WithEvents eventWindows As EnvDTE.WindowEvents
   Public WithEvents taskListEvents As EnvDTE.TaskListEvents

   Public Sub OnBeginShutdown(ByRef custom As System.Array) _
      Implements Extensibility.IDTExtensibility2.OnBeginShutdown
   End Sub

   Public Sub OnAddInsUpdate(ByRef custom As System.Array) _
      Implements Extensibility.IDTExtensibility2.OnAddInsUpdate
   End Sub

   Public Sub OnStartupComplete(ByRef custom As System.Array) _
      Implements Extensibility.IDTExtensibility2.OnStartupComplete
   End Sub

   Public Sub OnDisconnection(ByVal RemoveMode As _
      Extensibility.ext_DisconnectMode, _
      ByRef custom As System.Array) _
      Implements Extensibility.IDTExtensibility2.OnDisconnection
      Try
         mcbComment.Delete()
         'mcbDocument.Delete()
         mcbWindows.Delete()
         mcbDesigner.Delete()
         mcbSetupAbout.Delete()
         TBar.Delete()
         eventWindows = Nothing
         taskListEvents = Nothing
      Catch e As System.Exception
         MsgBox("Error deleting commands in OnDisconnection: " & _
                e.Message, MsgBoxStyle.Critical)
      End Try
   End Sub

   Public Sub OnConnection(ByVal application As Object, _
      ByVal connectMode As Extensibility.ext_ConnectMode, _
      ByVal addInInst As Object, ByRef custom As System.Array) _
      Implements Extensibility.IDTExtensibility2.OnConnection

      oVB = CType(application, EnvDTE.DTE)
      addInInstance = CType(addInInst, EnvDTE.AddIn)
      Try
         oUI = New CUIToolBar()

         ' load the form with the pictures on it
         frm.Show()
         frm.Hide()
         System.Windows.Forms.Application.DoEvents()

         ' create the add-ins toolbar
         CreateOfficeToolBar()

         ' Add the tool buttons to the add-in toolbar
         CreateOfficeToolBarButtons()

         ' don't need the form anymore, destroy it
         frm.Dispose()

         ' link DTE events we want to handle
         Dim events As EnvDTE.Events
         events = oVB.Events
         eventWindows = CType(events.WindowEvents(Nothing), EnvDTE.WindowEvents)
         taskListEvents = CType(events.TaskListEvents(Nothing), EnvDTE.WindowEvents)
         oRemind = New CReminders(oVB)

      Catch e As System.Exception

      End Try
   End Sub
   Private Sub CreateOfficeToolBar()
      ' This method creates the office toolbar
      TBar = oUI.AddOfficeToolBar(oVB, _
                            "NETDesktopTBar", _
                             False)
   End Sub
   Private Sub CreateOfficeToolBarButtons()
      ' This method calls the low level method that
      ' adds the tool buttons to the tool bar
      ' The paired commands do two things.
      ' 1) created the toolbar or button
      ' 2) link the command event to the event handler.
      Try
         ' note that the bitmap can come from a variety
         ' of places.  Here it is pulled from an imagelist
         mcbComment = oUI.AddOfficeToolBarButton(oVB, _
            TBar, "Comment Menu", frm.ImageList1.Images(78))
         mnuCommentHandler = CType(oVB.Events.CommandBarEvents(mcbComment), _
            EnvDTE.CommandBarEvents)

         mcbWindows = oUI.AddOfficeToolBarButton(oVB, _
            TBar, "Windows Menu", frm.ImageList1.Images(83))
         mnuWindowsHandler = CType(oVB.Events.CommandBarEvents(mcbWindows), _
            EnvDTE.CommandBarEvents)

         'mcbDocument = oUI.AddOfficeToolBarButton(oVB, _
         '   TBar, "Documentation Menu", frm.pic5.Image)
         'mnuDocumentHandler = CType(oVB.Events.CommandBarEvents(mcbDocument), _
         '   EnvDTE.CommandBarEvents)

         mcbDesigner = oUI.AddOfficeToolBarButton(oVB, _
            TBar, "Designers", frm.ImageList1.Images(80))
         mnuDesignerHandler = CType(oVB.Events.CommandBarEvents(mcbDesigner), _
            EnvDTE.CommandBarEvents)

         'mcbClone = oUI.AddOfficeToolBarButton(oVB, _
         '   TBar, "Clone Menu", frm.ImageList1.Images(28))
         'mnuCloneHandler = CType(oVB.Events.CommandBarEvents(mcbClone), _
         '   EnvDTE.CommandBarEvents)

         mcbSetupAbout = oUI.AddOfficeToolBarIconAndCaption(oVB, _
                              TBar, "About NET Desktop", frm.ImageList1.Images(79))
         mnuSetupAboutHandler = CType(oVB.Events.CommandBarEvents(mcbSetupAbout), _
            EnvDTE.CommandBarEvents)

      Catch e As System.Exception
         MsgBox(e.Message)
      End Try
   End Sub

   Private Sub mnuCommentHandler_Click(ByVal CommandBarControl As Object, _
      ByRef handled As Boolean, _
      ByRef CancelDefault As Boolean) _
      Handles mnuCommentHandler.Click, _
              mnuWindowsHandler.Click, _
              mnuDocumentHandler.Click, _
              mnuDesignerHandler.Click, _
              mnuSetupAboutHandler.Click
      'mnuCloneHandler.Click
      Dim oFH As New CMenuHandler()
      Try
         Select Case CommandBarControl.caption
            Case "Comment Menu"
               Dim oFRM As New frmComment(oVB)
               oFH.LoadMenuForm(oVB, mcbComment, oFRM)
            Case "Windows Menu"
               Dim oFRM As New frmWindowsMenu(oVB)
               oFH.LoadMenuForm(oVB, mcbWindows, ofrm)
            Case "Documentation Menu"
               Dim oFRM As New frmDocumentMenu(oVB)
               oFH.LoadMenuForm(oVB, mcbDocument, ofrm)
            Case "Designers"
               Dim oFRM As New frmDesignerMenu(oVB)
               oFH.LoadMenuForm(oVB, mcbDesigner, ofrm)
               'Case "Clone Menu"
               ' Dim oFRM As New frmCloneMenu(oVB)
               'oFH.LoadMenuForm(oVB, mcbClone, oFRM)
            Case "About NET Desktop"
               Dim oFRM As New frmAbout(oVB)
               ofrm.ShowDialog()
         End Select
         handled = True
      Catch e As System.Exception
         MsgBox(e.Message)
      End Try
   End Sub

   ' Event handlers for DTE events we are handling
   Private Sub eventWindows_WindowActivated(ByVal GotFocus As EnvDTE.Window, _
      ByVal LostFocus As EnvDTE.Window) Handles eventWindows.WindowActivated
      ' Let's do something useful
      ' if the window name is a default name, e.g, Form(n),
      ' Module(n) or Class(n)
      ' suggest to the user that they need to rename it
      oRemind.CkForRemindOfDefaultName(GotFocus.Caption)

      ' task item removed does not always fire because of
      ' multiple events firing, so place the calls in this
      ' event to kludge the closing of the task list
      If GotFocus.Caption.StartsWith("Task List") Then
         oRemind.CkForClosingTaskList()
      End If
      If LostFocus.Caption.StartsWith("Task List") Then
         oRemind.CkForClosingTaskList()
      End If
   End Sub
   Private Sub taskListEvents_TaskAdded(ByVal TaskItem As EnvDTE.TaskItem) _
      Handles taskListEvents.TaskAdded
      ' activate the task window
      oRemind.ActivateTaskList()
   End Sub
End Class
