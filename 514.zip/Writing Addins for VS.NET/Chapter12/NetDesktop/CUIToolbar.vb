Imports Microsoft.Office.Core
Imports Extensibility
Imports System.Runtime.InteropServices
Imports EnvDTE
Imports System.Windows.Forms

Public Class CUIToolBar
   Public Function AddOfficeToolBar(ByVal VBE As EnvDTE.DTE, _
      ByVal Caption As String, _
      Optional ByVal Floating As Boolean = False) _
      As Microsoft.Office.Core.CommandBar

      ' This method adds an office commandbar (toolbar) to
      ' the IDE.  It will become the container for command buttons.
      Dim Kind As Byte
      Dim toolBar As Microsoft.Office.Core.CommandBar

      Try

         ' Set parameter for pos argument:
         If Floating Then
            Kind = Microsoft.Office.Core.MsoBarPosition.msoBarFloating
         Else
            Kind = Microsoft.Office.Core.MsoBarPosition.msoBarTop
         End If

         ' Add custom toolbar and display it:
         toolBar = VBE.CommandBars.Add(Name:=Caption, _
                                    Position:=Kind, _
                                    Temporary:=True)
         toolBar.Visible = True
         Return toolBar
      Catch e As System.Exception
         Return toolBar
      End Try
   End Function

   Public Function AddOfficeToolBarButton(ByVal VBE As EnvDTE.DTE, _
      ByVal ToolBar As Microsoft.Office.Core.CommandBar, _
      ByVal Caption As String, _
      ByVal Bitmap As Object, _
      Optional ByVal pos As Byte = 0, _
      Optional ByVal sep As Boolean = False) _
      As Microsoft.Office.Core.CommandBarControl

      ' Variables:
      Dim cmdBtn As Microsoft.Office.Core.CommandBarControl

      Try
         If Caption = "" Or Bitmap Is Nothing Then Exit Function

         Clipboard.SetDataObject(Bitmap)

         ' Add button to Visual Studio IDE toolbar
         If pos = 0 Then pos = ToolBar.Controls.Count + 1
         cmdBtn = ToolBar.Controls.Add(Type:=Microsoft.Office.Core.MsoControlType.msoControlButton, _
                                        Before:=pos, _
                                        Temporary:=True)

         ' Set properties of button
         cmdBtn.Caption = Caption
         If sep Then cmdBtn.BeginGroup = True
         cmdBtn.Style = Microsoft.Office.Core.MsoButtonStyle.msoButtonIcon
         cmdBtn.PasteFace()
         Return cmdBtn
      Catch e As System.Exception
         Return cmdBtn
      End Try
   End Function

   Public Function AddOfficeToolBarIconAndCaption(ByVal VBE As EnvDTE.DTE, _
      ByVal ToolBar As Microsoft.Office.Core.CommandBar, _
      ByVal Caption As String, _
      ByVal Bitmap As Object, _
      Optional ByVal pos As Byte = 0, _
      Optional ByVal sep As Boolean = False) _
      As Microsoft.Office.Core.CommandBarControl

      ' Variables:
      Dim cmdBtn As Microsoft.Office.Core.CommandBarControl

      Try
         If Caption = "" Or Bitmap Is Nothing Then Exit Function

         Clipboard.SetDataObject(Bitmap)

         ' Add button to VB toolbar:
         If pos = 0 Then pos = ToolBar.Controls.Count + 1
         cmdBtn = ToolBar.Controls.Add(Type:=Microsoft.Office.Core.MsoControlType.msoControlButton, _
                                        Before:=pos, _
                                        Temporary:=True)

         ' Set properties of button:
         cmdBtn.Caption = Caption
         If sep Then cmdBtn.BeginGroup = True
         cmdBtn.Style = Microsoft.Office.Core.MsoButtonStyle.msoButtonIconAndCaption
         cmdBtn.PasteFace()
         Return cmdBtn
      Catch e As System.Exception
         Return cmdBtn
      End Try
   End Function

End Class
