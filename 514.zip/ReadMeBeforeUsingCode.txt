Since none of the add-in projects were created on your machine, using the Add-in Wizard; they will not be automatically registered in your registry and therefore you cannot expect to see them listed in the Add-in Manager Dialog.  The follow steps should be followed to test any of the add-in projects from the downloaded code:

1. Load the desired solution from the selected chapter into Visual Studio.NET.
2. Build the solution.
3. The add-in will be registered by the Build process, but it will not be automatically listed in the Add-in Manager dialog manager, as it would if it had been created by the Add-in Wizard.  The build process does everything but create the Add-In Manager entries.  To get that done, you can either go to Regedit and make the entries shown below; or you can create a .reg file using the infromation shown below, replacing the value for "ProjectName" with the name of the respective Add-in project name.  Also, replace the values for the FriendlyName, and Description entries to match the add-in you desire to load.  If you choose to create a .reg file, once you have created the file, using a text editor, simply double click the file in explorer and the data will be added to the registry.  You should then be able to go to the Add-In Manager, under the Tools Menu, in VS.NET and find your add-in listed.  Check the desired boxes and the add-in should load.

FreindlyName is the name that will appear in the Add-In Manager Dialog.
Description will appear there also to describe the add-in.
ProjectName.Connect should be the name of the add-in project followed by ".Connect" 

REGEDIT4
[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\VisualStudio\AddIns\ProjectName.Connect]
"FriendlyName"="ExternaName"
"Description"="Description for Addin Manager Dialog"
"LoadBehavior"=dword:00000000
"CommandLineSafe"=dword:00000000
"CommandPreload"=dword:00000000
